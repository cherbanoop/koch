-- "addons\\services\\lua\\autorun\\server\\sv_services.lua"
--[[---------------------------------------------------------------------------
Dispatcher (911) - серверная часть. Клиент: autorun/client/cl_services.lua (рация -> "Вызовы"),
группы и кто отвечает на вызовы: sh_services_config.lua (NYPD - полиция, FDNY - пожарные и парамедики).
  services_update  клиент -> сервер: String группа ("" - сервер подберёт группу сам)
                   сервер -> клиент: String группа, UInt32 размер, Data (DarkRP.TableCompress журнала)
  services_respond клиент -> сервер: String группа, UInt32 номер вызова, UInt3 действие
                   (1 - принять, 2 - открепиться, 3 - завершить)
  services_call    клиент -> сервер: UInt2 служба (Dispatcher.Services), String что случилось
                   (номер 911 в телефоне - mc_phone/extentions/addons/dispatcher.lua)
  Журнал группы: [номер] = {name, reason, time, pos, number (перезвонить заявителю), status (1 - активен,
                 2 - завершён), responders = {[SteamID] = {unit, name}}, closedby, closed}
  Вызов подаётся звонком на 911, командами /911 /ems /fire, из кода - Dispatcher.AddCall; пожары vFire - сами.
---------------------------------------------------------------------------]]
AddCSLuaFile("sh_services_config.lua")
include("sh_services_config.lua")

util.AddNetworkString("services_update")
util.AddNetworkString("services_respond")
util.AddNetworkString("services_call")
util.AddNetworkString("services_request")

Dispatcher = Dispatcher or {}
Dispatcher.Log = Dispatcher.Log or {}
Dispatcher.Meta = Dispatcher.Meta or {} -- только сервер: [номер] = {grp, caller = SteamID, fire = true}
Dispatcher.LastId = Dispatcher.LastId or 0

Dispatcher.Settings = {
	CallCooldown = 60, -- секунд между вызовами одного игрока
	PhoneWindow = 120, -- столько секунд после звонка на 911 можно описать вызов
	ReasonLen = 120, -- символов в описании
	CallLifetime = 1800, -- активный вызов закрывается сам через 30 минут
	KeepClosed = 3600, -- завершённые вызовы держатся в журнале час
	MaxClosed = 25, -- и не больше стольких на группу
	FireCalls = true, -- пожары vFire вызывают FDNY сами ("Очевидец")
	FireDelay = 30, -- огонь должен гореть столько секунд
	FireMin = 2, -- очагов рядом, чтобы это был пожар
	FireRadius = 800, -- один вызов на пожар в этом радиусе
}

-- службы телефона (UInt2) и чата: группа, приписка к причине, причина по умолчанию
Dispatcher.Services = {
	[1] = {grp = "NYPD", name = "Полиция", def = "Требуется полиция"},
	[2] = {grp = "FDNY", name = "Скорая", prefix = "Скорая: ", def = "Требуется медицинская помощь"},
	[3] = {grp = "FDNY", name = "Пожарные", prefix = "Пожар: ", def = "Пожар"},
}

local cfg = Dispatcher.Settings

local function cutText(str, max)
	str = string.Trim((string.gsub(tostring(str or ""), "%c", " ")))

	local len = utf8.len(str)
	if not len then return "" end

	if len > max then
		str = string.Trim(string.sub(str, 1, utf8.offset(str, max + 1) - 1))
	end

	return str
end

local function unitOf(ply)
	return DarkRP.Police and DarkRP.Police.GetUnit and DarkRP.Police.GetUnit(ply) or ""
end

local function responderInfo(ply)
	return {unit = unitOf(ply), name = ply:Name()}
end

local function signature(ply)
	local unit = unitOf(ply)

	return unit ~= "" and unit .. " " .. ply:Name() or ply:Name()
end

-- телефон: McPhone (1.3.1 - NWBool) или предмет-телефон в инвентаре; без McPhone звонить можно и так
local function hasPhone(ply)
	if not McPhone then return true end
	if McPhone.CanUsePhone and McPhone.CanUsePhone(ply) then return true end

	return McINV and McINV.GetPhone and McINV.GetPhone(ply) ~= nil or false
end

-- номер для обратного звонка (McPhone 1.2.0: номер персонажа McPhone.NumberChar)
local function phoneNumber(ply)
	if McPhone and McPhone.CanUsePhone and McPhone.CanUsePhone(ply) then
		return McPhone.NumberChar and tostring(McPhone.NumberChar(ply)) or tostring(ply:AccountID())
	end
end

--[[---------------------------------------------------------------------------
Группы
---------------------------------------------------------------------------]]
function Dispatcher.IsMember(ply, grp)
	local g = Dispatcher.Config and Dispatcher.Config.Grps and Dispatcher.Config.Grps[grp]
	if not g or not IsValid(ply) or not ply:IsPlayer() then return false end
	if not (g.Teams and g.Teams[ply:Team()]) and not (g.Responders and g.Responders(ply)) then return false end

	return not g.CustomCheck or g.CustomCheck(ply) ~= false
end

-- клиент ищет группу только по Teams (Инспектор FDNY её не найдёт и пришлёт "") - подбираем по Responders
function Dispatcher.GetGroup(ply, key)
	if Dispatcher.IsMember(ply, key) then return key end
	if key ~= "" then return end

	for grp in SortedPairs(Dispatcher.Config.Grps or {}) do
		if Dispatcher.IsMember(ply, grp) then return grp end
	end
end

function Dispatcher.GetMembers(grp, radio)
	local res = {}

	for _, v in ipairs(player.GetHumans()) do
		if not Dispatcher.IsMember(v, grp) then continue end
		if radio and not v:getDarkRPVar("rc_on") then continue end

		table.insert(res, v)
	end

	return res
end

function Dispatcher.GetCall(grp, id)
	return Dispatcher.Log[grp] and Dispatcher.Log[grp][id]
end

local function callerOf(id)
	local meta = Dispatcher.Meta[id]
	local ply = meta and meta.caller and player.GetBySteamID(meta.caller)

	return IsValid(ply) and ply or nil
end

--[[---------------------------------------------------------------------------
Отправка журнала
---------------------------------------------------------------------------]]
local function writeLog(key, data, len)
	net.Start("services_update")
		net.WriteString(key)
		net.WriteUInt(len, 32)
		net.WriteData(data, len)
end

function Dispatcher.SendLog(ply, grp, key)
	key = key or grp
	ply.Dispatcher_Grp, ply.Dispatcher_Key = grp, key

	local data, len = DarkRP.TableCompress(Dispatcher.Log[grp] or {})
	writeLog(key, data, len)
	net.Send(ply)
end

-- изменения уходят тем, кто уже открывал журнал этой группы (под тем ключом, что прислал клиент)
local function pushLog(grp)
	local data, len = DarkRP.TableCompress(Dispatcher.Log[grp] or {})

	for _, v in ipairs(Dispatcher.GetMembers(grp)) do
		if v.Dispatcher_Grp ~= grp or not v.Dispatcher_Key then continue end

		writeLog(v.Dispatcher_Key, data, len)
		net.Send(v)
	end
end

function Dispatcher.Update(grp)
	timer.Create("Dispatcher.Update." .. grp, 0.1, 1, function()
		pushLog(grp)
	end)
end

--[[---------------------------------------------------------------------------
Вызовы
---------------------------------------------------------------------------]]
-- grp: "NYPD" | "FDNY"; caller - игрок или nil (автоматический вызов); opts: {name, number, fire}
function Dispatcher.AddCall(grp, reason, pos, caller, opts)
	if not Dispatcher.Config.Grps[grp] or not isvector(pos) then return end

	opts = opts or {}
	reason = cutText(reason, cfg.ReasonLen)
	if reason == "" then reason = "Без описания" end

	Dispatcher.LastId = Dispatcher.LastId + 1

	local id = Dispatcher.LastId
	local call = {
		name = opts.name or (IsValid(caller) and caller:Name()) or "Аноним",
		reason = reason,
		time = os.time(),
		pos = pos,
		number = opts.number,
		status = 1,
		responders = {},
	}

	Dispatcher.Log[grp] = Dispatcher.Log[grp] or {}
	Dispatcher.Log[grp][id] = call
	Dispatcher.Meta[id] = {grp = grp, caller = IsValid(caller) and caller:SteamID() or nil, fire = opts.fire}

	local members = Dispatcher.GetMembers(grp)
	DarkRP.notify(members, 0, 8, "911 | Вызов № " .. id .. ": " .. reason)

	if IsValid(caller) then
		DarkRP.notify(caller, 0, 6, "Диспетчер 911: вызов № " .. id .. " принят. " .. (#members > 0 and "Ожидайте помощи" or "Свободных экипажей нет, вызов в очереди"))
	end

	DarkRP.log("911", caller, nil, "вызов № " .. id .. " (" .. grp .. "): " .. reason)
	hook.Run("Dispatcher.CallCreated", grp, id, call, caller)

	Dispatcher.Update(grp)

	return id, call
end

-- N.Y. Noire: короткий вызов (так зовут mc_simple_npcs / сигнализации):
-- Dispatcher.Call(grp, pos, reason, callername)
function Dispatcher.Call(grp, pos, reason, caller)
	if isentity(caller) then
		return Dispatcher.AddCall(grp, reason, pos, caller)
	end

	return Dispatcher.AddCall(grp, reason, pos, nil, {name = caller})
end

function Dispatcher.CanCall(ply, silent)
	if not IsValid(ply) or not ply:Alive() then return false end

	if ply.Dispatcher_Next and ply.Dispatcher_Next > CurTime() then
		if not silent then
			DarkRP.notify(ply, 1, 4, "Линия 911 занята. Перезвоните через " .. math.ceil(ply.Dispatcher_Next - CurTime()) .. " сек.")
		end

		return false
	end

	local ok, msg = hook.Run("Dispatcher.CanCall", ply)

	if ok == false then
		if msg and not silent then DarkRP.notify(ply, 1, 4, msg) end
		return false
	end

	return true
end

-- вызов от игрока (телефон, чат); повторный звонок, пока вызов открыт, дополняет его
function Dispatcher.PlayerCall(ply, idx, reason, payphone)
	local s = Dispatcher.Services[idx]
	if not s or not Dispatcher.Config.Grps[s.grp] or not Dispatcher.CanCall(ply) then return end

	reason = cutText(reason, cfg.ReasonLen)
	if reason == "" then reason = s.def end
	reason = (s.prefix or "") .. reason

	ply.Dispatcher_Next = CurTime() + cfg.CallCooldown

	local sid = ply:SteamID()

	for id, call in pairs(Dispatcher.Log[s.grp] or {}) do
		local meta = Dispatcher.Meta[id]
		if call.status ~= 1 or not meta or meta.caller ~= sid then continue end

		call.reason = cutText(reason, cfg.ReasonLen)
		call.pos = ply:GetPos()
		call.number = call.number or (not payphone and phoneNumber(ply) or nil)

		DarkRP.notify(Dispatcher.GetMembers(s.grp), 0, 8, "911 | Повторный звонок, вызов № " .. id .. ": " .. call.reason)
		DarkRP.notify(ply, 0, 5, "Диспетчер 911: информация по вызову № " .. id .. " передана экипажам")
		DarkRP.log("911", ply, nil, "повторный звонок, вызов № " .. id .. ": " .. call.reason)

		Dispatcher.Update(s.grp)
		return id
	end

	return Dispatcher.AddCall(s.grp, reason, ply:GetPos(), ply, {number = not payphone and phoneNumber(ply) or nil})
end

-- снять юнита со всех активных вызовов (кроме except)
local function detach(ply, exceptGrp, exceptId)
	local sid, ids = ply:SteamID(), {}

	for grp, log in pairs(Dispatcher.Log) do
		for id, call in pairs(log) do
			if call.status ~= 1 or not call.responders[sid] or (grp == exceptGrp and id == exceptId) then continue end

			call.responders[sid] = nil
			table.insert(ids, id)
			Dispatcher.Update(grp)
		end
	end

	return ids
end

function Dispatcher.Accept(ply, grp, id)
	local call = Dispatcher.GetCall(grp, id)
	if not call or call.status ~= 1 then return end

	local sid = ply:SteamID()
	if call.responders[sid] then return end

	local left = detach(ply, grp, id)
	call.responders[sid] = responderInfo(ply)

	local who = signature(ply)
	local radio = {}

	for _, v in ipairs(Dispatcher.GetMembers(grp, true)) do
		if v ~= ply then table.insert(radio, v) end
	end

	DarkRP.notify(ply, 0, 5, "Вы приняли вызов № " .. id .. (#left > 0 and " (сняты с вызова № " .. table.concat(left, ", ") .. ")" or ""))
	DarkRP.notify(radio, 0, 5, who .. " принял вызов № " .. id)

	local caller = callerOf(id)
	if caller and caller ~= ply then
		DarkRP.notify(caller, 0, 6, "Диспетчер 911: к вам направлен " .. (unitOf(ply) ~= "" and "экипаж " .. unitOf(ply) or ply:Name()))
	end

	DarkRP.log("911", ply, caller, "принял вызов № " .. id .. " (" .. grp .. ")")
	hook.Run("Dispatcher.CallAccepted", grp, id, call, ply)

	Dispatcher.Update(grp)
end

function Dispatcher.Detach(ply, grp, id)
	local call = Dispatcher.GetCall(grp, id)
	if not call or call.status ~= 1 or not call.responders[ply:SteamID()] then return end

	call.responders[ply:SteamID()] = nil

	DarkRP.notify(ply, 0, 4, "Вы откреплены от вызова № " .. id)
	Dispatcher.Update(grp)
end

-- ply - кто завершил (nil - диспетчер: истёк срок, админ); by - подпись вместо игрока
function Dispatcher.CloseCall(grp, id, ply, by)
	local call = Dispatcher.GetCall(grp, id)
	if not call or call.status ~= 1 then return end

	for sid in pairs(call.responders) do
		local v = player.GetBySteamID(sid)
		if IsValid(v) then call.responders[sid] = responderInfo(v) end
	end

	call.status = 2
	call.closed = os.time()
	call.closedby = IsValid(ply) and signature(ply) or by or "Диспетчер"

	local others = {}

	for sid in pairs(call.responders) do
		local v = player.GetBySteamID(sid)
		if IsValid(v) and v ~= ply then table.insert(others, v) end
	end

	if IsValid(ply) then DarkRP.notify(ply, 0, 5, "Вызов № " .. id .. " завершён") end
	DarkRP.notify(others, 0, 5, "Вызов № " .. id .. " завершён (" .. call.closedby .. ")")

	local caller = callerOf(id)
	if caller and caller ~= ply then
		DarkRP.notify(caller, 0, 5, "Диспетчер 911: ваш вызов № " .. id .. " закрыт")
	end

	if IsValid(ply) then
		DarkRP.log("911", ply, caller, "завершил вызов № " .. id .. " (" .. grp .. ")")
	else
		DarkRP.log("911", nil, caller, "вызов № " .. id .. " (" .. grp .. ") закрыт: " .. call.closedby)
	end

	hook.Run("Dispatcher.CallClosed", grp, id, call, ply)

	Dispatcher.Update(grp)
end

--[[---------------------------------------------------------------------------
Сеть
---------------------------------------------------------------------------]]
net.Receive("services_update", function(len, ply)
	if DarkRP.NetDelay(ply, "services_update", 1) then return end

	local key = net.ReadString()
	local grp = Dispatcher.GetGroup(ply, key)
	if not grp then return end

	Dispatcher.SendLog(ply, grp, key)
end)

net.Receive("services_respond", function(len, ply)
	if DarkRP.NetDelay(ply, "services_respond", 0.5) then return end

	local key = net.ReadString()
	local id = net.ReadUInt(32)
	local act = net.ReadUInt(3)

	local grp = Dispatcher.GetGroup(ply, key)
	if not grp or not ply:IsFreeman() then return end

	local call = Dispatcher.GetCall(grp, id)

	if not call or call.status ~= 1 then
		DarkRP.notify(ply, 1, 4, "Вызов № " .. id .. " уже закрыт")
		Dispatcher.SendLog(ply, grp, key)
		return
	end

	if act == 1 then
		Dispatcher.Accept(ply, grp, id)
	elseif act == 2 then
		Dispatcher.Detach(ply, grp, id)
	elseif act == 3 then
		if not call.responders[ply:SteamID()] then
			DarkRP.notify(ply, 1, 4, "Сначала примите вызов")
			return
		end

		Dispatcher.CloseCall(grp, id, ply)
	end
end)

-- описание после звонка на 911 (без звонка - игнор)
net.Receive("services_call", function(len, ply)
	if DarkRP.NetDelay(ply, "services_call", 2) then return end

	local idx = net.ReadUInt(2)
	local reason = net.ReadString()

	if not ply.Dispatcher_Phone or ply.Dispatcher_Phone + cfg.PhoneWindow < CurTime() then return end

	local payphone = ply.Dispatcher_PayPhone
	ply.Dispatcher_Phone, ply.Dispatcher_PayPhone = nil, nil

	Dispatcher.PlayerCall(ply, idx, reason, payphone)
end)

-- McPhone 1.2.0: звонок на 911 -> гудки -> меню служб в телефоне (sh_init.lua McPhone.ExtraNumbersFunc["911"])
--   String группа ("NYPD" / "FDNY"), String причина (из списка police_call или "скорая"/"пожар")
--   Звонок на 911 отмечает сервер телефона (sv_init.lua McPhone.CallExtra: ply.Dispatcher_Phone)
net.Receive("services_request", function(len, ply)
	if DarkRP.NetDelay(ply, "services_request", 2) then return end

	local grp = net.ReadString()
	local reason = net.ReadString()

	if not ply.Dispatcher_Phone or ply.Dispatcher_Phone + cfg.PhoneWindow < CurTime() then return end

	local idx

	if grp == "NYPD" then
		idx = 1
	elseif grp == "FDNY" then
		idx = (string.find(reason, "ожар", 1, true) or string.find(reason, "озгоран", 1, true)) and 3 or 2
	else
		return
	end

	local payphone = ply.Dispatcher_PayPhone
	ply.Dispatcher_Phone, ply.Dispatcher_PayPhone = nil, nil

	-- причина из меню уже полная: приписку службы не дублируем
	local s = Dispatcher.Services[idx]
	local prefix = s.prefix
	s.prefix = nil
	Dispatcher.PlayerCall(ply, idx, reason, payphone)
	s.prefix = prefix
end)

--[[---------------------------------------------------------------------------
Чат: /911 <что и где> - полиция, /ems - скорая, /fire - пожарные
---------------------------------------------------------------------------]]
local function chatCall(idx, cmd)
	return function(ply, args)
		if not ply:IsFreeman() then
			DarkRP.notify(ply, 1, 4, "Сейчас вы не можете позвонить")
			return ""
		end

		if not hasPhone(ply) then
			DarkRP.notify(ply, 1, 4, "Чтобы позвонить в 911, нужен телефон")
			return ""
		end

		if string.Trim(args or "") == "" then
			DarkRP.notify(ply, 1, 4, "Опишите, что случилось: /" .. cmd .. " <что и где>")
			return ""
		end

		Dispatcher.PlayerCall(ply, idx, args)

		return ""
	end
end

local function addCommands()
	if not DarkRP or not DarkRP.defineChatCommand then return end

	DarkRP.defineChatCommand("911", chatCall(1, "911"), 1)
	DarkRP.defineChatCommand("ems", chatCall(2, "ems"), 1)
	DarkRP.defineChatCommand("fire", chatCall(3, "fire"), 1)
end

addCommands()
hook.Add("DarkRPFinishedLoading", "Dispatcher.Commands", addCommands)

--[[---------------------------------------------------------------------------
Юниты: ушёл с работы / вышел - снимается с вызовов
---------------------------------------------------------------------------]]
hook.Add("DarkRP.LeaveTeam", "Dispatcher.Units", function(ply)
	detach(ply)
	ply.Dispatcher_Grp, ply.Dispatcher_Key = nil, nil
end)

hook.Add("PlayerDisconnected", "Dispatcher.Units", function(ply)
	detach(ply)
end)

--[[---------------------------------------------------------------------------
Пожары (vFire): огонь не потух за FireDelay и очагов рядом >= FireMin - вызов FDNY от очевидца
---------------------------------------------------------------------------]]
local fireChecks = {}

local function isCharacter(ent)
	return IsValid(ent) and (ent:IsPlayer() or ent:IsNPC() or ent:IsRagdoll())
end

local function activeFireCall(pos)
	for id, call in pairs(Dispatcher.Log.FDNY or {}) do
		local meta = Dispatcher.Meta[id]

		if call.status == 1 and meta and meta.fire and call.pos:DistToSqr(pos) < cfg.FireRadius ^ 2 then
			return id
		end
	end
end

local function firesNear(pos)
	local n, sum, car = 0, Vector(0, 0, 0), false

	for _, fire in ipairs(ents.FindByClass("vfire")) do
		if not IsValid(fire) or isCharacter(fire.parent) then continue end

		local p = fire:GetPos()
		if p:DistToSqr(pos) > cfg.FireRadius ^ 2 then continue end

		n = n + 1
		sum = sum + p

		if IsValid(fire.parent) and fire.parent:GetClass() == "gmod_sent_vehicle_fphysics_base" then car = true end
	end

	return n, n > 0 and sum / n or pos, car
end

function Dispatcher.CheckFire(pos)
	if not cfg.FireCalls or activeFireCall(pos) then return end

	local n, center, car = firesNear(pos)
	if n < cfg.FireMin then return end

	Dispatcher.AddCall("FDNY", car and "Горит автомобиль" or "Пожар", center, nil, {name = "Очевидец", fire = true})
end

hook.Add("vFireCreated", "Dispatcher.Fire", function(fire, parent)
	if not cfg.FireCalls or not IsValid(fire) or isCharacter(parent) then return end

	local pos = fire:GetPos()

	for _, p in ipairs(fireChecks) do
		if p:DistToSqr(pos) < cfg.FireRadius ^ 2 then return end
	end

	if activeFireCall(pos) then return end

	table.insert(fireChecks, pos)

	timer.Simple(cfg.FireDelay, function()
		table.RemoveByValue(fireChecks, pos)
		Dispatcher.CheckFire(pos)
	end)
end)

--[[---------------------------------------------------------------------------
Очистка журнала (раз в 30 с): истёкшие и потухшие (пожар без юнитов) вызовы закрываются,
старые завершённые удаляются
---------------------------------------------------------------------------]]
timer.Create("Dispatcher.Cleanup", 30, 0, function()
	local now = os.time()

	for grp, log in pairs(Dispatcher.Log) do
		local closed, changed = {}, false

		for id, call in pairs(log) do
			local meta = Dispatcher.Meta[id]

			if call.status == 1 and now - call.time > cfg.CallLifetime then
				Dispatcher.CloseCall(grp, id, nil, "Диспетчер (истёк срок)")
			elseif call.status == 1 and meta and meta.fire and table.IsEmpty(call.responders) and firesNear(call.pos) == 0 then
				Dispatcher.CloseCall(grp, id, nil, "Диспетчер (огонь потух)")
			end

			if call.status ~= 1 then
				if now - (call.closed or call.time) > cfg.KeepClosed then
					log[id] = nil
					Dispatcher.Meta[id] = nil
					changed = true
				else
					table.insert(closed, id)
				end
			end
		end

		if #closed > cfg.MaxClosed then
			table.sort(closed)

			for i = 1, #closed - cfg.MaxClosed do
				log[closed[i]] = nil
				Dispatcher.Meta[closed[i]] = nil
			end

			changed = true
		end

		if changed then Dispatcher.Update(grp) end
	end
end)
