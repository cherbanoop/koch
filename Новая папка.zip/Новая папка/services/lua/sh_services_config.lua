-- "addons\\services\\lua\\sh_services_config.lua"
-- Retrieved by Urbanichka
Dispatcher = Dispatcher or {}
Dispatcher.Config = {}
Dispatcher.Config.Grps = {}

local function CreateConfig()
	Dispatcher.Config.Grps = {
		["NYPD"] = {
			Teams = table.Copy(GAMEMODE.CivilProtection),
			Responders = function(ply)
				return ply:isCP()
			end,
			CustomCheck = function(ply) return true end,
		},
		["FDNY"] = {
			Teams = {
				[TEAM_REF] = true,
				[TEAM_FIREFIGHTER] = true,
			},
			Responders = function(ply)
				return ply:isEMS()
			end,
			CustomCheck = function(ply) return true end,
		},
	}
end

hook.Add("PostGamemodeLoaded", "CreateServicesConfig", function()
	CreateConfig()
end)

if GAMEMODE then
	CreateConfig()
end