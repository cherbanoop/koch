-- "addons\\glac\\lua\\sv_creditsys.lua"
--[[---------------------------------------------------------------------------
Магазин кредитов (glac) - серверная часть
  - баланс кредитов на аккаунт (SteamID64), SQLite: glac_credits
  - покупки из MSD.OpenDonate (F4 -> "Особые услуги"): NPCShop_BuyItem
      mode 1: предмет CreditShop_Items[k] (кейсы - is_case)
      mode 2: награда эпизода MQS.Episodes[1].Rewards[k] (за очки прогресса)
  - пополнения: консоль/RCON cs_addcredits, очередь glac_pending, HTTP API (CheckURL)
  - кнопка "Обновить" в меню (checkbuy) - проверка новых пополнений
API: ply:GetCredits(), ply:SetCredits(n), ply:AddCredits(n), ply:TakeCredits(n), CSNotify(ply, str, dur, type)
---------------------------------------------------------------------------]]

util.AddNetworkString("ply_SetCredits")
util.AddNetworkString("csnotify")
util.AddNetworkString("checkbuy")
util.AddNetworkString("NPCShop_BuyItem")
util.AddNetworkString("LA.Donate.Note")
util.AddNetworkString("LA.Donate.OpenCase")
util.AddNetworkString("LA.Donate.GetSuit")

CreditShop = CreditShop or {}

CreditShop.Config = {
	-- HTTP API пополнений (необязательно). Пусто - только RCON/консоль и очередь glac_pending
	-- GET <CheckURL>?steamid=<SteamID64>&server=<ServerName>&key=<APIKey>
	-- ответ JSON: {"payments": [{"id": "123", "amount": 100}, ...]} (id уникален - повторно не зачисляется)
	CheckURL = "",
	-- (необязательно) POST сюда подтверждение: steamid, server, key, ids (через запятую)
	ConfirmURL = "",
	APIKey = "",
	ServerName = "noire",

	-- Discord-вебхуки для Discord.Log(канал, данные). "request" - покупка разбана
	Webhooks = {
		request = "",
	},

	-- какие категории можно купить из меню (cars/misc - только как выпадение из кейса)
	Buyable = {
		Other = true,
		Pack = true,
		Money = true,
		Cases = true,
		skins = true,
	},

	-- можно купить без выбранного персонажа (в т.ч. с игровой блокировкой аккаунта)
	NoChar = {
		token = true,
		token2 = true,
		carslots = true,
		episode_1_premium = true,
		token_restore = true,
	},

	BuyDelay = 1.5, -- сек между покупками
	CheckDelay = 10, -- сек между проверками пополнений
}

local cfg = CreditShop.Config
local pmeta = FindMetaTable("Player")

--[[---------------------------------------------------------------------------
База данных
---------------------------------------------------------------------------]]
local function q(str)
	local res = sql.Query(str)

	if res == false then
		ErrorNoHalt("[CreditShop] SQL ошибка: " .. tostring(sql.LastError()) .. "\n" .. str .. "\n")
	end

	return res
end

q([[CREATE TABLE IF NOT EXISTS glac_credits (
	steamid TEXT PRIMARY KEY,
	credits INTEGER NOT NULL DEFAULT 0,
	total INTEGER NOT NULL DEFAULT 0,
	updated INTEGER NOT NULL DEFAULT 0
)]])

q([[CREATE TABLE IF NOT EXISTS glac_pending (
	id INTEGER PRIMARY KEY AUTOINCREMENT,
	steamid TEXT NOT NULL,
	amount INTEGER NOT NULL,
	note TEXT,
	created INTEGER NOT NULL DEFAULT 0
)]])

q([[CREATE TABLE IF NOT EXISTS glac_payments (
	payid TEXT PRIMARY KEY,
	steamid TEXT,
	amount INTEGER,
	time INTEGER
)]])

q([[CREATE TABLE IF NOT EXISTS glac_log (
	id INTEGER PRIMARY KEY AUTOINCREMENT,
	steamid TEXT,
	action TEXT,
	item TEXT,
	amount INTEGER,
	balance INTEGER,
	time INTEGER
)]])

local function toSID64(sid)
	sid = string.Trim(tostring(sid or ""))

	if string.StartWith(string.upper(sid), "STEAM_") then
		sid = util.SteamIDTo64(string.upper(sid))
	end

	if not string.match(sid, "^7656%d%d%d%d%d%d%d%d%d%d%d%d%d$") then return end

	return sid
end

CreditShop.ToSID64 = toSID64

function CreditShop.DBGet(sid64)
	local res = q("SELECT credits, total FROM glac_credits WHERE steamid = " .. sql.SQLStr(sid64))
	res = res and res[1]
	if not res then return 0, 0 end

	return tonumber(res.credits) or 0, tonumber(res.total) or 0
end

function CreditShop.DBSet(sid64, credits, total)
	q(string.format("INSERT OR REPLACE INTO glac_credits (steamid, credits, total, updated) VALUES (%s, %d, %d, %d)",
		sql.SQLStr(sid64), math.floor(credits), math.floor(total or 0), os.time()))
end

function CreditShop.Log(sid64, action, item, amount, balance)
	q(string.format("INSERT INTO glac_log (steamid, action, item, amount, balance, time) VALUES (%s, %s, %s, %d, %d, %d)",
		sql.SQLStr(sid64 or ""), sql.SQLStr(action or ""), sql.SQLStr(item or ""), math.floor(amount or 0), math.floor(balance or 0), os.time()))
end

local function dlog(ply, text, amount)
	if DarkRP and DarkRP.log then
		DarkRP.log("donate", ply, nil, text, nil, amount)
	else
		ServerLog("[CreditShop] " .. (IsValid(ply) and (ply:Nick() .. " (" .. ply:SteamID() .. ") ") or "") .. text .. "\n")
	end
end

--[[---------------------------------------------------------------------------
Уведомления
---------------------------------------------------------------------------]]
function CSNotify(ply, str, duration, notifytype)
	if not IsValid(ply) then
		print("[CreditShop] " .. tostring(str))
		return
	end

	net.Start("csnotify")
		net.WriteString(notifytype == "Error" and "Error" or "Generic")
		net.WriteString(tostring(str))
		net.WriteInt(duration or 4, 16)
	net.Send(ply)
end

local function note(ply, success, item, hsl)
	if not IsValid(ply) then return end

	net.Start("LA.Donate.Note")
		net.WriteUInt(success, 2)
		net.WriteUInt(item or 0, 32)
		net.WriteInt(math.Clamp(math.Round(tonumber(hsl) or 100), -512, 511), 10)
	net.Send(ply)
end

CreditShop.Note = note

-- превью костюма персонажа (MCR.shop[part][item]) после покупки
function CreditShop.SendSuit(ply, item, part, hsl)
	net.Start("LA.Donate.GetSuit")
		net.WriteUInt(item, 32)
		net.WriteString(part)
		net.WriteInt(math.Clamp(math.Round(tonumber(hsl) or 100), -512, 511), 10)
	net.Send(ply)
end

--[[---------------------------------------------------------------------------
Баланс игрока
---------------------------------------------------------------------------]]
function CreditShop.Send(ply)
	if not IsValid(ply) then return end

	net.Start("ply_SetCredits")
		net.WriteInt(math.Clamp(ply:GetCredits(), -2147483647, 2147483647), 32)
	net.Send(ply)
end

function CreditShop.Load(ply)
	if not IsValid(ply) or ply:IsBot() then return end

	ply.cs_credits, ply.cs_total = CreditShop.DBGet(ply:SteamID64())
	ply.cs_loaded = true
end

function CreditShop.Save(ply)
	if not IsValid(ply) or not ply.cs_loaded then return end

	CreditShop.DBSet(ply:SteamID64(), ply.cs_credits or 0, ply.cs_total or 0)
end

function pmeta:GetCredits()
	return math.floor(self.cs_credits or 0)
end

function pmeta:SetCredits(amount, reason)
	if not self.cs_loaded then CreditShop.Load(self) end
	if not self.cs_loaded then return 0 end

	amount = math.max(math.floor(tonumber(amount) or 0), 0)
	local old = self:GetCredits()
	self.cs_credits = amount

	CreditShop.Save(self)
	CreditShop.Send(self)
	CreditShop.Log(self:SteamID64(), reason or "set", "", amount - old, amount)

	hook.Run("CreditShop.CreditsChanged", self, old, amount)

	return amount
end

-- amount < 0 - списание (баланс не уходит в минус). topup = true - пополнение (учитывается в total)
function pmeta:AddCredits(amount, reason, topup)
	if not self.cs_loaded then CreditShop.Load(self) end
	if not self.cs_loaded then return 0 end

	amount = math.floor(tonumber(amount) or 0)
	if amount == 0 then return self:GetCredits() end

	local old = self:GetCredits()
	self.cs_credits = math.max(old + amount, 0)

	if topup and amount > 0 then
		self.cs_total = (self.cs_total or 0) + amount
	end

	CreditShop.Save(self)
	CreditShop.Send(self)
	CreditShop.Log(self:SteamID64(), reason or (amount > 0 and "add" or "take"), "", amount, self.cs_credits)

	hook.Run("CreditShop.CreditsChanged", self, old, self.cs_credits)

	return self.cs_credits
end

function pmeta:CanAffordCredits(amount)
	return self:GetCredits() >= math.floor(tonumber(amount) or 0)
end

function pmeta:TakeCredits(amount, reason)
	amount = math.floor(tonumber(amount) or 0)
	if amount < 0 or not self:CanAffordCredits(amount) then return false end

	self:AddCredits(-amount, reason or "take")

	return true
end

-- начисление по SteamID/SteamID64, в т.ч. оффлайн
function CreditShop.AddCredits(sid, amount, reason, topup)
	local sid64 = toSID64(sid)
	amount = math.floor(tonumber(amount) or 0)
	if not sid64 or amount == 0 then return false end

	local ply = player.GetBySteamID64(sid64)

	if IsValid(ply) and ply.cs_loaded then
		return true, ply:AddCredits(amount, reason, topup)
	end

	local credits, total = CreditShop.DBGet(sid64)
	credits = math.max(credits + amount, 0)
	if topup and amount > 0 then total = total + amount end

	CreditShop.DBSet(sid64, credits, total)
	CreditShop.Log(sid64, reason or "add_offline", "", amount, credits)

	return true, credits
end

function CreditShop.SetCredits(sid, amount, reason)
	local sid64 = toSID64(sid)
	if not sid64 or not tonumber(amount) then return false end

	amount = math.max(math.floor(tonumber(amount)), 0)
	local ply = player.GetBySteamID64(sid64)

	if IsValid(ply) and ply.cs_loaded then
		return true, ply:SetCredits(amount, reason)
	end

	local _, total = CreditShop.DBGet(sid64)
	CreditShop.DBSet(sid64, amount, total)
	CreditShop.Log(sid64, reason or "set_offline", "", 0, amount)

	return true, amount
end

-- поставить пополнение в очередь (зачислится при входе / по кнопке "Обновить")
function CreditShop.QueuePending(sid, amount, notetext)
	local sid64 = toSID64(sid)
	amount = math.floor(tonumber(amount) or 0)
	if not sid64 or amount <= 0 then return false end

	q(string.format("INSERT INTO glac_pending (steamid, amount, note, created) VALUES (%s, %d, %s, %d)",
		sql.SQLStr(sid64), amount, sql.SQLStr(notetext or ""), os.time()))

	return true
end

--[[---------------------------------------------------------------------------
Проверка пополнений
---------------------------------------------------------------------------]]
local function credited(ply, amount, source)
	if amount <= 0 or not IsValid(ply) then return end

	ply:AddCredits(amount, source or "topup", true)
	CSNotify(ply, "Ваш баланс пополнен на " .. string.Comma(amount) .. " ¤", 6, "Generic")
	dlog(ply, "пополнил баланс на " .. amount .. " кредитов (" .. (source or "topup") .. ")", amount)
end

function CreditShop.ProcessPending(ply)
	if not IsValid(ply) or not ply.cs_loaded then return 0 end

	local res = q("SELECT id, amount FROM glac_pending WHERE steamid = " .. sql.SQLStr(ply:SteamID64()))
	if not res or not res[1] then return 0 end

	local sum, ids = 0, {}

	for _, row in ipairs(res) do
		sum = sum + math.max(tonumber(row.amount) or 0, 0)
		table.insert(ids, tonumber(row.id))
	end

	q("DELETE FROM glac_pending WHERE id IN (" .. table.concat(ids, ",") .. ")")
	credited(ply, sum, "pending")

	return sum
end

local function urlencode(str)
	return (string.gsub(tostring(str), "[^%w%-_%.~]", function(c)
		return string.format("%%%02X", string.byte(c))
	end))
end

function CreditShop.CheckHTTP(ply, callback)
	if not cfg.CheckURL or cfg.CheckURL == "" then
		if callback then callback(0) end
		return
	end

	local sid64 = ply:SteamID64()
	local url = cfg.CheckURL .. (string.find(cfg.CheckURL, "?", 1, true) and "&" or "?")
		.. "steamid=" .. sid64 .. "&server=" .. urlencode(cfg.ServerName) .. "&key=" .. urlencode(cfg.APIKey)

	http.Fetch(url, function(body, _, _, code)
		if not IsValid(ply) then return end

		local data = code == 200 and util.JSONToTable(body or "")
		local list = istable(data) and (data.payments or data) or {}
		local sum, ids = 0, {}

		for _, pay in ipairs(istable(list) and list or {}) do
			local id = istable(pay) and pay.id and tostring(pay.id)
			local amount = istable(pay) and math.floor(tonumber(pay.amount) or 0) or 0

			if id and amount > 0 and not q("SELECT payid FROM glac_payments WHERE payid = " .. sql.SQLStr(id)) then
				q(string.format("INSERT INTO glac_payments (payid, steamid, amount, time) VALUES (%s, %s, %d, %d)", sql.SQLStr(id), sql.SQLStr(sid64), amount, os.time()))
				sum = sum + amount
				table.insert(ids, id)
			end
		end

		credited(ply, sum, "http")

		if #ids > 0 and cfg.ConfirmURL and cfg.ConfirmURL ~= "" then
			http.Post(cfg.ConfirmURL, {steamid = sid64, server = cfg.ServerName, key = cfg.APIKey, ids = table.concat(ids, ",")})
		end

		if callback then callback(sum) end
	end, function(err)
		ErrorNoHalt("[CreditShop] Ошибка проверки пополнений: " .. tostring(err) .. "\n")
		if callback and IsValid(ply) then callback(0) end
	end)
end

function CreditShop.CheckBuy(ply, silent)
	if not IsValid(ply) or not ply.cs_loaded then return end

	local found = CreditShop.ProcessPending(ply)
	hook.Run("CreditShop.CheckBuy", ply)

	CreditShop.CheckHTTP(ply, function(sum)
		if not IsValid(ply) then return end
		CreditShop.Send(ply)

		if not silent and found + sum <= 0 then
			CSNotify(ply, "Новых пополнений не найдено", 4, "Generic")
		end
	end)
end

net.Receive("checkbuy", function(len, ply)
	if (ply.cs_nextcheck or 0) > CurTime() then
		CSNotify(ply, "Подождите " .. math.ceil(ply.cs_nextcheck - CurTime()) .. " сек. перед повторной проверкой", 3, "Error")
		return
	end
	ply.cs_nextcheck = CurTime() + cfg.CheckDelay

	CreditShop.CheckBuy(ply)
end)

hook.Add("PlayerInitialSpawn", "CreditShop.Load", function(ply)
	CreditShop.Load(ply)

	timer.Simple(15, function()
		if IsValid(ply) and not ply.cs_sent then
			ply.cs_sent = true
			CreditShop.CheckBuy(ply, true)
		end
	end)
end)

hook.Add("DarkRP.PlayerLoaded", "CreditShop.Send", function(ply)
	if ply.cs_sent then return end
	ply.cs_sent = true

	CreditShop.CheckBuy(ply, true)
end)

hook.Add("PlayerDisconnected", "CreditShop.Save", function(ply)
	CreditShop.Save(ply)
end)

hook.Add("ShutDown", "CreditShop.Save", function()
	for _, ply in ipairs(player.GetHumans()) do
		CreditShop.Save(ply)
	end
end)

--[[---------------------------------------------------------------------------
Discord.Log (гейммод объявляет пустую таблицу Discord, сам модуль у автора был отдельно)
---------------------------------------------------------------------------]]
local function discordShim()
	Discord = Discord or {}
	if Discord.Log then return end

	function Discord.Log(channel, data)
		local url = cfg.Webhooks[channel] or cfg.Webhooks.default
		if not url or url == "" or not istable(data) then return end

		HTTP({
			url = url,
			method = "POST",
			type = "application/json",
			body = util.TableToJSON(data),
			failed = function(err)
				ErrorNoHalt("[CreditShop] Discord вебхук: " .. tostring(err) .. "\n")
			end,
		})
	end
end

hook.Add("PostGamemodeLoaded", "CreditShop.Discord", discordShim)
hook.Add("InitPostEntity", "CreditShop.Discord", discordShim)

--[[---------------------------------------------------------------------------
Покупки
---------------------------------------------------------------------------]]
local function indexOf(item)
	for k, v in pairs(CreditShop_Items) do
		if v == item then return k end
	end
end

CreditShop.IndexOf = indexOf

local function safeCall(fn, ...)
	if not isfunction(fn) then return true end

	local ok, a, b = pcall(fn, ...)

	if not ok then
		ErrorNoHalt("[CreditShop] " .. tostring(a) .. "\n")
		return false
	end

	return true, a, b
end

function CreditShop.GetPrice(ply, item)
	local price = item.Price

	if isfunction(item.priceUpdater) then
		local ok, res = safeCall(item.priceUpdater, ply)
		if ok and tonumber(res) then price = res end
	end

	return math.max(math.floor(tonumber(price) or 0), 0)
end

-- true / false, текст ошибки, нет кредитов
function CreditShop.CanBuy(ply, item, price)
	if not istable(item) then return false end
	if not cfg.Buyable[item.Category] then return false end
	if item.is_case and not (CreditShop_Cases[item.is_case] and CreditShop_Cases[item.is_case][1]) then return false, "Кейс сейчас недоступен" end
	if not item.is_case and not isfunction(item.OnPurFunction) and not item.perma then return false, "Предмет сейчас недоступен" end

	if not cfg.NoChar[item.key] and not ply:getDarkRPVar("character") then
		return false, "Сначала выберите персонажа"
	end

	if isfunction(item.check) then
		local ok, res = safeCall(item.check, ply)
		if not ok then return false, "Предмет сейчас недоступен" end
		if not res then return false, "Вы не можете приобрести этот предмет" end
	end

	local res, reason = hook.Run("CreditShop.CanBuy", ply, item, price)
	if res == false then return false, reason end

	if not ply:CanAffordCredits(price) then return false, nil, true end

	return true
end

-- взвешенный рандом по chance
function CreditShop.RollCase(case)
	local list = CreditShop_Cases[case]
	if not istable(list) then return end

	local sum = 0

	for _, v in ipairs(list) do
		sum = sum + math.max(tonumber(v.chance) or 0, 0)
	end

	if sum <= 0 then return end

	local roll = math.Rand(0, sum)

	for _, v in ipairs(list) do
		roll = roll - math.max(tonumber(v.chance) or 0, 0)
		if roll <= 0 then return v end
	end

	return list[#list]
end

local function give(ply, item)
	if item.perma and ply.CS_GivePerma then
		ply:CS_GivePerma(item.perma, item.perma_time)
	end

	return safeCall(item.OnPurFunction, ply, item)
end

function CreditShop.Buy(ply, k, hsl)
	local item = CreditShop_Items[k]
	if not istable(item) then return end

	local price = CreditShop.GetPrice(ply, item)
	local can, reason, nomoney = CreditShop.CanBuy(ply, item, price)

	if not can then
		if nomoney then
			note(ply, 1, k, hsl)
		elseif reason then
			DarkRP.notify(ply, 1, 4, reason)
		end
		return
	end

	if price > 0 and not ply:TakeCredits(price, "buy") then
		note(ply, 1, k, hsl)
		return
	end

	local sid64 = ply:SteamID64()
	CreditShop.Log(sid64, "buy", item.key, -price, ply:GetCredits())

	-- кейс
	if item.is_case then
		local drop = CreditShop.RollCase(item.is_case)
		local dropItem = drop and CreditShop_Items[drop.tbl]

		if not istable(dropItem) or not give(ply, dropItem) then
			if price > 0 then ply:AddCredits(price, "refund") end
			DarkRP.notify(ply, 1, 4, "Не удалось открыть кейс, кредиты возвращены")
			dlog(ply, "ошибка открытия кейса " .. tostring(item.key) .. " (" .. tostring(drop and drop.tbl) .. "), кредиты возвращены", price)
			return
		end

		CreditShop.Log(sid64, "case_drop", drop.tbl, 0, ply:GetCredits())
		dlog(ply, "открыл кейс \"" .. tostring(item.Name) .. "\" за " .. price .. " ¤ и получил \"" .. tostring(dropItem.Name) .. "\"", price)
		hook.Run("CreditShop.Bought", ply, item, price, dropItem)

		-- шаг 54: рулетка кейса (msd_ui msdf4menu.lua, страница "caseroll") - цвет витрины
		net.Start("LA.Donate.OpenCase")
			net.WriteInt(math.Clamp(math.Round(tonumber(hsl) or 100), -512, 511), 10)
		net.Send(ply)

		note(ply, 2, indexOf(dropItem) or 0, hsl)
		return
	end

	if not give(ply, item) then
		if IsValid(ply) then
			if price > 0 then ply:AddCredits(price, "refund") end
			DarkRP.notify(ply, 1, 4, "Ошибка выдачи предмета, кредиты возвращены")
		else
			CreditShop.AddCredits(sid64, price, "refund")
		end

		dlog(ply, "ошибка выдачи \"" .. tostring(item.Name) .. "\", кредиты возвращены", price)
		return
	end

	dlog(ply, "купил \"" .. tostring(item.Name) .. "\" за " .. price .. " ¤", price)
	hook.Run("CreditShop.Bought", ply, item, price)

	note(ply, 2, k, hsl)
end

-- награды эпизода (очки прогресса MQS), если эпизоды есть в mc_quests
function CreditShop.BuyReward(ply, k)
	local ep = MQS and MQS.Episodes and MQS.Episodes[1]
	local reward = ep and ep.Rewards and ep.Rewards[k]
	if not istable(reward) then return end

	local unlocks = table.Copy(MQS.GetDataStored(ply, "episode_1_unlocks") or {})
	local tokens = tonumber(MQS.GetDataStored(ply, "episode_1_tokens")) or 0
	local cost = math.max(math.floor(tonumber(reward.cost) or 0), 0)
	local notall = table.Count(unlocks) < #ep.Rewards - 1

	if reward.premium and not MQS.GetDataStored(ply, "episode_1_premium") then
		DarkRP.notify(ply, 1, 4, "Доступно только с премиум допуском")
		return
	end

	if unlocks[k] then
		DarkRP.notify(ply, 1, 4, "Вы уже разблокировали этот предмет")
		return
	end

	if reward.oncomplete and notall then
		DarkRP.notify(ply, 1, 4, "Сначала разблокируйте все остальные награды")
		return
	end

	if tokens < cost then
		DarkRP.notify(ply, 1, 4, "Нужно больше очков прогресса чтобы открыть предмет")
		return
	end

	if isfunction(reward.check) then
		local ok, res = safeCall(reward.check, ply)

		if not ok or not res then
			DarkRP.notify(ply, 1, 4, "Вы не можете получить эту награду")
			return
		end
	end

	-- шаг 31: в наградах из скриптхука (mc_quests sh_util.lua) функция выдачи называется give_func
	local fn = reward.give_func or reward.OnPurFunction or reward.func or reward.reward or reward.give

	if not isfunction(fn) or not safeCall(fn, ply, reward) then
		DarkRP.notify(ply, 1, 4, "Ошибка выдачи награды")
		return
	end

	-- награду "oncomplete" можно забирать бесконечно - не отмечаем
	if not reward.oncomplete then
		unlocks[k] = true
		MQS.SetNWStoredData(ply, "episode_1_unlocks", unlocks)
	end

	MQS.SetNWStoredData(ply, "episode_1_tokens", tokens - cost)

	dlog(ply, "получил награду эпизода \"" .. tostring(reward.name) .. "\" за " .. cost .. " очков", cost)

	note(ply, 3, k, cost > 1000 and 0 or 50 + (cost / 500) * 200)
end

net.Receive("NPCShop_BuyItem", function(len, ply)
	if (ply.cs_nextbuy or 0) > CurTime() then return end
	ply.cs_nextbuy = CurTime() + cfg.BuyDelay

	if not ply.cs_loaded then
		DarkRP.notify(ply, 1, 4, "Баланс ещё загружается, попробуйте позже")
		return
	end

	local mode = net.ReadUInt(2)
	local k = net.ReadUInt(32)

	if mode == 1 then
		CreditShop.Buy(ply, k, net.ReadInt(10))
	elseif mode == 2 then
		CreditShop.BuyReward(ply, k)
	end
end)

--[[---------------------------------------------------------------------------
Консоль / RCON (для сайта доната):
  cs_addcredits <STEAM_0:X:Y | SteamID64> <кол-во>   - начислить (оффлайн тоже)
  cs_setcredits <STEAM_0:X:Y | SteamID64> <кол-во>   - установить
  cs_getcredits <STEAM_0:X:Y | SteamID64>            - узнать баланс
  cs_queuecredits <STEAM_0:X:Y | SteamID64> <кол-во> - в очередь (зачислится по кнопке "Обновить"/при входе)
Из игры - только суперадмин (или SAM: addcredits / setcredits / credits)
---------------------------------------------------------------------------]]
local function parseArgs(argStr)
	argStr = string.gsub(argStr or "", "\"", "")
	argStr = string.gsub(argStr, "%s*:%s*", ":")

	local sid = string.match(argStr, "STEAM_%d:%d:%d+") or string.match(argStr, "7656%d+")
	local rest = sid and string.gsub(argStr, string.PatternSafe(sid), "", 1) or ""

	return sid, tonumber(string.match(rest, "%-?%d+"))
end

local function canConsole(ply)
	return not IsValid(ply) or ply:IsSuperAdmin()
end

local function reply(ply, text)
	if IsValid(ply) then
		ply:PrintMessage(HUD_PRINTCONSOLE, "[CreditShop] " .. text)
	else
		print("[CreditShop] " .. text)
	end
end

concommand.Add("cs_addcredits", function(ply, cmd, args, argStr)
	if not canConsole(ply) then return end

	local sid, amount = parseArgs(argStr)
	local ok, balance = CreditShop.AddCredits(sid, amount, IsValid(ply) and "admin" or "rcon", true)

	if not ok then
		reply(ply, "Использование: cs_addcredits <STEAM_0:X:Y | SteamID64> <кол-во>")
		return
	end

	reply(ply, "Начислено " .. amount .. " кредитов " .. sid .. ", баланс: " .. balance)
	dlog(IsValid(ply) and ply or nil, "начислил " .. amount .. " кредитов " .. sid, amount)

	local target = player.GetBySteamID64(toSID64(sid))

	if IsValid(target) and amount > 0 then
		CSNotify(target, "Ваш баланс пополнен на " .. string.Comma(amount) .. " ¤", 6, "Generic")
	end
end)

concommand.Add("cs_setcredits", function(ply, cmd, args, argStr)
	if not canConsole(ply) then return end

	local sid, amount = parseArgs(argStr)
	local ok, balance = CreditShop.SetCredits(sid, amount, IsValid(ply) and "admin_set" or "rcon_set")

	if not ok then
		reply(ply, "Использование: cs_setcredits <STEAM_0:X:Y | SteamID64> <кол-во>")
		return
	end

	reply(ply, "Баланс " .. sid .. " установлен: " .. balance)
	dlog(IsValid(ply) and ply or nil, "установил баланс " .. sid .. " = " .. balance, balance)
end)

concommand.Add("cs_getcredits", function(ply, cmd, args, argStr)
	if not canConsole(ply) then return end

	local sid = parseArgs(argStr)
	local sid64 = toSID64(sid)

	if not sid64 then
		reply(ply, "Использование: cs_getcredits <STEAM_0:X:Y | SteamID64>")
		return
	end

	local target = player.GetBySteamID64(sid64)
	local credits, total = CreditShop.DBGet(sid64)
	if IsValid(target) and target.cs_loaded then credits = target:GetCredits() end

	reply(ply, sid .. ": " .. credits .. " кредитов (всего пополнено: " .. total .. ")")
end)

concommand.Add("cs_queuecredits", function(ply, cmd, args, argStr)
	if not canConsole(ply) then return end

	local sid, amount = parseArgs(argStr)

	if not CreditShop.QueuePending(sid, amount, IsValid(ply) and ply:SteamID() or "rcon") then
		reply(ply, "Использование: cs_queuecredits <STEAM_0:X:Y | SteamID64> <кол-во>")
		return
	end

	reply(ply, "Пополнение " .. amount .. " для " .. sid .. " поставлено в очередь")
end)

-- для SAM-команд (autorun/cs_sam.lua)
function CreditShop.AdminCommand(admin, target, mode, amount)
	if not IsValid(target) then return end

	amount = math.floor(tonumber(amount) or 0)

	if mode == "add" then
		target:AddCredits(amount, "admin", amount > 0)
		dlog(admin, "изменил баланс " .. target:Nick() .. " на " .. amount .. " кредитов", amount)

		if amount > 0 then
			CSNotify(target, "Ваш баланс пополнен на " .. string.Comma(amount) .. " ¤", 6, "Generic")
		end
	elseif mode == "set" then
		target:SetCredits(amount, "admin_set")
		dlog(admin, "установил баланс " .. target:Nick() .. " = " .. amount, amount)
	end

	if IsValid(admin) then
		DarkRP.notify(admin, 0, 4, target:Nick() .. ": " .. string.Comma(target:GetCredits()) .. " ¤")
	else
		print("[CreditShop] " .. target:Nick() .. ": " .. target:GetCredits())
	end
end
