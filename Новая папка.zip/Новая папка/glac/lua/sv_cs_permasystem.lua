-- "addons\\glac\\lua\\sv_cs_permasystem.lua"
--[[---------------------------------------------------------------------------
Перманентные покупки магазина кредитов (выдаются при каждом спавне персонажа).
В текущем конфиге (cs_mainconfig.lua) не используются, но система рабочая:

CreditShop.RegisterPerma("perma_ak", {
	Name = "AK-47 навсегда",
	weapon = "weapon_ak47",                      -- выдать оружие при спавне
	OnSpawn = function(ply, expire) end,         -- или своя логика
})

В предмете магазина: perma = "perma_ak", perma_time = 2592000 (сек, nil - навсегда)
API: ply:CS_GivePerma(key, time), ply:CS_HasPerma(key), ply:CS_RemovePerma(key), ply:CS_GetPerma()
Консоль: cs_giveperma <SteamID> <key> [сек], cs_removeperma <SteamID> <key>
---------------------------------------------------------------------------]]

CreditShop = CreditShop or {}
CreditShop.Perma = CreditShop.Perma or {}

local pmeta = FindMetaTable("Player")

sql.Query([[CREATE TABLE IF NOT EXISTS glac_perma (
	steamid TEXT NOT NULL,
	item TEXT NOT NULL,
	expire INTEGER NOT NULL DEFAULT 0,
	PRIMARY KEY (steamid, item)
)]])

function CreditShop.RegisterPerma(key, data)
	CreditShop.Perma[key] = data
end

local function savePerma(sid64, key, expire)
	sql.Query(string.format("INSERT OR REPLACE INTO glac_perma (steamid, item, expire) VALUES (%s, %s, %d)", sql.SQLStr(sid64), sql.SQLStr(key), expire or 0))
end

local function removePerma(sid64, key)
	sql.Query(string.format("DELETE FROM glac_perma WHERE steamid = %s AND item = %s", sql.SQLStr(sid64), sql.SQLStr(key)))
end

function pmeta:CS_LoadPerma()
	self.cs_perma = {}
	if self:IsBot() then return end

	local now = os.time()
	local res = sql.Query("SELECT item, expire FROM glac_perma WHERE steamid = " .. sql.SQLStr(self:SteamID64()))

	for _, row in ipairs(res or {}) do
		local expire = tonumber(row.expire) or 0

		if expire > 0 and expire <= now then
			removePerma(self:SteamID64(), row.item)
		else
			self.cs_perma[row.item] = expire
		end
	end
end

function pmeta:CS_GetPerma()
	if not self.cs_perma then self:CS_LoadPerma() end

	return self.cs_perma
end

function pmeta:CS_HasPerma(key)
	local expire = self:CS_GetPerma()[key]
	if not expire then return false end

	if expire > 0 and expire <= os.time() then
		self:CS_RemovePerma(key)
		return false
	end

	return true, expire
end

local function apply(ply, key, expire)
	local data = CreditShop.Perma[key]
	if not data then return end

	if data.weapon and not ply:HasWeapon(data.weapon) then
		ply:Give(data.weapon)
	end

	if isfunction(data.OnSpawn) then
		local ok, err = pcall(data.OnSpawn, ply, expire)
		if not ok then ErrorNoHalt("[CreditShop] perma " .. key .. ": " .. tostring(err) .. "\n") end
	end
end

-- time (сек) - продлевает срок, nil/0 - навсегда
function pmeta:CS_GivePerma(key, time)
	local perma = self:CS_GetPerma()
	local now = os.time()
	local expire = 0

	time = tonumber(time) or 0

	if time > 0 then
		local cur = perma[key]
		if cur == 0 then return end -- уже навсегда

		expire = math.max(cur or now, now) + time
	end

	perma[key] = expire
	savePerma(self:SteamID64(), key, expire)

	if self:Alive() and self:getDarkRPVar("character") then
		apply(self, key, expire)
	end

	hook.Run("CreditShop.PermaGiven", self, key, expire)
end

function pmeta:CS_RemovePerma(key)
	self:CS_GetPerma()[key] = nil
	removePerma(self:SteamID64(), key)
end

hook.Add("PlayerInitialSpawn", "CreditShop.Perma", function(ply)
	ply:CS_LoadPerma()
end)

hook.Add("PlayerLoadout", "CreditShop.Perma", function(ply)
	if not ply:getDarkRPVar("character") then return end

	for key, expire in pairs(table.Copy(ply:CS_GetPerma())) do
		if ply:CS_HasPerma(key) then
			apply(ply, key, expire)
		end
	end
end)

local function argsOf(argStr)
	argStr = string.gsub(argStr or "", "\"", "")
	argStr = string.gsub(argStr, "%s*:%s*", ":")

	return string.Explode("%s+", string.Trim(argStr), true)
end

concommand.Add("cs_giveperma", function(ply, cmd, args, argStr)
	if IsValid(ply) and not ply:IsSuperAdmin() then return end

	local a = argsOf(argStr)
	local sid64 = CreditShop.ToSID64(a[1])

	if not sid64 or not a[2] then
		print("[CreditShop] Использование: cs_giveperma <SteamID> <key> [сек]")
		return
	end

	local target = player.GetBySteamID64(sid64)
	local time = tonumber(a[3]) or 0

	if IsValid(target) then
		target:CS_GivePerma(a[2], time)
	else
		savePerma(sid64, a[2], time > 0 and os.time() + time or 0)
	end

	print("[CreditShop] " .. sid64 .. " получил перма-предмет " .. a[2])
end)

concommand.Add("cs_removeperma", function(ply, cmd, args, argStr)
	if IsValid(ply) and not ply:IsSuperAdmin() then return end

	local a = argsOf(argStr)
	local sid64 = CreditShop.ToSID64(a[1])

	if not sid64 or not a[2] then
		print("[CreditShop] Использование: cs_removeperma <SteamID> <key>")
		return
	end

	local target = player.GetBySteamID64(sid64)

	if IsValid(target) then
		target:CS_RemovePerma(a[2])
	else
		removePerma(sid64, a[2])
	end

	print("[CreditShop] у " .. sid64 .. " удалён перма-предмет " .. a[2])
end)
