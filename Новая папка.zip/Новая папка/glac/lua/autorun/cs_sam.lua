-- "addons\\glac\\lua\\autorun\\cs_sam.lua"
-- Команды SAM для кредитов (общий файл - чтобы команды были видны в меню SAM)
--   addcredits <игрок> <кол-во>  - начислить (минус - списать)
--   setcredits <игрок> <кол-во>  - установить баланс
--   credits <игрок>              - узнать баланс
local function addCommands()
	if not sam or not sam.command or not sam.command.new then return end
	if sam.command.get_command and sam.command.get_command("addcredits") then return end

	sam.command.new("addcredits")
		:SetCategory("Credits")
		:SetPermission("addcredits", "superadmin")
		:AddArg("player", {single_target = true})
		:AddArg("number", {hint = "кредиты", round = true})
		:Help("Начислить кредиты (отрицательное число - списать)")
		:OnExecute(function(ply, targets, amount)
			CreditShop.AdminCommand(ply, targets[1], "add", amount)
		end)
	:End()

	sam.command.new("setcredits")
		:SetCategory("Credits")
		:SetPermission("setcredits", "superadmin")
		:AddArg("player", {single_target = true})
		:AddArg("number", {hint = "кредиты", min = 0, round = true})
		:Help("Установить баланс кредитов")
		:OnExecute(function(ply, targets, amount)
			CreditShop.AdminCommand(ply, targets[1], "set", amount)
		end)
	:End()

	sam.command.new("credits")
		:SetCategory("Credits")
		:SetPermission("credits", "admin")
		:AddArg("player", {single_target = true})
		:Help("Баланс кредитов игрока")
		:OnExecute(function(ply, targets)
			CreditShop.AdminCommand(ply, targets[1], "get")
		end)
	:End()
end

hook.Add("PostGamemodeLoaded", "CreditShop.SAM", addCommands)
