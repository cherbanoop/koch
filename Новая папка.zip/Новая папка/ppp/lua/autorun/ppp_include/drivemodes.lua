-- "addons\\ppp\\lua\\autorun\\ppp_include\\drivemodes.lua"
-- N.Y. Noire: восстановлено (в дампе отсутствовало — серверный файл).
-- Режимы управления физическими пилюлями (type = "phys"). В паке сервера
-- сейчас только "ply"-пилюли (хедкрабы/птицы), так что это запас на будущее.
if not SERVER then return end

local function eyeDirs(ply)
	local ang = ply:EyeAngles()
	local flat = Angle(0, ang.y, 0)
	return ang, flat:Forward(), flat:Right()
end

local function moveInput(ply, fwd, right)
	local dir = Vector(0, 0, 0)
	if ply:KeyDown(IN_FORWARD) then dir = dir + fwd end
	if ply:KeyDown(IN_BACK) then dir = dir - fwd end
	if ply:KeyDown(IN_MOVERIGHT) then dir = dir + right end
	if ply:KeyDown(IN_MOVELEFT) then dir = dir - right end
	if dir:LengthSqr() > 0 then dir:Normalize() end
	return dir
end

-- Катится (шары, rollermine)
pk_pills.registerDrive("roll", {
	think = function(ply, ent, opt)
		local phys = ent:GetPhysicsObject()
		if not IsValid(ply) or not IsValid(phys) then return end
		opt = opt or {}
		local _, fwd, right = eyeDirs(ply)
		local dir = moveInput(ply, fwd, right)
		if dir:LengthSqr() > 0 then
			phys:AddAngleVelocity(Vector(dir.y, -dir.x, 0) * (opt.power or 300) * FrameTime() * 10)
			phys:ApplyForceCenter(dir * phys:GetMass() * (opt.force or 300) * FrameTime())
		end
	end,
	key = function(ply, ent, opt, key)
		local phys = ent:GetPhysicsObject()
		if key == IN_JUMP and IsValid(phys) and (opt or {}).jump then
			local tr = util.TraceLine({start = ent:GetPos(), endpos = ent:GetPos() - Vector(0, 0, ent:BoundingRadius() + 5), filter = ent})
			if tr.Hit then phys:ApplyForceCenter(Vector(0, 0, opt.jump * phys:GetMass())) end
		end
	end
})

-- Парит над землёй (манхэк, сканер)
pk_pills.registerDrive("hover", {
	think = function(ply, ent, opt)
		local phys = ent:GetPhysicsObject()
		if not IsValid(ply) or not IsValid(phys) then return end
		opt = opt or {}
		local ang, fwd, right = eyeDirs(ply)
		local dir = moveInput(ply, fwd, right)
		local speed = opt.speed or 300
		local vel = dir * speed

		local h = opt.height or 60
		local tr = util.TraceLine({start = ent:GetPos(), endpos = ent:GetPos() - Vector(0, 0, h * 2), filter = ent})
		if tr.Hit then
			vel.z = (h - (ent:GetPos().z - tr.HitPos.z)) * 4
		else
			vel.z = -speed * 0.5
		end
		if ply:KeyDown(IN_JUMP) then vel.z = speed * 0.6 end
		if ply:KeyDown(IN_DUCK) then vel.z = -speed * 0.6 end

		phys:EnableGravity(false)
		phys:SetVelocity(LerpVector(FrameTime() * 5, phys:GetVelocity(), vel))
		phys:SetAngles(Angle(0, ang.y, 0))
		phys:AddAngleVelocity(-phys:GetAngleVelocity())
	end,
	key = function() end
})

-- Свободный полёт
pk_pills.registerDrive("fly", {
	think = function(ply, ent, opt)
		local phys = ent:GetPhysicsObject()
		if not IsValid(ply) or not IsValid(phys) then return end
		opt = opt or {}
		local ang = ply:EyeAngles()
		local dir = moveInput(ply, ang:Forward(), ang:Right())
		local speed = opt.speed or 400
		local vel = dir * speed
		if ply:KeyDown(IN_JUMP) then vel.z = vel.z + speed * 0.5 end
		if ply:KeyDown(IN_DUCK) then vel.z = vel.z - speed * 0.5 end

		phys:EnableGravity(false)
		phys:SetVelocity(LerpVector(FrameTime() * 3, phys:GetVelocity(), vel))
		phys:SetAngles(Angle(opt.tilt and ang.p or 0, ang.y, 0))
		phys:AddAngleVelocity(-phys:GetAngleVelocity())
	end,
	key = function() end
})

-- Прыжками (банка с хедкрабом и т.п.)
pk_pills.registerDrive("hop", {
	think = function() end,
	key = function(ply, ent, opt, key)
		local phys = ent:GetPhysicsObject()
		if not IsValid(ply) or not IsValid(phys) then return end
		opt = opt or {}
		if key == IN_JUMP or key == IN_FORWARD then
			local _, fwd = eyeDirs(ply)
			phys:ApplyForceCenter((fwd * (opt.forward or 200) + Vector(0, 0, opt.up or 250)) * phys:GetMass())
		end
	end
})

pk_pills.registerDrive("none", {
	think = function() end,
	key = function() end
})
