-- "addons\\ppp\\lua\\autorun\\ppp_pack_core.lua"
-- Retrieved by Urbanichka
require("pk_pills")

AddCSLuaFile()

if SERVER then
    include("ppp_include/drivemodes.lua")
end

pk_pills.packStart("Half-Life 2","base","games/16/hl2.png")

include("ppp_include/pill_headcrabs.lua")
include("ppp_include/pill_birds.lua")
