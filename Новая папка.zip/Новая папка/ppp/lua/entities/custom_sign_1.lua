-- "addons\\ppp\\lua\\entities\\custom_sign_1.lua"
-- Retrieved by Urbanichka
AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_edit"
ENT.PrintName = "SignUrl"
ENT.Author = "Mac"
ENT.Spawnable = true
ENT.AdminSpawnable = true

function ENT:SetupDataTables()
	self:NetworkVar("String", 0, "Url", { KeyName = "url", Edit = { type = "String", order = 1 } })
	self:NetworkVar("Float", 0, "Shadow", { KeyName = "Shadow", Edit = { type = "Float", order = 2 } })
end

if SERVER then
	function ENT:Initialize()
		self:SetModel("models/unioncity2/props_street/shopsign16.mdl")
		self:PhysicsInit(SOLID_VPHYSICS)
		self:SetMoveType(MOVETYPE_VPHYSICS)
		self:SetSolid(SOLID_VPHYSICS)
		--self:SetMaterial("models/gibs/metalgibs/metal_gibs")
		local phys = self:GetPhysicsObject()
		phys:EnableMotion(false)

		self:SetUrl("")
		self:SetShadow(1)
		self:DrawShadow(false)
	end
	return
end

function ENT:Draw()
	self:DrawModel()

	if not DarkRP.InRange(LocalPlayer(), self, 2900) then return end

	if not self.frame then
		self.frame = vgui.Create("DPanel")
		self.frame:SetSize(820, 400)
		self.frame.url = self:GetUrl()
		self.frame:SetPaintedManually(true)
		local cl = math.Clamp(255 * self:GetShadow(),0,255)
		self.frame.cl = Color(cl,cl,cl)
		self.frame.cls = self:GetShadow()
		self.frame.Paint = function(s, w, h)
			surface.DisableClipping(false)
			--draw.RoundedBox(0, 0, 0, w, h, color_white)
			if s.url ~= "" then
				MSD.DrawTexturedRect(0, 0, w, h, MSD.ImgLib.GetMaterial(s.url), s.cl)
			end
		end
		return
	end

	if not IsValid(self.frame) then return end

	if self.frame and self.frame.url ~= self:GetUrl() then
		self.frame.url = self:GetUrl()
	end

	if self.frame and self.frame.cls ~= self:GetShadow() then
		self.frame.cls = self:GetShadow()
		local cl = math.Clamp(255 * self:GetShadow(),0,255)
		self.frame.cl = Color(cl,cl,cl)
	end

	local Pos = self:GetPos()
	local Ang = self:GetAngles()

	Ang:RotateAroundAxis(Ang:Up(), 90)
	Ang:RotateAroundAxis(Ang:Forward(), 90)
	local sc = self:GetModelScale()

	cam.Start3D2D(Pos + Ang:Up() * 3 * sc - Ang:Right() * 38 * sc + Ang:Forward() * -78 * sc, Ang, 0.19 * sc)
		self.frame:PaintManual()
	cam.End3D2D()
end