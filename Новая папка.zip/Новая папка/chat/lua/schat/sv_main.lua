-- "addons\\chat\\lua\\schat\\sv_main.lua"
-- N.Y. Noire: серверная часть SChat (в дампе отсутствовала, восстановлена).
-- Клиент шлёт текст через net 'schat.say' вместо стандартного say,
-- здесь он прогоняется через обычный хук PlayerSay (DarkRP-команды, /me, /looc и т.д.).

util.AddNetworkString('schat.say')
util.AddNetworkString('schat.istyping')
util.AddNetworkString('schat.set_theme')
util.AddNetworkString('schat.set_emojis')

SChat.SAY_DELAY = 0.4
SChat.DATA_DIR = 'schat'
SChat.THEME_FILE = 'schat/server_theme.json'
SChat.EMOJI_FILE = 'schat/server_emojis.json'

if not file.IsDir(SChat.DATA_DIR, 'DATA') then
	file.CreateDir(SChat.DATA_DIR)
end

SChat.serverTheme = file.Read(SChat.THEME_FILE, 'DATA') or ''
SChat.serverEmojis = file.Read(SChat.EMOJI_FILE, 'DATA') or ''

local function SendTheme(target)
	net.Start('schat.set_theme', false)
	net.WriteString(SChat.serverTheme or '')
	if target then net.Send(target) else net.Broadcast() end
end

local function SendEmojis(target)
	net.Start('schat.set_emojis', false)
	net.WriteString(SChat.serverEmojis or '')
	if target then net.Send(target) else net.Broadcast() end
end

-- отправить "чистое" сообщение SChat (если какой-то аддон вернул текст из PlayerSay)
local function Broadcast(ply, channel, text)
	local teamOnly = channel == SChat.TEAM
	local targets = {}

	for _, v in ipairs(player.GetHumans()) do
		local ok, can = pcall(hook.Run, 'PlayerCanSeePlayersChat', text, teamOnly, v, ply)
		if not ok or can ~= false then
			if not teamOnly or v:Team() == ply:Team() then
				targets[#targets + 1] = v
			end
		end
	end

	if #targets == 0 then return end

	net.Start('schat.say', false)
	net.WriteUInt(channel, 4)
	net.WriteString(text)
	net.WriteEntity(ply)
	net.Send(targets)
end

net.Receive('schat.say', function(_, ply)
	if not IsValid(ply) then return end

	local now = RealTime()
	if ply.SChatNextSay and ply.SChatNextSay > now then return end
	ply.SChatNextSay = now + SChat.SAY_DELAY

	local channel = net.ReadUInt(4)
	local text = SChat.CleanupString(net.ReadString() or '')

	if text == '' then return end
	if utf8.len(text) and utf8.len(text) > SChat.MAX_MESSAGE_LEN then
		text = utf8.sub and utf8.sub(text, 1, SChat.MAX_MESSAGE_LEN) or string.sub(text, 1, SChat.MAX_MESSAGE_LEN * 2)
	end

	-- режимы поля ввода: 1 = LOOC, 2 = OOC (команды со слэшем не трогаем)
	local first = string.sub(text, 1, 1)
	if first ~= '/' and first ~= '!' then
		if channel == SChat.TEAM then
			text = '/looc ' .. text
		elseif channel == SChat.OOC then
			text = '// ' .. text
		end
	end

	local teamOnly = false
	local ok, result = pcall(hook.Run, 'PlayerSay', ply, text, teamOnly)

	if not ok then
		ErrorNoHalt('[SChat] PlayerSay error: ' .. tostring(result) .. '\n')
		return
	end

	-- лог в консоль сервера, как у обычного say
	ServerLog(string.format('%s: %s\n', ply:Nick(), text))

	if not isstring(result) or result == '' then return end

	Broadcast(ply, SChat.EVERYONE, result)
end)

net.Receive('schat.istyping', function(_, ply)
	if not IsValid(ply) then return end
	ply:SetNWBool('IsTyping', net.ReadBool() == true)
end)

net.Receive('schat.set_theme', function(_, ply)
	if not IsValid(ply) or not SChat:CanSetServerTheme(ply) then return end

	local data = net.ReadString() or ''
	if #data > 0 and not util.JSONToTable(data) then return end

	SChat.serverTheme = data
	if data == '' then
		file.Delete(SChat.THEME_FILE)
	else
		file.Write(SChat.THEME_FILE, data)
	end

	SendTheme()
	SChat.PrintF('%s изменил тему чата сервера', ply:Nick())
end)

net.Receive('schat.set_emojis', function(_, ply)
	if not IsValid(ply) or not SChat:CanSetServerEmojis(ply) then return end

	local data = net.ReadString() or ''
	if #data > 0 and not util.JSONToTable(data) then return end

	SChat.serverEmojis = data
	if data == '' then
		file.Delete(SChat.EMOJI_FILE)
	else
		file.Write(SChat.EMOJI_FILE, data)
	end

	SendEmojis()
end)

hook.Add('PlayerInitialSpawn', 'schat_SendServerData', function(ply)
	timer.Simple(5, function()
		if not IsValid(ply) then return end
		if SChat.serverTheme ~= '' then SendTheme(ply) end
		if SChat.serverEmojis ~= '' then SendEmojis(ply) end
	end)
end)

hook.Add('PlayerDisconnected', 'schat_ClearTyping', function(ply)
	ply.SChatNextSay = nil
end)
