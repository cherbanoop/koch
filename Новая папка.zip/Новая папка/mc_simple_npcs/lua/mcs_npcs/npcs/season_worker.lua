-- "addons\\mc_simple_npcs\\lua\\mcs_npcs\\npcs\\season_worker.lua"
-- Retrieved by Urbanichka
MCS.Spawns["season_worker"] = {
	name = "Работник магазина",
	model = "models/cityrp/pm/normal/male_05.mdl",
	submat = {
		[4] = "gbskins/outfit/top_54",
		[8] = "gbskins/outfit/pants_54",
		[9] = "gbskins/outfit/boots_3",
		[3] = "models/gmodbest/citizens/facemaps/art_facemap3"
	},
	namepos = 80,
	theme = "Default",
	scale = 1,
	questNPC = false,
	pos = {},
	sequence = "lineidle01",
	uselimit = false,
	skin = 1,
	bgr = {},
	ClModels = {},
	dialogs = {
		[1] = {
			["Line"] = [[У меня перекур, отстань.]],
			["Sound"] = "https://macnco.one/cityrp/seasonsound/season_worker/1.mp3",
			["Answers"] = {
				{"Прошу прощения.", "close",},
			},
		},
		[2] = {
			["Line"] = [[У меня перекур, отстань.]],
			["Sound"] = "https://macnco.one/cityrp/seasonsound/season_worker/1.mp3",
			["Answers"] = {
				{"Это я. За товаром.", 3,},
				{"Прошу прощения.", "close",},
			},
		},
		[3] = {
			["Line"] = [[Господи.. Передай Джо, что это последний раз. Столько мимо кассы проносить - самоубийство!]],
			["Sound"] = "https://macnco.one/cityrp/seasonsound/season_worker/3.mp3",
			["Answers"] = {
				{"Ваш магазин никогда столько бы не заработал сам по себе.", 4,},
				{"Мужик, а где тут мимо кассы? Ты позже официально оформляешь, а 'лишнее' на лапу забираешь.", 4,},
				{"Завались. Радуйся, что тебе платят.", 4,},
				{"Хорошо. Вот, твоя доля.", 5,},
			},
		},
		[4] = {
			["Line"] = [[..Л-ладно, ладно. Заходи через служебный, на стеллаже коробки. Только потише, окей?]],
			["Sound"] = "https://macnco.one/cityrp/seasonsound/season_worker/4.mp3",
			["Answers"] = {
				{"Спасибо.", "MQS Continue quest",},
				{"Окей.", "MQS Continue quest",},
			},
		},
		[5] = {
			["Line"] = [[Твои коробки на стеллаже в служебном. Только тихо.]],
			["Sound"] = "https://macnco.one/cityrp/seasonsound/season_worker/5.mp3",
			["Answers"] = {
				{"Спасибо.", "MQS Continue quest",},
				{"Окей.", "MQS Continue quest",},
			},
		},
		[6] = {
			["Line"] = [[У меня перекур! Дай нервы перебить!]],
			["Sound"] = "https://macnco.one/cityrp/seasonsound/season_worker/6.mp3",
			["Answers"] = {
				{"Это я. За товаром.", 7,},
				{"Прошу прощения.", "close",},
			},
		},
		[7] = {
			["Line"] = [[Всмы- а- ..уже? Господи, что мне делать..?]],
			["Sound"] = "https://macnco.one/cityrp/seasonsound/season_worker/7.mp3",
			["Answers"] = {
				{"Что случилось?", 8,},
				{"Где товар?", 12,},
				{"Ты всё проебал?", 13,},
			},
		},
		[8] = {
			["Line"] = [[Я не зн- ..Уже ведь- ..Обманули! Приехали три человека на чироки, с пушками, сказали что от Джо. Ну я им всё и отдал. Только потом вспомнил, что у Джо фургон..]],
			["Sound"] = "https://macnco.one/cityrp/seasonsound/season_worker/8.mp3",
			["Answers"] = {
				{"Идиот.", 9,},
				{"Не паникуй. Куда они поехали?", 11,},
				{"Ты помнишь, кто это сделал?", 11,},
			},
		},
		[9] = {
			["Line"] = [[Я знаю, не нагнетай! Если бы только кто-то поехал за ними и- ..Точняк, слушай! Давай я тебе покажу куда они примерно двинули, а ко мне никаких претензий?]],
			["Sound"] = "https://macnco.one/cityrp/seasonsound/season_worker/9.mp3",
			["Answers"] = {
				{"Давай.", 10,},
				{"Хорошо.", 10,},
				{"Претензии останутся. Ты облажался.", 10,},
			},
		},
		[10] = {
			["Line"] = [[Только, это.. они не заплатили. Думаю, ты понимаешь, к чему я веду.]],
			["Sound"] = "https://macnco.one/cityrp/seasonsound/season_worker/10.mp3",
			["Answers"] = {
				{"Держи.", "MQS Continue quest",},
				{"Ладно. Ты мне должен.", "MQS Continue quest",},
				{"Ещё один такой косяк - и ты поедешь со мной.", "MQS Continue quest",},
			},
		},
		[11] = {
			["Line"] = [[Не знаю! Они не говорили! Я только видел, куда напра- ..Точно, слушай, я-ж видел! Давай я тебе покажу, а ко мне никаких претензий?]],
			["Sound"] = "https://macnco.one/cityrp/seasonsound/season_worker/11.mp3",
			["Answers"] = {
				{"Давай.", 10,},
				{"Хорошо.", 10,},
				{"Претензии останутся. Ты облажался.", 10,},
			},
		},
		[12] = {
			["Line"] = [[Я- ..Я капитально накосячил. Приехали на чироки три человека, с пушками, сказали что от Джо. Ну я им всё и отдал. Только потом вспомнил, что у Джо фургон..]],
			["Sound"] = "https://macnco.one/cityrp/seasonsound/season_worker/12.mp3",
			["Answers"] = {
				{"Идиот.", 9,},
				{"Не паникуй. Куда они поехали?", 11,},
				{"Ты помнишь, кто это сделал?", 11,},
			},
		},
		[13] = {
			["Line"] = [[Да! То-то есть нет! ..Тьфу! Меня запугали, обманули; три амбала на чироки. Пушками махали, сказали что от Джо - вот я им всё и отдал. Только потом вспомнил, что у Джо фургон..]],
			["Sound"] = "https://macnco.one/cityrp/seasonsound/season_worker/13.mp3",
			["Answers"] = {
				{"Идиот.", 9,},
				{"Не паникуй. Куда они поехали?", 11,},
				{"Ты помнишь, кто это сделал?", 11,},
			},
		},
	}
}