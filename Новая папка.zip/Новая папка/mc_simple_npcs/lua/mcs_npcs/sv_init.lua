--  _______               __          _______  __                   __          _______  ______  ______        
-- |   |   |.---.-..----.|  |.-----. |     __||__|.--------..-----.|  |.-----. |    |  ||   __ \|      |.-----.
-- |       ||  _  ||  __| |_||__ --| |__     ||  ||        ||  _  ||  ||  -__| |       ||    __/|   ---||__ --|
-- |__|_|__||___._||____|    |_____| |_______||__||__|__|__||   __||__||_____| |__|____||___|   |______||_____|
--                                                          |__|      
--
-- N.Y. Noire: серверная часть под клиент 1.4.2 (cl_menu.lua / entities/mcs_npc из дампа сервера).
-- Сетевые строки регистрируются в autorun/mcs_load.lua.
--   MCS.OpenMenu (Entity)                         -> клиент
--   MCS.CloseMenu ()                              <- клиент (только NPC с uselimit)
--   MCS.SrartAnimation (String anim, Bool gest)   <- клиент
--   MCS.Dialogue (UInt15 line, UInt15 answer, Entity)
--   MCS.Formater (UInt15 line, Entity) -> (String line, String sound, Table answers)

-- NPC без pos на этой карте, но с get_pos (дилер Дезз и т.п.) появляются в случайной точке
-- и переезжают раз в MCS.RelocateTime секунд. NPC questNPC без pos спавнят квесты (MQS).
MCS.RelocateTime = isnumber(MCS.RelocateTime) and MCS.RelocateTime or 1800 -- N.Y. Noire: бывало, что сюда попадала таблица

local function applyLook(ent, look)
	if look.submat then
		for k, v in pairs(look.submat) do
			ent:SetSubMaterial(k, v)
		end
	end

	if look.bgr then
		for k, v in pairs(look.bgr) do
			ent:SetBodygroup(k, v)
		end
	end

	if look.skin then
		ent:SetSkin(look.skin)
	end
end

local randomPM = {
	"models/cityrp/pm/normal/male_01.mdl", "models/cityrp/pm/normal/male_02.mdl", "models/cityrp/pm/normal/male_03.mdl",
	"models/cityrp/pm/normal/male_04.mdl", "models/cityrp/pm/normal/male_05.mdl", "models/cityrp/pm/normal/male_06.mdl",
	"models/cityrp/pm/normal/female_01.mdl", "models/cityrp/pm/normal/female_02.mdl", "models/cityrp/pm/normal/female_03.mdl",
}

local function pickModel(model)
	if model and util.IsValidModel(model) then return model end
	return "models/player/group01/male_07.mdl"
end

function MCS.SpawnNPC(npc, uid, pos, ang)
	npc.uselimit = npc.uselimit or false

	local look = npc
	if npc.models and #npc.models > 0 then
		look = npc.models[math.random(#npc.models)]
	end

	local model = look.model or npc.model
	if npc.randompm then
		model = randomPM[math.random(#randomPM)]
	end

	local ent = ents.Create("mcs_npc")
	ent:SetModel(pickModel(model))
	ent:SetModelScale(npc.scale or 1)
	ent:SetPos(pos)
	ent:SetAngles(ang)
	ent:SetNamer(npc.name or "")
	ent:SetUID(uid)
	ent:SetInputLimit(npc.uselimit)
	ent:SetUseType(SIMPLE_USE)
	ent:SetSolid(SOLID_BBOX)
	ent:PhysicsInit(SOLID_BBOX)
	ent:SetMoveType(MOVETYPE_NONE)

	ent.canscare = npc.scare_timer and npc.scare_timer > 0
	ent.checkpos = npc.checkpos
	ent.turntoplayer = npc.turntoplayer
	ent.DefAng = ang
	-- шаг 23: продавцы (vendor = true в таблице NPC). Флаг не попадал на сущность -> DarkRP.PlayerBuyItem
	-- не находил продавца рядом и молча отменял покупку
	ent.vendor = npc.vendor or nil

	applyLook(ent, npc)
	if look ~= npc then applyLook(ent, look) end

	-- склад у NPC (hasinv = {место, название})
	if npc.hasinv then
		ent.inv = McINV and McINV.EmptyInv and McINV.EmptyInv() or {}
		ent.invMaxSpace = npc.hasinv[1]
		ent.NonPickeble = true
	end

	if npc.extras then
		for k, v in pairs(npc.extras) do
			ent[k] = v
		end
	end

	ent:Spawn()

	if npc.hasinv then
		ent:SetSpace(npc.hasinv[1] or 100)
		ent:SetStorageName(npc.hasinv[2] or npc.name or "")
	end

	-- склад улик NYPD — общий с modules/police (Slawer / static_storage)
	if ent.policeEvidnce and DarkRP.Police and DarkRP.Police.GetEvidence then
		ent.inv = DarkRP.Police.GetEvidence()
		ent:SetNWBool("policeEvidnce", true)
	end

	if npc.invisible then
		ent:SetNoDraw(true)
	end

	if npc.noshadow then
		ent:DrawShadow(false)
	end

	local sequence = look.sequence or npc.sequence

	if sequence then
		if istable(sequence) then
			ent.randSequence = sequence
			sequence = table.Random(sequence)
		end

		ent.AutomaticFrameAdvance = true
		ent:SetDefAnimation(sequence)
		ent:ResetSequence(sequence)
		ent:SetCycle(0)
	end

	return ent
end

local function mapPos(npc)
	if not npc.pos then return end
	return npc.pos[string.lower(game.GetMap())] or npc.pos["all"]
end

local function randomPos(npc)
	if not npc.get_pos or #npc.get_pos == 0 then return end
	return npc.get_pos[math.random(#npc.get_pos)]
end

function MCS.SpawnAllNPCs()
	print( "[MCS NPCs] Spawning NPCs" )
	for _, ent in pairs(ents.FindByClass("mcs_npc")) do
		if IsValid(ent) and not ent.IsMQS then
			ent:Remove()
		end
	end

	local count = 0

	for uid, npc in pairs(MCS.Spawns) do
		local spawnpos = mapPos(npc)

		if not spawnpos and not npc.questNPC then
			spawnpos = randomPos(npc)
		end

		if not spawnpos then continue end

		local ok, err = pcall(MCS.SpawnNPC, npc, uid, spawnpos[1], spawnpos[2])
		if not ok then
			print( "[MCS NPCs] Error spawning npc " .. tostring(uid) .. ": " .. tostring(err) )
			continue
		end

		count = count + 1
	end

	print( "[MCS NPCs] Spawned " .. count .. " npcs" )
end

function MCS.FindNPC(uid)
	for _, ent in ipairs(ents.FindByClass("mcs_npc")) do
		if ent:GetUID() == uid then return ent end
	end
end

-- переезд NPC со случайными точками (не трогаем, пока с ним говорят)
timer.Create("MCS.Relocate", tonumber(MCS.RelocateTime) or 1800, 0, function()
	for uid, npc in pairs(MCS.Spawns) do
		if mapPos(npc) or npc.questNPC or not npc.get_pos then continue end

		local ent = MCS.FindNPC(uid)
		if IsValid(ent) and ent.UsingPlayer then continue end
		if IsValid(ent) then ent:Remove() end

		local p = randomPos(npc)
		if p then pcall(MCS.SpawnNPC, npc, uid, p[1], p[2]) end
	end
end)

-- Дилер (кнопка "Dezz" в диалогах): показываем точку на GPS
function MCS.CreateDiller(ply)
	local npc = MCS.Spawns["dezz"]
	if not npc then return end

	local ent = MCS.FindNPC("dezz")

	if not IsValid(ent) then
		local p = mapPos(npc) or randomPos(npc)
		if not p then return end
		ent = MCS.SpawnNPC(npc, "dezz", p[1], p[2])
	end

	if IsValid(ply) and IsValid(ent) and McPhone and McPhone.ToggleGPS then
		McPhone.ToggleGPS(ply, npc.name or "Дилер", ent:GetPos())
	end

	return ent
end

concommand.Add("mcs_npcrespawn", function(ply)
	if IsValid(ply) and not ply:IsSuperAdmin() then return end
	MCS.SpawnAllNPCs()
end)

hook.Add("PostCleanupMap", "MCS.PostCleanupMap", function()
	MCS.SpawnAllNPCs()
end)

-- Fix for addons that add custom animations, to avoid floating animation. We need to respawn npcs after loading there models for the first time
timer.Simple(5, function() MCS.SpawnAllNPCs() end)
timer.Simple(10, function() MCS.SpawnAllNPCs() end)

concommand.Add("mcs_setup", function(ply)
	if not IsValid(ply) or not ply:IsSuperAdmin() then return end
	net.Start("MCS.SetupMenu")
	net.Send(ply)
end)

hook.Add("PlayerUse", "MCS.LastNPC", function(ply, ent)
	if IsValid(ent) and ent.SimpleNPC then
		ply.MCSLastNPC = ent
	end
end)

local function playerNPC(ply)
	local npc = ply.MCSInUse
	if not IsValid(npc) then npc = ply.MCSLastNPC end
	if not IsValid(npc) or not npc.SimpleNPC then return end
	if npc:GetPos():DistToSqr(ply:GetPos()) > 300 * 300 then return end
	return npc
end

local function runAddon(fa, ply, npc, data)
	local addon = MCS.AddonList[fa]
	if not addon or not addon["enabled"] or not addon["function_sv"] then return end

	local ok, err = pcall(addon["function_sv"], ply, npc, data)
	if not ok then
		print( "[MCS NPCs] " .. tostring(fa) .. " error: " .. tostring(err) )
	end
end

net.Receive("MCS.Dialogue", function(l, ply)
	if MCS.SpamBlock(ply, 0.5) then return end
	local lid = net.ReadUInt(15)
	local aid = net.ReadUInt(15)
	local npc = net.ReadEntity()

	if not aid or not lid or not IsValid(npc) or not npc.GetUID or not MCS.Spawns[npc:GetUID()] then return end
	if npc:GetPos():DistToSqr(ply:GetPos()) > 300 * 300 then return end

	local dialog = MCS.Spawns[npc:GetUID()].dialogs

	if not dialog or not dialog[lid] then return end

	local fa = " "
	local data

	if aid == 0 and dialog[lid]["CallBack"] then
		fa = dialog[lid]["CallBack"].name
		data = dialog[lid]["CallBack"].data
	else
		if not dialog[lid]["Answers"] or not dialog[lid]["Answers"][aid] or not dialog[lid]["Answers"][aid][2] then return end

		fa = dialog[lid]["Answers"][aid][2]
		if istable(fa) then
			data = fa.data
			fa = fa.id
		end
	end

	if not fa then return end

	runAddon(fa, ply, npc, data)
end)

-- строка диалога, которую собирает сервер (скупка у Дезза, разборка машин)
net.Receive("MCS.Formater", function(l, ply)
	if MCS.SpamBlock(ply, 0.3) then return end
	local lid = net.ReadUInt(15)
	local npc = net.ReadEntity()

	if not IsValid(npc) or not npc.GetUID or not MCS.Spawns[npc:GetUID()] then return end
	if npc:GetPos():DistToSqr(ply:GetPos()) > 300 * 300 then return end

	local dialog = MCS.Spawns[npc:GetUID()].dialogs
	dialog = dialog and dialog[lid]
	if not dialog or not dialog["Formater_SV"] then return end

	local ok, line, snd, answers = pcall(dialog["Formater_SV"], ply, npc)
	if not ok then
		print( "[MCS NPCs] Formater_SV error: " .. tostring(line) )
		line, snd, answers = "...", "", nil
	end

	local clean = {}
	for k, ans in ipairs(istable(answers) and answers or {{"...", "close"}}) do
		if istable(ans) then
			clean[k] = {tostring(ans[1] or "..."), istable(ans[2]) and ans[2] or (ans[2] or "close")}
		end
	end

	net.Start("MCS.Formater")
		net.WriteString(tostring(line or "..."))
		net.WriteString(tostring(snd or ""))
		net.WriteTable(clean)
	net.Send(ply)
end)

net.Receive("MCS.CloseMenu", function(l, ply)
	local npc = ply.MCSInUse
	ply.MCSInUse = nil
	if not IsValid(npc) then return end
	if npc.UsingPlayer == ply then npc.UsingPlayer = nil end

	if npc.LastAnim and npc.LastAnim + 1 > CurTime() then return end
	MCS.PlayDefAnimation(npc)
end)

net.Receive("MCS.SrartAnimation", function(l, ply)
	if MCS.SpamBlock(ply, 0.1) then return end
	local anim = net.ReadString()
	local gesture = net.ReadBool()
	local npc = playerNPC(ply)
	if not npc or not anim or anim == "" then return end

	local seq = npc:LookupSequence(anim)
	if not seq or seq < 0 then return end

	if gesture and npc.AddGestureSequence then
		pcall(npc.AddGestureSequence, npc, seq, true)
		return
	end

	npc:ResetSequence(seq)
	npc:SetCycle(0)
	npc.LastAnim = CurTime()
end)

hook.Add("PlayerDisconnected", "MCS.FreeNPC", function(ply)
	local npc = ply.MCSInUse
	if IsValid(npc) and npc.UsingPlayer == ply then npc.UsingPlayer = nil end
end)

function MCS.SpamBlock(ply, t)
	if not IsValid(ply) then return true end
	if ply.MCSCkeck and ply.MCSCkeck + t > CurTime() then return true end
	ply.MCSCkeck = CurTime()

	return false
end
