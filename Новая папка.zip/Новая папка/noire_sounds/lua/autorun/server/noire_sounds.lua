-- N.Y. Noire — шаг 35. Звуки игрока (sound/player/*): курение, зажигалка, бонг, вещества, дыхание, шаги.
-- Игроки скачивают их при входе (resource.AddFile). Если эти звуки уже есть в Workshop-коллекции сервера - не мешает.
-- exhale.wav и breath_light.wav сделаны громче (+33 и +14 дБ), остальные - как в архиве.
local files = {
	"bong.wav", "breath_heavy.wav", "breath_light.wav", "breath_medium.wav",
	"drink.mp3", "drop.mp3", "eat.mp3", "exhale.wav", "heal.mp3",
	"lighter.wav", "lighter2.wav", "lighter_off.wav", "lighter_on.wav",
	"pickup.mp3", "pills_here.mp3", "soda.mp3",
	"use/snort.wav", "use/syringe.wav",
}

for i = 1, 10 do
	files[#files + 1] = "sfx/step" .. i .. ".wav"
end

for _, f in ipairs(files) do
	resource.AddFile("sound/player/" .. f)
end
