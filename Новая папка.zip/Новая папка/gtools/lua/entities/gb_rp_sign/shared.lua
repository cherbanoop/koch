-- "addons\\gtools\\lua\\entities\\gb_rp_sign\\shared.lua"
-- Retrieved by Urbanichka
ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Spawned Sign"
ENT.Author = "Mac"
ENT.Spawnable = false
ENT.AdminSpawnable = true

function ENT:SetupDataTables()
	self:NetworkVar("String", 0, "Text")
	self:NetworkVar("Int", 0, "Type")
	self:NetworkVar("Int", 1, "Font")
end