-- "addons\\gmodlamd\\lua\\mmd\\core\\sh_init.lua"
-- Retrieved by Urbanichka
print(1)