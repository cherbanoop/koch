-- "addons\\gmodlamd\\lua\\mmd\\configs\\sh_config.lua"
-- Retrieved by Urbanichka
print("")