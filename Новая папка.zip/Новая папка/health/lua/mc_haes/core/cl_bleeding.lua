-- N.Y. Noire, шаг 44: капли крови у кровоточащего (по присланному bleedingg.lua). Сервер - sv_bleeding.lua.
local function spawnBloodDrops(ply)
	if not IsValid(ply) or not ply:IsPlayer() or not ply:Alive() then return end

	local emitter = ParticleEmitter(ply:GetPos())
	if not emitter then return end

	local attach = ply:LookupAttachment("stomach")
	local pos = ply:GetPos() + Vector(0, 0, 20)

	if attach and attach > 0 then
		local att = ply:GetAttachment(attach)
		if att and att.Pos then pos = att.Pos end
	else
		local chest = ply:LookupAttachment("chest")

		if chest and chest > 0 then
			local att = ply:GetAttachment(chest)
			if att and att.Pos then pos = att.Pos - Vector(0, 0, 15) end
		end
	end

	emitter:SetPos(pos)

	for i = 1, 4 do
		local particle = emitter:Add("decals/blood1", pos + Vector(0, 0, -i * 3))

		if particle then
			particle:SetVelocity(VectorRand() * 8 + Vector(0, 0, -90))
			particle:SetLifeTime(0)
			particle:SetDieTime(math.Rand(0.8, 1.5))
			particle:SetStartAlpha(180)
			particle:SetEndAlpha(0)
			particle:SetStartSize(math.Rand(2, 4))
			particle:SetEndSize(1)
			particle:SetRoll(math.Rand(-10, 10))
			particle:SetColor(180, 20, 20)
			particle:SetGravity(Vector(0, 0, -250))
		end
	end

	emitter:Finish()
end

net.Receive("MES.BleedDrops", function()
	spawnBloodDrops(net.ReadEntity())
end)
