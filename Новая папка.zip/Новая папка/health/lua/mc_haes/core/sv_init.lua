-- "addons\\health\\lua\\mc_haes\\core\\sv_init.lua"
-- Медицина: осмотр и помощь аптечкой, СЛР со скиллчеком, реанимация.
--   Аптечка (med_kit - парамедик, med_pd - пожарные/полиция): ЛКМ -> "mes.check" k (MES.List), ПКМ -> "mes.apply" k (MES.ListHeal)
--     MES.ListHeal[k] = {название, заряды Clip1, fn(medic, ply, rag), звук, /me, длительность, [условие fn(ply)], [отказ]}
--     MES.ListHealRest - только парамедик (TEAM_REF) с рангом FDNY >= MES.Config.RestRank (как и в меню клиента)
--   Пациент - игрок / тело без сознания (rag.player) / труп (rag.SelfPlayer, только СЛР) перед медиком; никого - на себя.
--   СЛР (MES.SLR): компрессии (MES.ListHeal[5]) -> таймер (миниигра перенесена в отмычку) -> шанс реанимации (MES.Revive).
--     Тело можно откачать MES.Config.CPRTime сек. после смерти и MES.Config.CPRTries попыток; rag.crithit - никогда.
--     Тату b9 - СЛР без аптечки (/slr_tatoo из меню взаимодействия с телом).
--   Реанимированный приходит в себя в своём теле, с тату и навыками (ply.MES_Revive, sv_tattoo.lua).
-- Скиллчек: сервер -> UInt2 0, UInt5 начало зоны, UInt5 ширина (из 20), UInt12 сек., Float старт, Bool красная схема; UInt2 1 - конец.
--   Клиент -> Float позиция стрелки (1 - cos(t * 4)) / 2, Float время нажатия.
-- Кровь/кровотечение/переломы/шок/холод - sv_damage.lua, вещества и курение - sv_drugs.lua.
local pmeta = FindMetaTable("Player")


MES.Config = MES.Config or {}

local cfg = MES.Config
cfg.Range = cfg.Range or 110 -- до пациента
cfg.ActRange = cfg.ActRange or 150 -- отойти дальше - действие прервётся
cfg.Kits = cfg.Kits or {["med_kit"] = true, ["med_pd"] = true}
cfg.DeadOnly = cfg.DeadOnly or {[5] = true} -- MES.ListHeal, что можно делать с трупом (СЛР)
cfg.RestRank = cfg.RestRank or 3
cfg.CPRTime = cfg.CPRTime or 180 -- сек. после смерти, пока можно откачать
cfg.CPRTries = cfg.CPRTries or 9 -- попыток на одно тело
cfg.CPRDuration = cfg.CPRDuration or 10 -- компрессии по тату b9 (у аптечки - MES.ListHeal[5][6])
cfg.CPRZone = cfg.CPRZone or 2 -- ширина зоны скиллчека (+1 парамедику, +1 с рангом RestRank)
cfg.CPRCheckTime = cfg.CPRCheckTime or 3
cfg.CPRChance = cfg.CPRChance or {hit = 55, medic = 70, miss = 10} -- % реанимации: попал / попал парамедик / промах
cfg.ReviveHP = cfg.ReviveHP or {7, 20}
cfg.ReviveUncon = cfg.ReviveUncon or {30, 60}
cfg.ReviveBlood = cfg.ReviveBlood or 30
cfg.ReviveMoney = cfg.ReviveMoney or 150 -- парамедику за спасённую жизнь
cfg.ReviveKarma = cfg.ReviveKarma or 3
cfg.HealKarma = cfg.HealKarma or 1 -- помощь другому, не чаще HealKarmaDelay
cfg.HealKarmaDelay = cfg.HealKarmaDelay or 60

--[[---------------------------------------------------------------------------
Утилиты
---------------------------------------------------------------------------]]
local function ragPos(rag)
	local phys = rag:GetPhysicsObjectNum(0)
	return IsValid(phys) and phys:GetPos() or rag:GetPos()
end

MES.RagPos = ragPos

function MES.Me(ply, text)
	local cmd = DarkRP.getChatCommand and DarkRP.getChatCommand("me")
	if cmd and cmd.callback then cmd.callback(ply, text) end
end

-- /me о себе: "вводит препарат человеку" -> "вводит препарат себе"
local function selfText(text)
	return (text:gsub(" на человека", " на себя"):gsub(" человеку", " себе"):gsub(" человека", " себя"))
end

local function canAct(ply)
	if not IsValid(ply) or not ply:Alive() then return false end
	if ply:getDarkRPVar("HandCuffed") or ply:getDarkRPVar("Arrested") or ply:getDarkRPVar("unconscious") then return false end

	return true
end

MES.CanAct = canAct

local function freeze(ply, time)
	if time then
		ply:SetDarkRPVar("rice_anim_n", "")
		ply:SetDarkRPVar("rice_anim", CurTime() + time)
	elseif ply:getDarkRPVar("rice_anim") then
		ply:SetDarkRPVar("rice_anim", nil)
	end

	-- шаг 24: снять позу roofidle1 (конец / прерывание действия)
	if not time and DarkRP.StopRoofIdle then DarkRP.StopRoofIdle(ply) end
end

MES.Freeze = freeze

function MES.IsMedic(ply, rank)
	if not IsValid(ply) or ply:Team() ~= (TEAM_REF or 13) then return false end
	if not rank then return true end

	return (tonumber(MRS and MRS.GetPlyRank and MRS.GetPlyRank(ply, "FDNY")) or 0) >= rank
end

function MES.GetKit(ply)
	local wep = ply:GetActiveWeapon()
	if IsValid(wep) and cfg.Kits[wep:GetClass()] then return wep end
end

-- кто перед медиком: ply, rag. Труп без хозяина (возродился/вышел) - nil, rag
function MES.GetPatient(medic, range)
	local src = medic:GetShootPos()
	local dst = src + medic:GetAimVector() * (range or cfg.Range)
	local tr = util.TraceLine({start = src, endpos = dst, filter = medic, mask = MASK_SHOT})

	if not IsValid(tr.Entity) then
		tr = util.TraceHull({start = src, endpos = dst, filter = medic, mask = MASK_SHOT, mins = Vector(-6, -6, -6), maxs = Vector(6, 6, 6)})
	end

	local ent = tr.Entity
	if not IsValid(ent) then return end

	if ent:IsPlayer() then
		if ent:Alive() then return ent end
		return
	end

	-- каталка / кресло
	if IsValid(ent.Stretcher) then ent = ent.Stretcher end

	-- в салоне simfphys - ближайший к точке взгляда (IsVehicle у simfphys тоже true)
	if ent.IsSimfphyscar and ent.GetSeats then
		local best, bd

		for _, seat in ipairs(ent:GetSeats()) do
			local p = IsValid(seat) and seat:GetDriver()
			if not IsValid(p) then continue end

			local d = p:WorldSpaceCenter():DistToSqr(tr.HitPos)

			if d < 6400 and (not bd or d < bd) then
				best, bd = p, d
			end
		end

		return best
	end

	if ent:IsVehicle() and IsValid(ent:GetDriver()) then
		return ent:GetDriver()
	end

	if ent:GetClass() ~= "prop_ragdoll" then return end

	local ply = ent.player
	if IsValid(ply) and ply:Alive() and ply.UnconRagdoll == ent then return ply, ent end

	if ent.IsDeathRagdoll then
		ply = ent.SelfPlayer
		if IsValid(ply) and not ply:Alive() and ply.DeathRagdoll == ent then return ply, ent end

		return nil, ent
	end
end

local function log(medic, ply, msg)
	DarkRP.log("medic", medic, ply ~= medic and ply or nil, msg, Color(120, 200, 255))
end

local function healKarma(medic, ply)
	if medic == ply or not medic.addKarma then return end
	if (medic.MES_KarmaTime or 0) > CurTime() then return end

	medic.MES_KarmaTime = CurTime() + cfg.HealKarmaDelay
	medic:addKarma(cfg.HealKarma)
end


--[[---------------------------------------------------------------------------
Осмотр
---------------------------------------------------------------------------]]
-- раны по оружию (sv_damage.lua пишет ply.MES_Wounds[класс оружия | "bullet" | "slash" | "club" | "burn" | "blast" | "fall" | "vehicle"] = n)
function MES.WoundLines(ply, medic)
	local lines = {}
	local pro = MES.IsMedic(medic)

	for class, n in pairs(ply.MES_Wounds or {}) do
		local g = MES.gunz[class]
		local m = MES.melee[class]

		if g then
			local txt = pro and ("Огнестрельное ранение " .. g[1] .. " (" .. g[2] .. ")") or "Огнестрельное ранение"
			table.insert(lines, txt .. (n > 1 and " - " .. n or ""))
		elseif m then
			table.insert(lines, n > 1 and string.format(m[2], n) or m[1])
		elseif class == "bullet" then
			table.insert(lines, "Огнестрельное ранение" .. (n > 1 and " - " .. n or ""))
		elseif class == "slash" then
			table.insert(lines, "Резаные раны" .. (n > 1 and " - " .. n or ""))
		elseif class == "club" then
			table.insert(lines, "Ушибы, ссадины" .. (n > 1 and " - " .. n or ""))
		elseif class == "burn" then
			table.insert(lines, "Ожоги" .. (n > 1 and " - " .. n or ""))
		elseif class == "blast" then
			table.insert(lines, "Осколочные ранения, контузия")
		elseif class == "fall" then
			table.insert(lines, "Ушибы от падения")
		elseif class == "vehicle" then
			table.insert(lines, "Травмы, характерные для ДТП")
		end
	end

	return lines
end

concommand.Add("mes.check", function(medic, cmd, args)
	if not IsValid(medic) or DarkRP.NetDelay(medic, "MES.Check", 1) then return end
	if not canAct(medic) or not MES.GetKit(medic) then return end

	local k = tonumber(args[1] or "")
	local v = k and MES.List[k]
	if not v then return end

	local ply, rag = MES.GetPatient(medic)

	if IsValid(rag) and not IsValid(ply) then
		DarkRP.ChatNotify(medic, 1, "Тело уже холодное, тут ничем не помочь.")
		return
	end

	ply = ply or medic

	if ply ~= medic and (medic.MES_LastCheck ~= ply or (medic.MES_LastCheckTime or 0) < CurTime()) then
		medic.MES_LastCheck = ply
		medic.MES_LastCheckTime = CurTime() + 30
		MES.Me(medic, "осматривает человека")
	end

	local ok, res = pcall(v[3], ply, v[1], medic)
	if not ok then res = "Не удалось осмотреть" end

	DarkRP.ChatNotify(medic, 0, (ply == medic and "(Вы) " or "") .. v[2] .. ": " .. tostring(res))

	if k == 1 then
		for _, line in ipairs(MES.WoundLines(ply, medic)) do
			DarkRP.ChatNotify(medic, 2, line)
		end
	end
end)

--[[---------------------------------------------------------------------------
Помощь
---------------------------------------------------------------------------]]
-- пока тело качают - не возрождается само
local function holdDeath(ply, time)
	ply.MES_CPRUntil = CurTime() + time

	if ply.DeathStart then
		ply.DeathDuration = math.max(ply.DeathDuration or 0, CurTime() - ply.DeathStart + time + 15)
	end
end

hook.Add("PlayerDeathThink", "MES.CPR", function(ply)
	if ply.MES_CPRUntil and ply.MES_CPRUntil > CurTime() then return true end
end)

function MES.CanCPR(ply, rag)
	if not IsValid(ply) or ply:Alive() then return false, "СЛР ничем не поможет" end
	if not IsValid(rag) or ply.DeathRagdoll ~= rag or not rag.IsDeathRagdoll then return false, "Тело уже холодное, тут ничем не помочь." end
	if rag.crithit or (rag.CPRCount or 0) >= cfg.CPRTries then return false, "Тело уже холодное, тут ничем не помочь." end
	if CurTime() - (rag.DeathTime or 0) > cfg.CPRTime then return false, "Пострадавший мёртв." end
	if not ply:getDarkRPVar("character") then return false, "Пострадавший мёртв." end

	return true
end

function MES.Heal(medic, k, kit)
	local v = MES.ListHeal[k]
	if not v or not canAct(medic) then return end

	if MES.ListHealRest[k] and not MES.IsMedic(medic, cfg.RestRank) then
		DarkRP.notify(medic, 1, 4, "Вам не хватает квалификации")
		return
	end

	local ply, rag = MES.GetPatient(medic)

	if IsValid(rag) and not IsValid(ply) then
		DarkRP.notify(medic, 1, 4, "Тело уже холодное, тут ничем не помочь.")
		return
	end

	ply = ply or medic

	local dead = not ply:Alive()

	if dead and not cfg.DeadOnly[k] then
		DarkRP.notify(medic, 1, 4, "Пострадавший мёртв. Поможет только СЛР")
		return
	end

	if v[7] and not v[7](ply) then
		DarkRP.notify(medic, 1, 4, v[8] or "Сейчас в этом нет необходимости")
		return
	end

	if dead then
		local ok, why = MES.CanCPR(ply, rag)

		if not ok then
			DarkRP.notify(medic, 1, 4, why)
			return
		end
	end

	if kit and kit:Clip1() < (v[2] or 0) then
		DarkRP.notify(medic, 1, 4, "В аптечке не хватает материалов")
		return
	end

	local time = v[6] or 2
	local target = IsValid(rag) and rag or ply

	if dead then holdDeath(ply, time + cfg.CPRCheckTime + 5) end

	local started = DarkRP.ProgressAction(medic, target, time, cfg.ActRange, function()
		freeze(medic)

		if kit and (not IsValid(kit) or kit:GetOwner() ~= medic or kit:Clip1() < (v[2] or 0)) then
			DarkRP.notify(medic, 1, 4, "В аптечке не хватает материалов")
			return
		end

		if not IsValid(ply) or ply:Alive() == dead then
			DarkRP.notify(medic, 1, 4, dead and "Уже поздно" or "Пострадавший умер")
			return
		end

		if not dead and IsValid(rag) and ply.UnconRagdoll ~= rag then rag = nil end

		if kit then kit:SetClip1(kit:Clip1() - (v[2] or 0)) end

		v[3](medic, ply, IsValid(rag) and rag or nil)

		if not dead then healKarma(medic, ply) end
		log(medic, ply, "применил \"" .. v[1] .. "\"" .. (ply == medic and " на себе" or ""))
		hook.Run("MES.Healed", medic, ply, k)
	end, function()
		freeze(medic)
		DarkRP.notify(medic, 1, 3, "Действие прервано")
	end)

	if not started then return end

	-- шаг 21: анимация (sv_medanims.lua) - на колено к лежащему, жест к стоящему / на себе
	if MES.PlayHealAnim then
		MES.PlayHealAnim(medic, ply, IsValid(rag) and rag or nil, time, dead)
	else
		freeze(medic, time)
	end

	if v[4] then medic:EmitSound(v[4], 60) end
	if v[5] then MES.Me(medic, ply == medic and selfText(v[5]) or v[5]) end
end

concommand.Add("mes.apply", function(medic, cmd, args)
	if not IsValid(medic) or DarkRP.NetDelay(medic, "MES.Apply", 1) then return end

	local kit = MES.GetKit(medic)
	if not kit then return end

	MES.Heal(medic, tonumber(args[1] or ""), kit)
end)

--[[---------------------------------------------------------------------------
СЛР и реанимация
---------------------------------------------------------------------------]]
function MES.SLR(medic, ply, rag)
	local ok, why = MES.CanCPR(ply, rag)

	if not ok then
		DarkRP.notify(medic, 1, 4, why)
		return
	end

	rag.CPRCount = (rag.CPRCount or 0) + 1
	holdDeath(ply, cfg.CPRCheckTime + 5)

	-- N.Y. Noire: миниигра убрана (перенесена в отмычку) — СЛР идёт по времени
	-- шаг 34: надписи о ходе и результате СЛР убраны (результат видно осмотром аптечкой, ЛКМ)
	-- DarkRP.notify(medic, 0, cfg.CPRCheckTime, "Вы делаете непрямой массаж сердца...")
	if MES.HoldAnim and MES.AnimConfig then MES.HoldAnim(medic, MES.AnimConfig.CPR, cfg.CPRCheckTime) end

	timer.Simple(cfg.CPRCheckTime, function()
		local hit = true
		if not IsValid(medic) or not medic:Alive() then return end
		if not IsValid(ply) or ply:Alive() or not IsValid(rag) or ply.DeathRagdoll ~= rag then return end

		if ragPos(rag):DistToSqr(medic:GetPos()) > cfg.ActRange ^ 2 then
			DarkRP.notify(medic, 1, 4, "Вы отошли от пострадавшего")
			return
		end

		local chance = hit and (MES.IsMedic(medic) and cfg.CPRChance.medic or cfg.CPRChance.hit) or cfg.CPRChance.miss

		if math.random(100) > chance then
			-- шаг 34: без надписей "Пульс не появился. Продолжайте СЛР" / "Пульс так и не появился..."
			return
		end

		MES.Revive(ply, rag, medic)
	end)
end

hook.Add("DarkRP.PlayerSpawnPos", "MES.Revive", function(ply)
	if ply.MES_Revive and ply.MES_RevivePos then return ply.MES_RevivePos end
end)

-- реанимировать: приходит в себя в своём теле (full - админ: сразу на ногах и здоров)
function MES.Revive(ply, rag, medic, full)
	if not IsValid(ply) or ply:Alive() or not ply:getDarkRPVar("character") then return false end

	rag = IsValid(rag) and rag or ply.DeathRagdoll

	if IsValid(rag) and (not rag.IsDeathRagdoll or rag.SelfPlayer ~= ply) then rag = nil end

	local pos = IsValid(rag) and ragPos(rag) or ply.DeathPos

	ply.MES_Revive = true
	ply.MES_RevivePos = pos
	ply.MES_CPRUntil = nil

	ply:Spawn()

	ply.MES_Revive = nil
	ply.MES_RevivePos = nil

	if not ply:Alive() then return false end

	DarkRP.UIEffect(ply, "unNLR")

	if full then
		if IsValid(rag) then rag:Remove() end

		-- шаг 25: поднимается с земли (zombie_slump_rise_01)
		if DarkRP.PlayGetUp then DarkRP.PlayGetUp(ply, 0.15) end

		MES.SetBlood(ply, 100)

		timer.Simple(0.1, function()
			if IsValid(ply) and ply:Alive() then ply:SetHealth(ply:GetMaxHealth()) end
		end)
	else
		ply:SetHealth(math.random(cfg.ReviveHP[1], cfg.ReviveHP[2]))
		MES.SetBlood(ply, math.max(MES.GetBlood(ply), cfg.ReviveBlood))

		if IsValid(rag) then
			ply:Ragdollize(math.random(cfg.ReviveUncon[1], cfg.ReviveUncon[2]), true, rag)
		else
			ply:Ragdollize(math.random(cfg.ReviveUncon[1], cfg.ReviveUncon[2]), true)
		end

		DarkRP.ChatNotify(ply, 4, "Вас вернули с того света. Вы очнётесь через пару минут")
	end

	if IsValid(medic) and medic ~= ply then
		-- шаг 34: надпись "Пульс появился! Вы спасли человеку жизнь" убрана (премия - как раньше)
		-- DarkRP.notify(medic, 0, 6, "Пульс появился! Вы спасли человеку жизнь")

		if medic.addKarma then medic:addKarma(cfg.ReviveKarma) end

		if MES.IsMedic(medic) and cfg.ReviveMoney > 0 and medic.addMoney then
			medic:addMoney(cfg.ReviveMoney)
			DarkRP.notify(medic, 0, 6, "Премия за спасённую жизнь: " .. DarkRP.formatMoney(cfg.ReviveMoney))
		end
	end

	DarkRP.log("revive", IsValid(medic) and medic or ply, IsValid(medic) and medic ~= ply and ply or nil, full and "реанимировал (админ)" or "реанимировал", Color(120, 255, 160))
	hook.Run("MES.Revived", ply, medic, full)

	return true
end

-- СЛР без аптечки (тату b9): меню взаимодействия с телом -> /slr_tatoo
local function tattooCPR(ply)
	if not MCR or not MCR.HasTatoo or not MCR.HasTatoo(ply, "b9") then return "" end
	if not canAct(ply) or DarkRP.NetDelay(ply, "MES.SLR", 2) then return "" end

	local target, rag = MES.GetPatient(ply, cfg.Range + 20)

	if not IsValid(rag) then
		DarkRP.notify(ply, 1, 4, "Посмотрите на тело")
		return ""
	end

	local ok, why = MES.CanCPR(target, rag)

	if not ok then
		DarkRP.notify(ply, 1, 4, why)
		return ""
	end

	holdDeath(target, cfg.CPRDuration + cfg.CPRCheckTime + 5)

	local started = DarkRP.ProgressAction(ply, rag, cfg.CPRDuration, cfg.ActRange, function()
		freeze(ply)
		MES.SLR(ply, target, rag)
	end, function()
		freeze(ply)
		DarkRP.notify(ply, 1, 3, "Действие прервано")
	end)

	if not started then return "" end

	if MES.HoldAnim and MES.AnimConfig then MES.HoldAnim(ply, MES.AnimConfig.CPR, cfg.CPRDuration) else freeze(ply, cfg.CPRDuration) end
	ply:EmitSound("metromod/breath_1.wav", 60)
	MES.Me(ply, "приступает к СЛР")

	return ""
end

local function registerCommands()
	if not DarkRP or not DarkRP.defineChatCommand then return end
	DarkRP.defineChatCommand("slr_tatoo", tattooCPR, 2)
end

registerCommands()
hook.Add("PostGamemodeLoaded", "MES.Commands", registerCommands)

-- админ: поднять мёртвого / привести в сознание (SAM "revive", autorun/mes_sam.lua)
function MES.AdminRevive(ply)
	if not IsValid(ply) then return false end

	if not ply:Alive() then
		return MES.Revive(ply, nil, nil, true)
	end

	if ply.IsUncon and ply:IsUncon() then ply:UnRagdollize() end

	for _, stat in ipairs({"bleeding", "fracture", "fracturearm", "shock", "overdose"}) do
		if ply:getDarkRPVar(stat) then ply:RemoveTempStat(stat) end
	end

	timer.Remove(ply:UserID() .. "overdose")
	MES.SetBlood(ply, 100)
	if MES.SetCold then MES.SetCold(ply, 0) end
	ply:SetHealth(ply:GetMaxHealth())

	return true
end

--[[---------------------------------------------------------------------------
шаг 54: помощь в больнице (NPC "Терапевт" civilian_med, mcs_npcs/npcs/hospital.lua)
  "Мне нужна медицинская помощь." (квестов MQS heal_all/heal_gov нет) -> MCS "DarkRP Лечение" -> MES.HospitalCare:
    прогресс HospitalTime сек. у стойки, оплата HospitalPrice (госслужащим бесплатно - HospitalFree) -> MES.HospitalTreat.
  "Подозреваемому нужно оказать медицинскую помощь." (полицейский ведёт задержанного) -> Police.Arrest mode 0
    (modules/police/sv_init.lua) -> MES.HospitalTreat задержанному, бесплатно.
  MES.HospitalTreat: здоровье, кровь, кровотечение, боль, шок, холод, передозировка, раны (для осмотра).
---------------------------------------------------------------------------]]
cfg.HospitalPrice = cfg.HospitalPrice or 100
cfg.HospitalTime = cfg.HospitalTime or 6
cfg.HospitalRange = cfg.HospitalRange or 200 -- отойти от терапевта дальше - лечение прервётся
cfg.HospitalFree = cfg.HospitalFree or function(ply)
	return ply:isCP() or ply:isEMS() or ply:isMayor()
end

function MES.HospitalTreat(ply)
	if not IsValid(ply) or not ply:Alive() then return false end

	for _, stat in ipairs({"bleeding", "fracture", "fracturearm", "shock", "cough"}) do
		if ply:getDarkRPVar(stat) or (ply.TempStats and ply.TempStats[stat]) then ply:RemoveTempStat(stat) end
	end

	if MES.StopBleeding then MES.StopBleeding(ply) end

	if MES.ClearOverdose then
		MES.ClearOverdose(ply)
	else
		timer.Remove(ply:UserID() .. "overdose")
		if ply:getDarkRPVar("overdose") then ply:SetSelfDarkRPVar("overdose", nil) end
	end

	if MES.ClearPain then MES.ClearPain(ply) end
	if MES.SetCold then MES.SetCold(ply, 0) end

	MES.SetBlood(ply, 100)
	ply:SetHealth(math.max(ply:Health(), ply:GetMaxHealth()))
	ply.MES_Wounds = nil
	ply.MES_Recent = nil

	-- "время прошло": экран из темноты
	ply:ScreenFade(SCREENFADE.IN, color_black, 1.5, 0.3)

	hook.Run("MES.HospitalTreated", ply)

	return true
end

function MES.HospitalCare(ply, npc)
	if not IsValid(ply) or not ply:Alive() or not IsValid(npc) then return end

	if not MES.NeedsTreatment(ply) then
		DarkRP.notify(ply, 0, 4, "Вам не требуется медицинская помощь")
		return
	end

	local free = cfg.HospitalFree and cfg.HospitalFree(ply)
	local price = free and 0 or math.max(math.floor(tonumber(cfg.HospitalPrice) or 0), 0)

	if price > 0 and not ply:canAfford(price) then
		DarkRP.notify(ply, 1, 4, "Лечение стоит " .. DarkRP.formatMoney(price))
		return
	end

	local started = DarkRP.ProgressAction(ply, npc, cfg.HospitalTime, cfg.HospitalRange, function()
		if not MES.NeedsTreatment(ply) then return end

		if price > 0 then
			if not ply:canAfford(price) then
				DarkRP.notify(ply, 1, 4, "Лечение стоит " .. DarkRP.formatMoney(price))
				return
			end

			ply:addMoney(-price)
		end

		MES.HospitalTreat(ply)
		DarkRP.notify(ply, 0, 5, "Вам оказали медицинскую помощь" .. (price > 0 and (" (" .. DarkRP.formatMoney(price) .. ")") or ""))
		DarkRP.log("medic", ply, nil, "лечение в больнице" .. (price > 0 and (" за " .. DarkRP.formatMoney(price)) or ""), Color(120, 200, 255))
	end, function()
		DarkRP.notify(ply, 1, 3, "Лечение прервано")
	end)

	if started then
		DarkRP.notify(ply, 0, cfg.HospitalTime, "Вас осматривает врач..")
	end
end

--[[---------------------------------------------------------------------------
Мост для оружия (mlw_* читают NW-переменные): переломы, героин, алкоголь, тату
---------------------------------------------------------------------------]]
local nwBool = {fracturearm = true, fracture = true, heroin = true, bleeding = true}
local nwFloat = {alcohol = true}

hook.Add("DarkRPVarChanged", "MES.NW", function(ply, var, old, new)
	if nwBool[var] then
		ply:SetNWBool(var, new and true or false)
	elseif nwFloat[var] then
		ply:SetNWFloat(var, tonumber(new) or 0)
	elseif var == "tatoo" then
		local has = {}

		for _, id in ipairs(string.Explode(";", new or "")) do
			has[id] = true
		end

		for id in pairs(MCR and MCR.Tatoo or {}) do
			ply:SetNWBool("NoireTattoo_" .. id, has[id] or false)
		end
	end
end)
