-- "addons\\health\\lua\\mc_haes\\core\\sv_damage.lua"
-- Ранения: кровь, кровотечения, шок, нокауты, холод, кашель, регенерация.
--   Кровь: DarkRPVar "blood" (self, 0-100). MES.GetBlood(ply), MES.SetBlood(ply, n), ply:AddBlood(n), ply:BloodLevel(n) - поднять до n.
--     < BloodShock - головокружение (шок), < BloodFaint - обмороки, <= BloodDeath - смерть.
--     Восстанавливается сытым (energy >= RegenEnergy) без кровотечения, быстро - под физраствором (ply.saline).
--   Кровотечение (шаг 44): sv_bleeding.lua - MES.Bleed(ply) от пуль и порезов, бинты (MES.ListHeal[1], bandage) снимают.
--     Здесь только уровень крови: при кровотечении падает на BleedBlood за тик и не восстанавливается.
--   Переломов НЕТ (шаг 24): MES.Fracture - пустышка, только снимает старые статусы. Рана в руку - оружие выпадает (кроме тату g1).
--   Нокаут: MES.Knockout(ply, сек, heavy) -> ply:Ragdollize (в машине - без сознания в кресле). Тату g6 - пули не вырубают.
--   Смерть: разнесённая голова / сильный взрыв / давка -> ply.crithit (тело не откачать). Тату b4 - тело никогда не откачать.
--   Пули по машине simfphys достаются тем, кто внутри (игроки в креслах не принимают трассы).
--   Раны для осмотра: ply.MES_Wounds[класс оружия | "bullet" | "slash" | "club" | "burn" | "blast" | "fall" | "vehicle"] = n.
-- Хуки: MES.CanKnockout(ply, time, heavy) -> false запретить.
local pmeta = FindMetaTable("Player")

MES.Bleeding = true -- кровотечение считает MES (hungermod не наносит свой урон)

MES.DamageConfig = MES.DamageConfig or {}

local cfg = MES.DamageConfig
cfg.Tick = cfg.Tick or 2
-- кровотечение - шаг 44, sv_bleeding.lua (урон, пятна, капли, срок). Здесь только потеря крови:
cfg.BleedBlood = cfg.BleedBlood or 0.5 -- уровень крови за тик при кровотечении (как раньше у лёгкого), 0 - не трогать
-- кровь
cfg.BloodRegen = cfg.BloodRegen or 15 -- сек на 1 ед.
cfg.SalineRegen = cfg.SalineRegen or 1 -- за тик под физраствором
cfg.BloodShock = cfg.BloodShock or 40
cfg.BloodFaint = cfg.BloodFaint or 25
cfg.BloodDeath = cfg.BloodDeath or 5
cfg.FaintChance = cfg.FaintChance or 15 -- % за тик
cfg.FaintDelay = cfg.FaintDelay or 60
cfg.FaintTime = cfg.FaintTime or {20, 35}
cfg.BloodMinLoad = cfg.BloodMinLoad or 20 -- при входе персонажем не меньше
-- здоровье
cfg.HPRegen = cfg.HPRegen or 20 -- сек на 1 HP
cfg.RegenMeds = cfg.RegenMeds or 4 -- "Лечение" (meds3)
cfg.RegenEnergy = cfg.RegenEnergy or 100
cfg.RegenBlood = cfg.RegenBlood or 60
cfg.RegenDelay = cfg.RegenDelay or 30 -- после урона
-- шок (переломы убраны в шаге 24)
cfg.DropChance = cfg.DropChance or 35 -- % выронить оружие от пули в руку
cfg.ShockMax = cfg.ShockMax or 8 -- шок от ран не копится дольше
-- нокауты
cfg.KOHP = cfg.KOHP or 25 -- HP после пули
cfg.KOArmor = cfg.KOArmor or 12 -- пуля в жилет
cfg.KOStim = cfg.KOStim or 10 -- под стимуляторами/адреналином
cfg.KOChance = cfg.KOChance or 70
cfg.KOHead = cfg.KOHead or 50 -- % от пули в голову (не насмерть)
cfg.KORecent = cfg.KORecent or 60 -- урона за 10 сек
cfg.KOTime = cfg.KOTime or {20, 80}
-- смерть
cfg.CritHead = cfg.CritHead or 60
cfg.CritBlast = cfg.CritBlast or 100
cfg.CritCrush = cfg.CritCrush or 150
cfg.CorpseHead = cfg.CorpseHead or 40 -- пулями в голову трупа
cfg.CorpseDmg = cfg.CorpseDmg or 150
-- машины
cfg.CarBulletMul = cfg.CarBulletMul or 0.8 -- кузов немного гасит пулю
cfg.CrashSpeed = cfg.CrashSpeed or 750 -- удар сильнее - травмы в салоне (шаг 19: было 900)
cfg.CrashDmgDiv = cfg.CrashDmgDiv or 25
-- холод (вода залива)
cfg.ColdGain = cfg.ColdGain or 3
cfg.ColdG3 = cfg.ColdG3 or 1 -- "Баптист"
cfg.ColdLoss = cfg.ColdLoss or 2
cfg.ColdCarLoss = cfg.ColdCarLoss or 3
cfg.ColdHurt = cfg.ColdHurt or 60
cfg.ColdKO = cfg.ColdKO or 100
cfg.ColdMax = cfg.ColdMax or 120
-- броня только по зонам жилета (armorVest): мимо жилета движок не гасит урон бронёй
cfg.ArmorZones = cfg.ArmorZones ~= false

local function roll(chance)
	return math.random(100) <= chance
end

local function tatoo(ply, id)
	return MCR and MCR.HasTatoo and MCR.HasTatoo(ply, id) or false
end

local function uncon(ply)
	return ply.IsUncon and ply:IsUncon() or false
end

--[[---------------------------------------------------------------------------
Кровь
---------------------------------------------------------------------------]]
function MES.GetBlood(ply)
	return ply.MES_Blood or tonumber(ply:getDarkRPVar("blood")) or 100
end

function MES.SetBlood(ply, n)
	n = math.Clamp(tonumber(n) or 100, 0, 100)
	ply.MES_Blood = n

	local int = math.floor(n + 0.5)

	if ply:getDarkRPVar("blood") ~= int then
		ply:SetSelfDarkRPVar("blood", int)
	end
end

function pmeta:AddBlood(n)
	MES.SetBlood(self, MES.GetBlood(self) + (tonumber(n) or 0))
end

-- не ниже n (физраствор)
function pmeta:BloodLevel(n)
	if MES.GetBlood(self) < (tonumber(n) or 0) then
		MES.SetBlood(self, n)
	end
end

local function setCold(ply, v)
	v = math.Clamp(math.Round(v), 0, cfg.ColdMax)
	local cur = tonumber(ply:getDarkRPVar("cold"))

	if v <= 0 then
		if cur and cur > 0 then ply:SetSelfDarkRPVar("cold", nil) end
		return
	end

	if cur ~= v then ply:SetSelfDarkRPVar("cold", v) end
end

MES.SetCold = setCold

-- урон в обход брони (кровопотеря, холод)
local function hurt(ply, n, cause)
	if ply:HasGodMode() then return false end

	local hp = ply:Health() - n

	if hp <= 0 then
		ply.MES_Cause = cause
		ply:Kill()
		return true
	end

	ply:SetHealth(hp)

	return false
end

MES.Hurt = hurt -- шаг 44: урон кровотечения (sv_bleeding.lua)

--[[---------------------------------------------------------------------------
Состояния
---------------------------------------------------------------------------]]
-- шаг 44: MES.Bleed / MES.StopBleeding - в sv_bleeding.lua

-- шаг 24: переломов нет. Функция оставлена, чтобы старые вызовы (аддоны, команды) не ломались:
-- ничего не ломает, только снимает статусы, если они как-то остались.
function MES.Fracture(ply)
	MES.ClearFractures(ply)
end

function MES.ClearFractures(ply)
	if not IsValid(ply) then return end

	for _, stat in ipairs({"fracture", "fracturearm"}) do
		if ply.TempStats then ply.TempStats[stat] = nil end
		if ply:getDarkRPVar(stat) then ply:SetDarkRPVar(stat, nil) end
	end
end

local function shock(ply, time)
	local left = ply:TempStatLeft("shock")
	if left >= cfg.ShockMax then return end

	ply:AddTempStat("shock", math.min(time, cfg.ShockMax - left))
end

MES.Shock = shock

-- рана в руку: оружие выпадает
function MES.DropWeapon(ply)
	if tatoo(ply, "g1") then return end

	timer.Simple(0, function()
		if not IsValid(ply) or not ply:Alive() or ply:InVehicle() or uncon(ply) then return end

		local wep = ply:GetActiveWeapon()
		if not IsValid(wep) or wep:GetModel() == "" or not DarkRP.CanDropWeapon(ply, wep) then return end

		ply:DropDRPWeapon(wep)
		DarkRP.notify(ply, 1, 3, "Оружие выпало из раненой руки")
	end)
end

-- heavy = false - просто сбит с ног (видит, но лежит)
function MES.Knockout(ply, time, heavy)
	time = math.Clamp(tonumber(time) or 20, 2, GAMEMODE.Config.RagdollMaxTime or 180)

	-- после урона: тело с силой удара, не посреди физики
	timer.Simple(0, function()
		if not IsValid(ply) or not ply:Alive() then return end
		if hook.Run("MES.CanKnockout", ply, time, heavy) == false then return end

		ply:Ragdollize(time, heavy ~= false)
	end)
end

local function headFX(pos)
	local recv = {}

	for _, v in ipairs(player.GetHumans()) do
		if v:GetPos():DistToSqr(pos) < 2250000 then table.insert(recv, v) end
	end

	if #recv > 0 then DarkRP.UIEffect(recv, "headshot", {pos}) end
end

local function hitPos(ply, dmg)
	local pos = dmg:GetDamagePosition()
	if pos:IsZero() then pos = ply:EyePos() end
	return pos
end

local function painkiller(ply)
	return ply:getDarkRPVar("morph") or ply:getDarkRPVar("heroin") or ply:getDarkRPVar("adren")
end

local function stimulated(ply)
	return ply:getDarkRPVar("coca") or ply:getDarkRPVar("meth") or ply:getDarkRPVar("adren")
end

--[[---------------------------------------------------------------------------
Разбор урона
---------------------------------------------------------------------------]]
local function kindOf(dmg)
	if dmg:IsDamageType(DMG_BULLET) or dmg:IsDamageType(DMG_BUCKSHOT) or dmg:IsDamageType(DMG_SNIPER) then return "bullet" end
	if dmg:IsExplosionDamage() then return "blast" end
	if dmg:IsFallDamage() then return "fall" end
	if dmg:IsDamageType(DMG_SLASH) then return "slash" end
	if dmg:IsDamageType(DMG_CLUB) then return "club" end
	if dmg:IsDamageType(DMG_BURN) or dmg:IsDamageType(DMG_SLOWBURN) then return "burn" end
	if dmg:IsDamageType(DMG_VEHICLE) or dmg:IsDamageType(DMG_CRUSH) then return "crush" end

	return "other"
end

MES.DamageKind = kindOf

-- класс оружия (пули из SWEP обычно идут от игрока)
local function weaponOf(dmg)
	local inf, att = dmg:GetInflictor(), dmg:GetAttacker()

	if IsValid(inf) and inf:IsWeapon() then return inf:GetClass() end

	if IsValid(att) and att:IsPlayer() and (inf == att or not IsValid(inf)) then
		local wep = att:GetActiveWeapon()
		return IsValid(wep) and wep:GetClass() or nil
	end

	return IsValid(inf) and inf:GetClass() or nil
end

local function carOf(ent)
	if not IsValid(ent) then return end
	if ent.IsSimfphyscar then return ent end

	if ent:GetClass() == "gmod_sent_vehicle_fphysics_wheel" and ent.GetBaseEnt then
		local base = ent:GetBaseEnt()
		if IsValid(base) then return base end
	end

	local par = ent:GetParent()
	if IsValid(par) and par.IsSimfphyscar then return par end
end

local woundKinds = {bullet = true, slash = true, club = true, burn = true, blast = true, fall = true, vehicle = true}

local function addWound(ply, kind, class, CT)
	local key = class and (MES.gunz[class] or MES.melee[class]) and class or (woundKinds[kind] and kind)
	if not key then return end

	-- огонь жжёт каждый тик
	if kind == "burn" then
		if (ply.MES_BurnWound or 0) > CT then return end
		ply.MES_BurnWound = CT + 5
	end

	ply.MES_Wounds = ply.MES_Wounds or {}
	ply.MES_Wounds[key] = (ply.MES_Wounds[key] or 0) + 1
end

-- урон за последние 10 сек
local function addRecent(ply, n, CT)
	local list = ply.MES_Recent or {}
	local sum = 0

	for i = #list, 1, -1 do
		if list[i][1] + 10 < CT then
			table.remove(list, i)
		else
			sum = sum + list[i][2]
		end
	end

	table.insert(list, {CT, n})
	ply.MES_Recent = list

	return sum + n
end

-- зоны жилета (armorVest): 1 - полицейский, 2 - лёгкий, 3 - боёвка FDNY
local vestZones = {
	[1] = {[HITGROUP_CHEST] = true, [HITGROUP_STOMACH] = true},
	[2] = {[HITGROUP_CHEST] = true},
	[3] = {[HITGROUP_CHEST] = true, [HITGROUP_STOMACH] = true, [HITGROUP_LEFTARM] = true, [HITGROUP_RIGHTARM] = true},
}

local function armored(ply, hg)
	if ply:Armor() <= 0 then return false end

	local zones = vestZones[ply:getDarkRPVar("armorVest") or 0]
	if not zones then return hg ~= HITGROUP_HEAD end -- броня без жилета (выдана админом)

	return zones[hg] or false
end

local function restoreArmor(ply)
	if not ply.MES_Armor then return end

	if ply:Alive() then ply:SetArmor(ply.MES_Armor) end
	ply.MES_Armor = nil
end

-- куда попали по рэгдоллу (ближайшая физ. кость)
local boneGroups = {
	{"head", HITGROUP_HEAD}, {"neck", HITGROUP_HEAD},
	{"l_upperarm", HITGROUP_LEFTARM}, {"l_forearm", HITGROUP_LEFTARM}, {"l_hand", HITGROUP_LEFTARM},
	{"r_upperarm", HITGROUP_RIGHTARM}, {"r_forearm", HITGROUP_RIGHTARM}, {"r_hand", HITGROUP_RIGHTARM},
	{"l_thigh", HITGROUP_LEFTLEG}, {"l_calf", HITGROUP_LEFTLEG}, {"l_foot", HITGROUP_LEFTLEG},
	{"r_thigh", HITGROUP_RIGHTLEG}, {"r_calf", HITGROUP_RIGHTLEG}, {"r_foot", HITGROUP_RIGHTLEG},
	{"spine2", HITGROUP_CHEST}, {"spine4", HITGROUP_CHEST}, {"clavicle", HITGROUP_CHEST},
}

local function ragHitGroup(rag, pos)
	if not pos or pos:IsZero() then return HITGROUP_GENERIC end

	local best, bd

	for i = 0, rag:GetPhysicsObjectCount() - 1 do
		local phys = rag:GetPhysicsObjectNum(i)
		if not IsValid(phys) then continue end

		local d = phys:GetPos():DistToSqr(pos)
		if not bd or d < bd then best, bd = i, d end
	end

	if not best then return HITGROUP_GENERIC end

	local name = string.lower(rag:GetBoneName(rag:TranslatePhysBoneToBone(best)) or "")

	for _, v in ipairs(boneGroups) do
		if string.find(name, v[1], 1, true) then return v[2] end
	end

	return HITGROUP_STOMACH
end

MES.RagHitGroup = ragHitGroup

--[[---------------------------------------------------------------------------
Последствия ранений (после урона, здоровье уже снято)
  info: hg - зона, vest - попали в жилет, class - оружие, amount - снято HP, raw - урон, hp, recent - урон за 10 сек
---------------------------------------------------------------------------]]
local function koTime(ply, info)
	return math.Clamp(info.amount * 0.8 + 15 + (ply:GetMaxHealth() - info.hp) * 0.2, cfg.KOTime[1], cfg.KOTime[2])
end

local handlers = {}

handlers.bullet = function(ply, dmg, info)
	local hg = info.hg

	-- травматика: сбивает с ног, не ранит
	if info.class == "police_beanbag" then
		shock(ply, 4)
		if roll(50) then MES.Knockout(ply, 4, false) end
		return
	end

	-- шаг 44: кровотечение от любой пули, в жилет - с шансом BleedArmor (sv_bleeding.lua)
	if not info.vest or roll(cfg.BleedArmor) then
		MES.Bleed(ply)
	end

	if hg == HITGROUP_LEFTLEG or hg == HITGROUP_RIGHTLEG then
		-- переломов нет (шаг 24)
	elseif (hg == HITGROUP_LEFTARM or hg == HITGROUP_RIGHTARM) and not info.vest then
		if roll(cfg.DropChance) then MES.DropWeapon(ply) end
	elseif hg == HITGROUP_HEAD then
		headFX(hitPos(ply, dmg))
	end

	if not painkiller(ply) then
		if info.raw >= 25 then
			shock(ply, math.random(3, 6))
		elseif roll(40) then
			shock(ply, math.random(2, 4))
		end
	end

	-- "Непреодолимая сила"
	if tatoo(ply, "g6") then return end

	local stim = stimulated(ply)
	local th = stim and cfg.KOStim or (info.vest and cfg.KOArmor or cfg.KOHP)

	if (info.hp <= th and roll(cfg.KOChance)) or (not stim and info.recent >= cfg.KORecent) or (hg == HITGROUP_HEAD and not stim and roll(cfg.KOHead)) then
		MES.Knockout(ply, koTime(ply, info))
	end
end

handlers.slash = function(ply, dmg, info)
	-- шаг 44: порез - кровотечение всегда, в бронежилете - с шансом BleedArmor
	if ply:Armor() <= 0 or roll(cfg.BleedArmor) then
		MES.Bleed(ply)
	end

	if info.raw >= 20 and not painkiller(ply) then shock(ply, 2) end
end

handlers.club = function(ply, dmg, info)
	-- кулаки и mlw_* сами решают, кого вырубить
	local class = info.class or ""
	if class == "keys" or string.StartWith(class, "mlw_") then return end

	if info.raw >= 10 and not painkiller(ply) then shock(ply, 2) end
	-- шаг 44: от ударов кровотечения нет (только пули и порезы)

	if info.hp <= 30 and roll(50) and not stimulated(ply) then
		MES.Knockout(ply, math.random(15, 30))
	end
end

handlers.blast = function(ply, dmg, info)
	if info.raw >= 10 then
		shock(ply, 6)
		DarkRP.UIEffect(ply, "headache")
	end

	-- шаг 44: от взрыва кровотечения нет (только пули и порезы)

	if info.raw >= 30 then
		MES.Knockout(ply, math.Clamp(info.raw * 0.5 + 10, 15, 60))
	end
end

handlers.fall = function(ply, dmg, info)
	if info.raw >= 10 then shock(ply, 2) end

	if info.raw >= 35 then
		MES.Knockout(ply, math.Clamp(10 + info.raw * 0.4, 15, 50))
	end
end

handlers.burn = function(ply, dmg, info)
	if roll(30) and ply:TempStatLeft("cough") < 3 then ply:AddTempStat("cough", 6) end
end

-- сбит машиной
handlers.vehicle = function(ply, dmg, info)
	if info.raw < 10 then return end

	-- шаг 44: от машины кровотечения нет (только пули и порезы)

	MES.Knockout(ply, math.Clamp(info.raw * 0.6 + 5, 5, 40), info.raw >= 25)
end

--[[---------------------------------------------------------------------------
Хуки урона
---------------------------------------------------------------------------]]
-- труп: разнесённая голова / изрешечённое тело - уже не откачать
local function corpseDamage(rag, dmg)
	if rag.crithit then return end

	local n = dmg:GetDamage()
	if dmg:IsDamageType(DMG_CRUSH) and n < 20 then return end

	rag.MES_Dmg = (rag.MES_Dmg or 0) + n

	if (dmg:IsDamageType(DMG_BULLET) or dmg:IsDamageType(DMG_BUCKSHOT)) and ragHitGroup(rag, dmg:GetDamagePosition()) == HITGROUP_HEAD then
		rag.MES_HeadDmg = (rag.MES_HeadDmg or 0) + n
	end

	if (rag.MES_HeadDmg or 0) >= cfg.CorpseHead or rag.MES_Dmg >= cfg.CorpseDmg then
		rag.crithit = true
	end
end

hook.Add("EntityTakeDamage", "MES.Damage", function(ent, dmg)
	if ent.IsDeathRagdoll then
		corpseDamage(ent, dmg)
		return
	end

	if not ent:IsPlayer() or not ent:Alive() then return end

	ent.MES_PreHP = ent:Health()

	local kind = kindOf(dmg)
	local hg

	if IsValid(ent.UnconDamageRag) then
		-- по телу без сознания (sv_ragdoll.lua): голову движок не удваивает
		hg = ragHitGroup(ent.UnconDamageRag, dmg:GetDamagePosition())
		if hg == HITGROUP_HEAD and kind == "bullet" then dmg:ScaleDamage(2) end
	elseif ent.MES_ForceHitGroup then
		hg = ent.MES_ForceHitGroup
	elseif kind == "bullet" then
		hg = ent:LastHitGroup()
	end

	ent.MES_HitGroup = hg
	ent.MES_Vest = nil

	if kind == "bullet" and hg and hg ~= HITGROUP_GENERIC and ent:Armor() > 0 then
		ent.MES_Vest = armored(ent, hg)

		if not ent.MES_Vest and cfg.ArmorZones and not ent.MES_Armor then
			ent.MES_Armor = ent:Armor()
			ent:SetArmor(0)

			timer.Simple(0, function()
				if IsValid(ent) then restoreArmor(ent) end
			end)
		end
	end

	-- сбили машиной: виноват водитель
	ent.MES_CarHit = nil

	if kind == "crush" and not ent:InVehicle() then
		local car = carOf(dmg:GetInflictor()) or carOf(dmg:GetAttacker())

		if car then
			ent.MES_CarHit = car

			local drv = car.GetDriver and car:GetDriver()
			local att = dmg:GetAttacker()

			if IsValid(drv) and drv ~= ent and (not IsValid(att) or att == car or att:IsWorld() or not att:IsPlayer()) then
				dmg:SetAttacker(drv)
			end
		end
	end
end)

hook.Add("PostEntityTakeDamage", "MES.Damage", function(ply, dmg, took)
	if not ply:IsPlayer() then return end

	restoreArmor(ply)

	local hg, vest, car, pre = ply.MES_HitGroup, ply.MES_Vest, ply.MES_CarHit, ply.MES_PreHP
	ply.MES_HitGroup, ply.MES_Vest, ply.MES_CarHit, ply.MES_PreHP = nil, nil, nil, nil

	if not took or ply.MES_Skip or not pre then return end

	local CT = CurTime()
	local kind = kindOf(dmg)
	local class = weaponOf(dmg)

	if car and kind == "crush" then kind = "vehicle" end

	-- удары салона при аварии - в MES.Crash
	if kind == "other" and ply:InVehicle() and carOf(dmg:GetInflictor()) then return end

	addWound(ply, kind, class, CT)

	if not ply:Alive() then return end

	local hp = ply:Health()
	local amount = math.max(pre - hp, 0)
	local h = handlers[kind]

	local recent = addRecent(ply, amount, CT)
	if not h then return end

	h(ply, dmg, {
		hg = hg, vest = vest, class = class, amount = amount, raw = dmg:GetDamage(), hp = hp, recent = recent,
	})
end)

-- смерть: тело, которое уже не откачать
hook.Add("DoPlayerDeath", "MES.Death", function(ply, attacker, dmg)
	local kind = kindOf(dmg)
	local n = dmg:GetDamage()
	local hg = ply.MES_HitGroup

	local crit = tatoo(ply, "b4") -- "Подлость"

	if kind == "bullet" and hg == HITGROUP_HEAD and n >= cfg.CritHead then
		crit = true
		headFX(hitPos(ply, dmg))
	elseif kind == "blast" and n >= cfg.CritBlast then
		crit = true
	elseif kind == "crush" and n >= cfg.CritCrush then
		crit = true
	end

	if crit then ply.crithit = true end
end)

hook.Add("PlayerDeath", "MES.Damage", function(ply)
	ply.MES_Recent = nil
	ply.MES_Armor = nil
	ply.saline = nil
	setCold(ply, 0)
end)

--[[---------------------------------------------------------------------------
Машины simfphys
---------------------------------------------------------------------------]]
-- насколько близко луч проходит от точки: расстояние, дальность вдоль луча
local function rayDist(pos, dir, p)
	local t = (p - pos):Dot(dir)
	return (pos + dir * t):Distance(p), t
end

local bodyPoints = {
	{0, 7, HITGROUP_HEAD},
	{14, 11, HITGROUP_CHEST},
	{26, 11, HITGROUP_STOMACH},
}

-- пули по кузову: кто сидит на линии выстрела
hook.Add("simfphysOnTakeDamage", "MES.Passengers", function(car, dmg)
	if not (dmg:IsDamageType(DMG_BULLET) or dmg:IsDamageType(DMG_BUCKSHOT) or dmg:IsDamageType(DMG_SNIPER)) then return end
	if car.IsArmored or car.Armored or not car.GetSeats then return end

	local pos = dmg:GetDamagePosition()
	local dir = dmg:GetDamageForce()
	local att = dmg:GetAttacker()

	if dir:IsZero() then
		if not IsValid(att) then return end
		dir = pos - (att:IsPlayer() and att:GetShootPos() or att:WorldSpaceCenter())
	end

	dir:Normalize()

	local victim, vt, vhg, vpos

	for _, seat in ipairs(car:GetSeats()) do
		local p = IsValid(seat) and seat:GetDriver()
		if not IsValid(p) or not p:Alive() or p == att then continue end

		local eye = p:EyePos()
		local up = seat:GetUp()

		for _, bp in ipairs(bodyPoints) do
			local point = eye - up * bp[1]
			local d, t = rayDist(pos, dir, point)

			if d <= bp[2] and t >= -12 and t <= 160 and (not vt or t < vt) then
				victim, vt, vhg, vpos = p, t, bp[3], pos + dir * t
				break
			end
		end
	end

	if not victim then return end

	local d = DamageInfo()
	d:SetDamage(dmg:GetDamage() * cfg.CarBulletMul * (vhg == HITGROUP_HEAD and 2 or 1))
	-- шаг 19: + DMG_DIRECT, иначе фильтр simfphys гасит урон сидящему
	d:SetDamageType(bit.bor(dmg:GetDamageType(), DMG_DIRECT))
	d:SetAttacker(IsValid(att) and att or game.GetWorld())
	d:SetInflictor(IsValid(dmg:GetInflictor()) and dmg:GetInflictor() or d:GetAttacker())
	d:SetDamagePosition(vpos)
	d:SetDamageForce(dmg:GetDamageForce() * 0.2)

	local fx = EffectData()
	fx:SetOrigin(vpos)
	fx:SetScale(3)
	util.Effect("BloodImpact", fx)

	victim.MES_ForceHitGroup = vhg
	victim:TakeDamageInfo(d)
	victim.MES_ForceHitGroup = nil
end)

-- сильный удар: травмы у всех в салоне
local function crash(ply, car, over)
	if not ply:Alive() then return end

	addWound(ply, "vehicle", nil, CurTime())

	local n = math.floor(over / cfg.CrashDmgDiv)

	if n > 0 then
		local d = DamageInfo()
		d:SetDamage(n)
		d:SetDamageType(bit.bor(DMG_VEHICLE, DMG_DIRECT))
		d:SetAttacker(game.GetWorld())
		d:SetInflictor(car)

		ply.MES_Skip = true
		ply:TakeDamageInfo(d)
		ply.MES_Skip = nil

		if not ply:Alive() then return end
	end

	shock(ply, math.Clamp(over / 150, 2, 6))

	-- шаг 44: от аварии кровотечения нет (только пули и порезы)

	if over >= 100 and roll(math.min(over / 8, 90)) then
		MES.Knockout(ply, math.Clamp(15 + over / 20, 15, 60))
	end
end

hook.Add("simfphysPhysicsCollide", "MES.Crash", function(car, data)
	local speed = data.Speed or 0
	if speed < cfg.CrashSpeed or (data.DeltaTime or 0) < 0.2 then return end

	local hit = data.HitEntity
	if IsValid(hit) and (hit:IsPlayer() or hit:IsNPC()) then return end

	if (car.MES_Crash or 0) > CurTime() then return end
	car.MES_Crash = CurTime() + 1

	local over = speed - cfg.CrashSpeed

	-- не из физического колбэка
	timer.Simple(0, function()
		if not IsValid(car) or not car.GetSeats then return end

		for _, seat in ipairs(car:GetSeats()) do
			local ply = IsValid(seat) and seat:GetDriver()
			if IsValid(ply) then crash(ply, car, over) end
		end
	end)
end)

--[[---------------------------------------------------------------------------
Тик: кровь, кровотечение, регенерация, холод, кашель
---------------------------------------------------------------------------]]
local function fed(ply)
	return (tonumber(ply:getDarkRPVar("energy")) or 0) >= cfg.RegenEnergy
end

local function cough(ply)
	local pitch = ply:getDarkRPVar("gender") == "female" and math.random(120, 130) or math.random(95, 108)
	ply:EmitSound("ambient/voices/cough" .. math.random(4) .. ".wav", 65, pitch)
end

MES.Cough = cough

local function think(ply, CT)
	local bleeding = ply:getDarkRPVar("bleeding")
	local blood = MES.GetBlood(ply)
	local down = uncon(ply)

	-- кровотечение: урон, пятна и капли - sv_bleeding.lua (шаг 44), здесь только уровень крови
	if bleeding then
		blood = blood - (cfg.BleedBlood or 0)
	elseif blood < 100 and fed(ply) and (ply.MES_BloodRegen or 0) <= CT then
		ply.MES_BloodRegen = CT + cfg.BloodRegen
		blood = blood + 1
	end

	-- физраствор держит объём даже при кровотечении
	if ply.saline then
		if ply.saline > CT then
			blood = blood + cfg.SalineRegen
		else
			ply.saline = nil
		end
	end

	MES.SetBlood(ply, blood)
	blood = MES.GetBlood(ply)

	if blood <= cfg.BloodDeath and not ply:HasGodMode() then
		ply.MES_Cause = "blood"
		ply:Kill()
		return
	end

	if blood < cfg.BloodFaint then
		if not down and (ply.MES_Faint or 0) <= CT and roll(cfg.FaintChance) then
			ply.MES_Faint = CT + cfg.FaintDelay
			DarkRP.notify(ply, 1, 4, "В глазах темнеет...")
			ply:Ragdollize(math.random(cfg.FaintTime[1], cfg.FaintTime[2]), true)
			down = true
		end
	elseif blood < cfg.BloodShock and not down and (ply.MES_BloodShock or 0) <= CT and roll(25) then
		ply.MES_BloodShock = CT + 20
		shock(ply, 3)
		DarkRP.notify(ply, 1, 3, "Кружится голова...")
	end

	-- холод: вода залива
	local cold = tonumber(ply:getDarkRPVar("cold")) or 0

	if ply:WaterLevel() >= 2 and not ply:InVehicle() then
		cold = cold + (tatoo(ply, "g3") and cfg.ColdG3 or cfg.ColdGain)
	elseif cold > 0 then
		cold = cold - (ply:InVehicle() and cfg.ColdCarLoss or cfg.ColdLoss)
	end

	setCold(ply, cold)

	if cold > cfg.ColdHurt then
		ply.MES_ColdN = (ply.MES_ColdN or 0) + 1

		if ply.MES_ColdN >= 2 then
			ply.MES_ColdN = 0
			if hurt(ply, 1, "cold") then return end
		end

		if roll(10) and ply:TempStatLeft("cough") < 3 then ply:AddTempStat("cough", 5) end

		if cold >= cfg.ColdKO and not down and (ply.MES_ColdKO or 0) <= CT and roll(30) then
			ply.MES_ColdKO = CT + 60
			DarkRP.notify(ply, 1, 4, "Тело сводит от холода...")
			ply:Ragdollize(15, true)
			down = true
		end
	end

	-- регенерация здоровья
	local hp, max = ply:Health(), ply:GetMaxHealth()

	if hp < max and not bleeding and blood >= cfg.RegenBlood and cold <= 30 and fed(ply) and (ply.LastDamage or 0) + cfg.RegenDelay < CT then
		if (ply.MES_Regen or 0) <= CT then
			local mul = (ply:getDarkRPVar("meds3") and cfg.RegenMeds or 1) * (ply:getDarkRPVar("hunger") and 2 or 1)

			ply.MES_Regen = CT + cfg.HPRegen / mul
			ply:SetHealth(math.min(hp + 1, max))
		end
	else
		ply.MES_Regen = nil
	end

	-- кашель
	if ply:getDarkRPVar("cough") and (ply.MES_Cough or 0) <= CT and not ply.UnconHeavy then
		ply.MES_Cough = CT + math.Rand(4, 9)
		cough(ply)
	end
end

timer.Create("MES.Health", cfg.Tick, 0, function()
	local CT = CurTime()

	for _, ply in ipairs(player.GetAll()) do
		if not ply:Alive() or not ply:getDarkRPVar("character") or ply.DarkRPHidden then continue end
		if ply:GetMoveType() == MOVETYPE_NOCLIP and not ply.UnconHidden then continue end

		think(ply, CT)
	end
end)

--[[---------------------------------------------------------------------------
Помощь медика: бинты ускоряют заживление
---------------------------------------------------------------------------]]
hook.Add("MES.Healed", "MES.Damage", function(medic, ply, k)
	local v = MES.ListHeal[k]
	if v and v[1] == "Наложить бинты" and ply:Alive() then ply:AddTempStat("meds3", 120) end
end)

--[[---------------------------------------------------------------------------
Персонаж: кровь живёт с ним, раны - до возрождения
---------------------------------------------------------------------------]]
hook.Add("PlayerSpawn", "MES.Damage", function(ply)
	MES.ClearFractures(ply)
	ply.MES_Recent = nil
	ply.MES_Faint = nil

	-- реанимация (sv_init.lua MES.Revive): раны и кровь остаются
	if ply.MES_Revive then return end

	ply.MES_Wounds = nil
	ply.saline = nil
	MES.SetBlood(ply, 100)
	setCold(ply, 0)
end)

hook.Add("DarkRP.CharacterSelected", "MES.Damage", function(ply, slot, ch)
	local vars = ch and ch.vars or {}

	ply.MES_Wounds = nil
	MES.SetBlood(ply, math.max(tonumber(vars.blood) or 100, cfg.BloodMinLoad))
end)

hook.Add("DarkRP.DB.SaveCharVars", "MES.Damage", function(ply, vars)
	if not ply:Alive() or not ply.MES_Blood then
		vars.blood = nil
		return
	end

	local b = math.floor(MES.GetBlood(ply))
	vars.blood = b < 100 and b or nil
end)

hook.Add("MCR.CharacterUnloaded", "MES.Damage", function(ply)
	ply.MES_Blood = nil
	ply.MES_Wounds = nil
	ply.MES_Recent = nil
	ply.saline = nil

	ply:SetSelfDarkRPVar("blood", nil)
	ply:SetSelfDarkRPVar("cold", nil)
end)
