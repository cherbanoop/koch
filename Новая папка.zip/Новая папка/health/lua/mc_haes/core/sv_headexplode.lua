-- Шаг 21. Взрыв головы (по мотивам RP/lua/autorun/uncon.lua). Какое оружие что взрывает - шаг 30 ниже.
--   Стоящий: смертельное попадание в голову (пуля/дробь/взрыв) с уроном >= HeadExplodeLive -> голова трупа разлетается.
--   Без сознания / труп: урон в голову рэгдолла копится, >= HeadExplodeRag (или один удар >= HeadExplodeRagHit) -> взрыв.
--   Взорванная голова: NWBool "HeadExploded", кость Head1 в 0 (головные уборы клиент прячет сам), кровь, декали, звук.
--   Такое тело не откачать (crithit). Без сознания - игрок умирает.
MES = MES or {}
MES.DamageConfig = MES.DamageConfig or {}
local cfg = MES.DamageConfig

cfg.HeadExplode = cfg.HeadExplode ~= false
-- шаг 26: голову разносит тяжёлое оружие (винтовки, дробовики, пулемёты, взрыв).
-- шаг 30:
--   * стоящему (не в рэгдолле): тяжёлое оружие - смертельный выстрел в голову от HeadExplodeLive;
--     Colt King Cobra (любой ствол: обычный, длинный, короткий) и Deagle - с первого смертельного выстрела
--     в голову, без порога урона (HeadExplodeOneShot); остальные пистолеты стоящему голову НЕ взрывают.
--   * лежащему (без сознания в рэгдолле или труп): любое огнестрельное, в том числе лёгкие пистолеты.
--     Пуля в голову лежащего считается x2 (HeadExplodeRagMul) - как по живому, где движок удваивает урон в голову.
cfg.HeadExplodeLive = cfg.HeadExplodeLive or 60   -- смертельный выстрел в голову стоящему (тяжёлое оружие)
cfg.HeadExplodeRag = cfg.HeadExplodeRag or 120    -- накоплено по голове лежащего / трупа
cfg.HeadExplodeRagHit = cfg.HeadExplodeRagHit or 60 -- один выстрел по голове лежащего / трупа
cfg.HeadExplodeRagMul = cfg.HeadExplodeRagMul or 2  -- множитель пули в голову лежащего / трупа
cfg.HeadExplodeOneShot = cfg.HeadExplodeOneShot or {["mwb_357"] = true, ["mwb_deagle"] = true, ["police_sw"] = true}
if cfg.HeadExplodePistol == nil then cfg.HeadExplodePistol = false end -- true - лёгкие пистолеты и стоящему
if cfg.HeadExplodePistolRag == nil then cfg.HeadExplodePistolRag = true end -- false - лёгкие и лежащему нельзя
-- шаг 33:
--   * лёгкое оружие (пистолеты, Tec-9, MAC-10, Uzi - кроме Deagle и револьверов) по голове лежащего (рэгдолл без
--     сознания или труп): голова разлетается с N-го попадания, N - случайно от 2 до 4 для каждого тела
--     (HeadExplodeLightHits). Урон пули для них больше не важен.
--   * Deagle и револьверы (HeadExplodeOneShot + любое оружие с HoldType "revolver"): по голове лежащего - с первого
--     попадания; стоящему - выстрел в голову сразу насмерть и голова разлетается (HeadExplodeOneShotKill).
--     Шлем, который держит пулю (каска helmet из DarkRP.WearJunk), спасает - тогда обычный урон.
--   * тяжёлое оружие (винтовки, дробовики, пулемёты, взрыв) - как раньше, по урону.
cfg.HeadExplodeLightHits = cfg.HeadExplodeLightHits or {2, 4}
cfg.HeadExplodeLight = cfg.HeadExplodeLight or {["mwb_uzi"] = true, ["mwb_tec9"] = true, ["mwb_mac10"] = true}
if cfg.HeadExplodeOneShotRevolvers == nil then cfg.HeadExplodeOneShotRevolvers = true end
if cfg.HeadExplodeOneShotKill == nil then cfg.HeadExplodeOneShotKill = true end
-- шаг 31: свой звук взрыва головы (sound/noire/headshot/head.wav) удалён по просьбе - остался только
-- стандартный «шлепок» HL2. Вернуть любой звук: MES.DamageConfig.HeadExplodeSound = "папка/файл.wav"
if cfg.HeadExplodeSound == "noire/headshot/head.wav" then cfg.HeadExplodeSound = nil end
cfg.HeadExplodeSound = cfg.HeadExplodeSound or ""

if cfg.HeadExplodeSound ~= "" then resource.AddFile("sound/" .. cfg.HeadExplodeSound) end

local decals = {"decals/blood4model", "decals/bloodstain_001", "decals/bloodstain_002", "decals/bloodstain_003", "decals/bloodstain_003b", "decals/bloodstain_101"}

local function headPos(rag)
	local b = rag:LookupBone("ValveBiped.Bip01_Head1")
	if b then
		local m = rag:GetBoneMatrix(b)
		if m then return m:GetTranslation() end
		local p = rag:GetBonePosition(b)
		if p then return p end
	end
	return rag:WorldSpaceCenter()
end

local pistolHold = {pistol = true, revolver = true, duel = true}

-- из какого оружия стреляли
local function weaponClass(dmg)
	local inf = dmg:GetInflictor()
	if IsValid(inf) and inf:IsWeapon() then return inf:GetClass() end

	local atk = dmg:GetAttacker()
	if IsValid(atk) and atk:IsPlayer() then
		local wep = atk:GetActiveWeapon()
		if IsValid(wep) then return wep:GetClass() end
	end

	if IsValid(inf) and inf ~= atk then return inf:GetClass() end
end

function MES.IsPistolClass(class)
	if not class then return false end
	local sw = DarkRP and DarkRP.SingleWep
	if sw and sw.PistolWeps and sw.PistolWeps[class] then return true end

	local wt = weapons.GetStored(class)
	if not wt then return false end
	if wt.HoldType and pistolHold[string.lower(wt.HoldType)] then return true end

	-- mg_base: SWEP.HoldTypes / Base = пистолет
	local base = wt.Base and weapons.GetStored(wt.Base)
	return base and base.HoldType and pistolHold[string.lower(base.HoldType)] and true or false
end

local function holdTypeOf(class)
	local wt = class and weapons.GetStored(class)
	if not wt then return end

	local ht = wt.HoldType
	if not isstring(ht) and wt.Base then
		local base = weapons.GetStored(wt.Base)
		ht = base and base.HoldType
	end

	return isstring(ht) and string.lower(ht) or nil
end

-- шаг 33: Deagle / револьвер - голова «с первого»
function MES.IsOneShotClass(class)
	if not class then return false end
	if cfg.HeadExplodeOneShot[class] then return true end

	return cfg.HeadExplodeOneShotRevolvers and holdTypeOf(class) == "revolver" or false
end

-- шаг 33: лёгкое оружие - по лежащему с 2-4 попаданий
function MES.IsLightClass(class)
	if not class then return false end
	if cfg.HeadExplodeLight[class] then return true end

	return MES.IsPistolClass(class)
end

-- сколько попаданий лёгким оружием нужно этому телу (HeadExplodeLightHits = {от, до} или число)
local function lightNeed()
	local r = cfg.HeadExplodeLightHits
	local lo, hi = 2, 4

	if istable(r) then
		lo = tonumber(r[1]) or lo
		hi = tonumber(r[2] or r[1]) or hi
	elseif tonumber(r) then
		lo, hi = tonumber(r), tonumber(r)
	end

	lo = math.max(1, math.floor(lo))
	hi = math.max(lo, math.floor(hi))

	return math.random(lo, hi)
end

-- может ли этот урон разнести голову. live - по стоящему игроку, иначе по лежащему (рэгдолл / труп).
-- Второе значение: true - «с первого выстрела» (Deagle, револьверы). Третье: true - лёгкое оружие (2-4 попадания).
local function explodable(dmg, live)
	if dmg:IsExplosionDamage() then return true, false, false end
	if not (dmg:IsBulletDamage() or dmg:IsDamageType(DMG_BULLET) or dmg:IsDamageType(DMG_BUCKSHOT) or dmg:IsDamageType(DMG_SNIPER)) then
		return false, false, false
	end

	-- дробь - всегда тяж
	if dmg:IsDamageType(DMG_BUCKSHOT) then return true, false, false end

	local class = weaponClass(dmg)
	if MES.IsOneShotClass(class) then return true, true, false end
	if not MES.IsLightClass(class) then return true, false, false end

	-- лёгкое оружие: стоящему нельзя, лежащему - с 2-4 попаданий
	if live then return cfg.HeadExplodePistol and true or false, false, true end

	return cfg.HeadExplodePistolRag and true or false, false, true
end

MES.HeadExplodable = explodable

function MES.ExplodeHead(rag, pos)
	if not cfg.HeadExplode or not IsValid(rag) or rag:GetNWBool("HeadExploded") then return end

	rag:SetNWBool("HeadExploded", true)
	rag.crithit = true

	local hb = rag:LookupBone("ValveBiped.Bip01_Head1")
	if hb then rag:ManipulateBoneScale(hb, Vector(0, 0, 0)) end

	pos = (pos and not pos:IsZero()) and pos or headPos(rag)

	local fx = EffectData()
	fx:SetOrigin(pos)
	fx:SetScale(6)
	fx:SetFlags(3)
	fx:SetColor(0)
	util.Effect("BloodImpact", fx)
	for i = 1, 5 do util.Effect("bloodspray", fx) end

	for i = 1, 6 do
		local dir = VectorRand()
		dir.z = dir.z - 0.6
		dir:Normalize()
		local tr = util.TraceLine({start = pos, endpos = pos + dir * 150, filter = rag})
		if tr.Hit then util.Decal("Blood", tr.HitPos + tr.HitNormal, tr.HitPos - tr.HitNormal, rag) end
	end

	for i = 1, 3 do
		local dir = VectorRand()
		dir.z = dir.z - 0.5
		dir:Normalize()
		local tr = util.TraceLine({start = pos, endpos = pos + dir * 100, filter = rag})
		if tr.Hit then util.Decal(decals[math.random(#decals)], tr.HitPos + tr.HitNormal, tr.HitPos - tr.HitNormal, rag) end
	end

	if cfg.HeadExplodeSound ~= "" then rag:EmitSound(cfg.HeadExplodeSound, 80, math.random(95, 105)) end
	rag:EmitSound("npc/antlion_grub/squashed.wav", 75, 95)

	hook.Run("MES.HeadExploded", rag, pos)
end

-- живой игрок: смертельный выстрел в голову
hook.Add("DoPlayerDeath", "MES.HeadExplode", function(ply, attacker, dmg)
	ply.MES_HeadExplode = nil
	if not cfg.HeadExplode then return end
	if ply.MES_HitGroup ~= HITGROUP_HEAD then return end

	-- шаг 33: урон пришёл через рэгдолл без сознания (sv_ragdoll.lua пересылает его игроку) - это «лежащий».
	-- Тогда решает хук рэгдолла ниже (там же счётчик попаданий лёгким оружием), здесь не взрываем.
	if IsValid(ply.UnconDamageRag) or IsValid(ply.UnconRagdoll) then return end

	local ok, oneshot = explodable(dmg, true)
	if not ok then return end

	local need = oneshot and 0 or cfg.HeadExplodeLive
	if dmg:GetDamage() < need then return end

	ply.MES_HeadExplode = dmg:GetDamagePosition()
	ply.crithit = true
end)

hook.Add("DarkRP.DeathRagdollCreated", "MES.HeadExplode", function(ply, rag)
	local pos = ply.MES_HeadExplode
	if not pos then return end
	ply.MES_HeadExplode = nil
	timer.Simple(0, function() MES.ExplodeHead(rag, pos) end)
end)

-- рэгдолл (без сознания или труп): урон в голову копится
hook.Add("EntityTakeDamage", "MES.HeadExplode", function(ent, dmg)
	if not cfg.HeadExplode or not (ent.IsDeathRagdoll or ent.IsUnconRagdoll) then return end
	if ent:GetNWBool("HeadExploded") then return end

	local ok, oneshot, light = explodable(dmg, false)
	if not ok then return end
	if not MES.RagHitGroup or MES.RagHitGroup(ent, dmg:GetDamagePosition()) ~= HITGROUP_HEAD then return end

	-- шаг 33: Deagle / револьвер - с первого попадания; лёгкое оружие - с 2-4 попаданий; тяжёлое - по урону
	if light then
		ent.MES_HeadHits = (ent.MES_HeadHits or 0) + 1
		ent.MES_HeadNeed = ent.MES_HeadNeed or lightNeed()
		if ent.MES_HeadHits < ent.MES_HeadNeed then return end
	elseif not oneshot then
		local n = dmg:GetDamage() * (dmg:IsExplosionDamage() and 1 or cfg.HeadExplodeRagMul)
		ent.MES_HeadBurst = (ent.MES_HeadBurst or 0) + n
		if ent.MES_HeadBurst < cfg.HeadExplodeRag and n < cfg.HeadExplodeRagHit then return end
	end

	local pos = dmg:GetDamagePosition()

	if ent.IsUnconRagdoll and not ent.IsDeathRagdoll then
		local ply = ent.player
		timer.Simple(0, function()
			if IsValid(ply) and ply:Alive() and ply.UnconRagdoll == ent then
				ply.crithit = true
				ply:Kill()
			end
			-- тело остаётся тем же рэгдоллом (DarkRP.TakeUnconRagdoll)
			timer.Simple(0, function()
				local rag = IsValid(ply) and IsValid(ply.DeathRagdoll) and ply.DeathRagdoll or ent
				MES.ExplodeHead(rag, pos)
			end)
		end)
		return
	end

	MES.ExplodeHead(ent, pos)
end)

--[[---------------------------------------------------------------------------
Шаг 33: Deagle / револьвер в голову стоящему - сразу насмерть, голова разлетается (DoPlayerDeath выше).
  Не действует: в машине, без сознания (там хук рэгдолла), дробь, шлем, который держит пулю.
  Выключить: MES.DamageConfig.HeadExplodeOneShotKill = false (тогда взрыв только если выстрел и так смертельный).
---------------------------------------------------------------------------]]
local function bulletHelmet(ply)
	local W = DarkRP and DarkRP.WearJunk
	local worn = ply.WornJunk
	if not W or not istable(W.Items) or not istable(worn) then return false end

	for _, part in ipairs({"head", "face"}) do
		local item = worn[part]
		local c = istable(item) and W.Items[item.class]
		if c and c.prot and (not c.dmg or bit.band(c.dmg, DMG_BULLET) ~= 0) then return true end
	end

	return false
end

hook.Add("EntityTakeDamage", "MES.HeadOneShot", function(ent, dmg)
	if not cfg.HeadExplode or not cfg.HeadExplodeOneShotKill then return end
	if not ent:IsPlayer() or not ent:Alive() or ent:InVehicle() then return end
	if IsValid(ent.UnconDamageRag) or IsValid(ent.UnconRagdoll) or ent.UnconSeat then return end
	if dmg:IsDamageType(DMG_BUCKSHOT) or not (dmg:IsBulletDamage() or dmg:IsDamageType(DMG_BULLET)) then return end
	if ent:LastHitGroup() ~= HITGROUP_HEAD then return end
	if not MES.IsOneShotClass(weaponClass(dmg)) then return end
	if bulletHelmet(ent) then return end

	dmg:SetDamage(math.max(dmg:GetDamage(), ent:Health() + ent:Armor() + 100))
end)
