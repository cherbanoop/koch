--[[---------------------------------------------------------------------------
Шаг 24. Боль (порт присланного pain.lua под сборку). Отруб/нокаут НЕ трогаем - он свой
(gamemode/modules/base/sv_ragdoll.lua). Из pain.lua взято:
  * NW "Pain"  - боль от не-пулевого урона (урон * 5, меньше в бронике), раз в 3 сек, спадает 12/сек
                 -> красная пульсирующая виньетка и размытие (client/hud.lua, вместе с шагом 21)
  * ViewPunch   - камеру дёргает при каждом попадании (один раз, не постоянно)
  * 30% шанс "сбить дыхание": 1.8 сек нельзя стрелять / прицеливаться / прыгать, мышь x0.35,
                 + "Shock" 15 (спадает 5/сек, замедляет движение, красная виньетка)
  * HP <= 30   - хромота (скорость x0.85 .. x0.6)
  * голос боли: рука/нога/грудь (vo/npc/male01 | female01 по модели)
Не взято: вода/яд (своя система холода), постоянное замедление после попадания (уже есть в
shared/commands.lua через ply.LastDamage), сердцебиение и обесцвечивание (уже есть в client/hud.lua).
Значения хранятся как "значение + время", спад считается на лету - NW не пишется каждый кадр.
---------------------------------------------------------------------------]]
MES = MES or {}

MES.PainConfig = MES.PainConfig or {
	PainMul = 5,          -- боль = урон * PainMul (броник уменьшает)
	PainCooldown = 3,     -- сек между приростами боли
	PainDecay = 12,       -- в секунду
	PainMax = 100,
	BlockChance = 30,     -- % при попадании
	BlockTime = 1.8,      -- сек без стрельбы/прыжка
	BlockMouse = 0.35,    -- чувствительность мыши в это время
	ShockAdd = 15,
	ShockDecay = 5,
	ShockMax = 200,
	LimpHP = 30,          -- хромота
	LimpMin = 0.6,        -- множитель скорости при 5 HP
	LimpMax = 0.85,       -- при 30 HP
	Punch = 7,            -- сила рывка камеры (градусы)
	VoiceCooldown = 1.2,
	Voices = {
		arm = {"myarm01.wav", "myarm02.wav"},
		leg = {"myleg01.wav", "myleg02.wav"},
		gut = {"mygut02.wav"},
		-- общие стоны: голова/прочее, и вперемешку с репликами про руку/ногу/живот
		generic = {"pain01.wav", "pain02.wav", "pain03.wav", "pain04.wav", "pain05.wav", "pain06.wav", "pain07.wav", "pain08.wav", "pain09.wav"},
	},
	VoicePartChance = 60, -- % что при попадании в руку/ногу/живот прозвучит реплика про часть тела, иначе стон
}
local pc = MES.PainConfig

local function decayed(ply, key, rate)
	local v = ply:GetNWFloat(key, 0)
	if v <= 0 then return 0 end
	return math.max(v - (CurTime() - ply:GetNWFloat(key .. "T", 0)) * rate, 0)
end

function MES.GetPain(ply)
	return IsValid(ply) and decayed(ply, "Pain", pc.PainDecay) or 0
end

function MES.GetPainShock(ply)
	return IsValid(ply) and decayed(ply, "Shock", pc.ShockDecay) or 0
end

-- без сознания / в рэгдолле - боль не действует (система отруба сборки)
local function knocked(ply)
	if not ply:Alive() then return true end
	if ply.getDarkRPVar and ply:getDarkRPVar("unconscious") then return true end
	if SERVER and ply.IsUncon and ply:IsUncon() then return true end
	return false
end
MES.PainKnocked = knocked

local function blocked(ply)
	return ply:GetNWFloat("NextActionTime", 0) > CurTime()
end

hook.Add("StartCommand", "MES.Pain", function(ply, cmd)
	if not IsValid(ply) or not ply:Alive() or not blocked(ply) or knocked(ply) then return end

	cmd:RemoveKey(IN_ATTACK)
	cmd:RemoveKey(IN_ATTACK2)
	cmd:RemoveKey(IN_JUMP)
end)

hook.Add("SetupMove", "MES.Pain", function(ply, mv)
	if not ply:Alive() or ply:InVehicle() or ply:GetMoveType() ~= MOVETYPE_WALK or knocked(ply) then return end

	local f = 1

	local shock = MES.GetPainShock(ply)
	if shock > 0 then
		f = f * math.Clamp(1 - shock / 100 * 0.9, 0.1, 1)
	end

	local hp = ply:Health()
	if hp <= pc.LimpHP then
		f = f * math.Clamp(math.Remap(hp, pc.LimpHP, 5, pc.LimpMax, pc.LimpMin), pc.LimpMin, pc.LimpMax)
	end

	if f >= 1 then return end

	mv:SetForwardSpeed(mv:GetForwardSpeed() * f)
	mv:SetSideSpeed(mv:GetSideSpeed() * f)
	mv:SetMaxClientSpeed(mv:GetMaxClientSpeed() * f)
	mv:SetMaxSpeed(mv:GetMaxSpeed() * f)
end)

if CLIENT then
	hook.Add("InputMouseApply", "MES.Pain", function(cmd, x, y)
		local ply = LocalPlayer()
		if not IsValid(ply) or not ply:Alive() or not blocked(ply) or knocked(ply) then return end

		cmd:SetMouseX(x * pc.BlockMouse)
		cmd:SetMouseY(y * pc.BlockMouse)
	end)

	local vig

	hook.Add("HUDPaint", "MES.PainShock", function()
		local ply = LocalPlayer()
		if not IsValid(ply) or not ply:Alive() or knocked(ply) then return end

		local shock = MES.GetPainShock(ply)
		if shock <= 0 then return end

		vig = vig or (DarkRP.Hud and DarkRP.Hud.Materials and DarkRP.Hud.Materials["vignette"]) or Material("msd/vignette.png", "nocull smooth")
		if not vig or vig:IsError() then return end

		local pulse = 0.6 + 0.4 * math.sin(CurTime() * 3)
		surface.SetMaterial(vig)
		surface.SetDrawColor(255, 20, 20, math.Clamp(shock * 2.5, 0, 255) * (0.7 + 0.3 * pulse))
		surface.DrawTexturedRect(0, 0, ScrW(), ScrH())
	end)

	hook.Add("RenderScreenspaceEffects", "MES.PainShock", function()
		local ply = LocalPlayer()
		if not IsValid(ply) or not ply:Alive() or knocked(ply) then return end

		local i = math.Clamp(MES.GetPainShock(ply) / 100 * 0.3, 0, 0.3)
		if i > 0.01 then DrawMotionBlur(0.2, i, 0.02) end
	end)

	return
end

--[[---------------------------------------------------------------------------
Сервер
---------------------------------------------------------------------------]]
local function setDecayed(ply, key, v)
	ply:SetNWFloat(key, v)
	ply:SetNWFloat(key .. "T", CurTime())
end

function MES.AddPain(ply, n)
	if not IsValid(ply) then return end
	setDecayed(ply, "Pain", math.Clamp(MES.GetPain(ply) + n, 0, pc.PainMax))
end

function MES.AddPainShock(ply, n)
	if not IsValid(ply) then return end
	setDecayed(ply, "Shock", math.Clamp(MES.GetPainShock(ply) + n, 0, pc.ShockMax))
end

function MES.ClearPain(ply)
	if not IsValid(ply) then return end
	ply:SetNWFloat("Pain", 0)
	ply:SetNWFloat("Shock", 0)
	ply:SetNWFloat("NextActionTime", 0)
	ply.MES_PainCD = nil
	ply.MES_PainHG, ply.MES_PainHGT = nil, nil
end

local function voiceSet(hg)
	if hg == HITGROUP_LEFTARM or hg == HITGROUP_RIGHTARM then return pc.Voices.arm end
	if hg == HITGROUP_LEFTLEG or hg == HITGROUP_RIGHTLEG then return pc.Voices.leg end
	if hg == HITGROUP_CHEST or hg == HITGROUP_STOMACH then return pc.Voices.gut end
end

local function painVoice(ply, hg)
	local set = voiceSet(hg)
	if not set or #set == 0 or math.random(100) > (pc.VoicePartChance or 60) then set = pc.Voices.generic end
	if not set or #set == 0 then return end

	local CT = CurTime()
	if (ply.MES_VoiceCD or 0) > CT then return end
	ply.MES_VoiceCD = CT + pc.VoiceCooldown

	local female = string.find(string.lower(ply:GetModel() or ""), "female", 1, true) ~= nil
	ply:EmitSound("vo/npc/" .. (female and "female01" or "male01") .. "/" .. set[math.random(#set)], 75, math.random(97, 103))
end
MES.PainVoice = painVoice

-- зона попадания пули (ScalePlayerDamage приходит раньше урона)
hook.Add("ScalePlayerDamage", "MES.PainVoice", function(ply, hg)
	ply.MES_PainHG = hg
	ply.MES_PainHGT = CurTime()
end)

hook.Add("PostEntityTakeDamage", "MES.Pain", function(ply, dmg, took)
	if not IsValid(ply) or not ply:IsPlayer() then return end

	local hg = ply.MES_PainHGT and ply.MES_PainHGT >= CurTime() - 0.05 and ply.MES_PainHG or nil
	ply.MES_PainHG, ply.MES_PainHGT = nil, nil

	if not took or not ply:Alive() or knocked(ply) then return end
	if dmg:IsDamageType(DMG_DROWN) then return end

	local am = dmg:GetDamage()
	if am < 1 then return end

	local CT = CurTime()

	-- боль: от всего, кроме пуль (как в pain.lua), броник гасит
	if not (dmg:IsDamageType(DMG_BULLET) or dmg:IsDamageType(DMG_BUCKSHOT)) and (ply.MES_PainCD or 0) <= CT then
		local mult = ply:Armor() > 0 and math.Clamp(1 - ply:Armor() / 100, 0.05, 1) or 1
		MES.AddPain(ply, am * pc.PainMul * mult)
		ply.MES_PainCD = CT + pc.PainCooldown
	end

	-- рывок камеры и "сбило дыхание" - не чаще раза в 0.5 сек (огонь, дробь, очереди)
	if (ply.MES_PunchCD or 0) <= CT then
		ply.MES_PunchCD = CT + 0.5

		local p = pc.Punch
		ply:ViewPunch(Angle(math.Rand(-p, p), math.Rand(-p, p), math.Rand(-2, 2)))

		if math.random(100) <= pc.BlockChance then
			ply:SetNWFloat("NextActionTime", CT + pc.BlockTime)
			MES.AddPainShock(ply, pc.ShockAdd)
		end
	end

	-- голос: от пуль/дроби всегда (зона попадания - если известна), от прочего - только с зоной
	if hg or dmg:IsDamageType(DMG_BULLET) or dmg:IsDamageType(DMG_BUCKSHOT) then painVoice(ply, hg) end
end)

hook.Add("PlayerDeath", "MES.Pain", MES.ClearPain)
hook.Add("PlayerSpawn", "MES.Pain", MES.ClearPain)

-- потерял сознание - боль и шок сбрасываются (как в pain.lua)
hook.Add("DarkRPVarChanged", "MES.Pain", function(ply, var, old, new)
	if var == "unconscious" and new and IsValid(ply) and ply:IsPlayer() then MES.ClearPain(ply) end
end)
