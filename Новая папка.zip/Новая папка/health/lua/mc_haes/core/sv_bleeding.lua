-- N.Y. Noire, шаг 44: кровотечение по присланному bleedingg.lua, подключено к системам MES / DarkRP.
--   Начинается от пуль (и дроби) и порезов: sv_damage.lua (handlers.bullet / handlers.slash) -> MES.Bleed(ply).
--     Пуля в жилет (зоны брони MES) или порез в бронежилете - кровотечение только с шансом BleedArmor %.
--     Травматика (police_beanbag) не ранит. Ножи mlw_* и кейс выдают статус "bleeding" сами - это тоже рана.
--   Каждые BleedDamageDelay сек. -BleedDamage HP (без сознания - нет), каждые BleedDecalDelay сек. - пятно крови
--     под человеком (без сознания - под телом), у стоящего - капли крови (cl_bleeding.lua).
--     Уровень крови при кровотечении падает, как раньше (sv_damage.lua, cfg.BleedBlood).
--   Проходит само через BleedTimeout сек. после последней раны (тату b2 "Бескровность" - в разы быстрее)
--     или при полном здоровье. Бинты (свои и медика) и админ-реанимация снимают сразу.
--   Умер - тело ещё кровит пятнами до конца срока. NPC тоже кровоточат (урон от мира, пятна).
--   Для HUD / осмотра / бинтов - временный статус "bleeding" (hungermod), его срок = последняя рана + BleedTimeout.
-- MES.Bleed(ent) - новая рана (старые вызовы MES.Bleed(ply, сек, уровень) тоже работают), MES.StopBleeding(ent).
util.AddNetworkString("MES.BleedDrops")

MES.DamageConfig = MES.DamageConfig or {}

local cfg = MES.DamageConfig
cfg.BleedDamage = cfg.BleedDamage or 4 -- HP
cfg.BleedDamageDelay = cfg.BleedDamageDelay or 6 -- сек.
cfg.BleedDecalDelay = cfg.BleedDecalDelay or 3.5 -- сек.
cfg.BleedTimeout = cfg.BleedTimeout or 40 -- сек. после последней раны
cfg.BleedArmor = cfg.BleedArmor or 18 -- % (в скрипте: 30% и ещё 60% при броне)
cfg.BleedB2 = cfg.BleedB2 or 0.3 -- тату "Бескровность": срок * 0.3

MES.Bleeds = MES.Bleeds or {}

local bleeds = MES.Bleeds
local down = Vector(0, 0, 200)

local function tatoo(ply, id)
	return MCR and MCR.HasTatoo and MCR.HasTatoo(ply, id) or false
end

local function uncon(ply)
	return ply.IsUncon and ply:IsUncon() or false
end

local function ragPos(rag)
	local phys = rag:GetPhysicsObjectNum(0)
	return IsValid(phys) and phys:GetPos() or rag:GetPos()
end

local function timeout(ent)
	if ent:IsPlayer() and tatoo(ent, "b2") then return cfg.BleedTimeout * cfg.BleedB2 end
	return cfg.BleedTimeout
end

-- статус "bleeding": истекает через timeout после последней раны (hungermod снимет сам)
local function setStat(ply, untilT)
	if not ply:getDarkRPVar("bleeding") then
		ply.MES_BleedSet = true
		ply:AddTempStat("bleeding", math.max(untilT - CurTime(), 1))
		ply.MES_BleedSet = nil
	end

	ply.TempStats = ply.TempStats or {}
	ply.TempStats.bleeding = untilT
end

function MES.Bleed(ent)
	if not IsValid(ent) or not (ent:IsPlayer() or ent:IsNPC()) then return end
	if ent:IsPlayer() and not ent:Alive() then return end
	if ent:IsNPC() and ent:Health() <= 0 then return end

	local CT = CurTime()
	local b = bleeds[ent]

	if b then
		b.last = CT
	else
		bleeds[ent] = {last = CT, nextDmg = CT + cfg.BleedDamageDelay, nextDecal = CT + cfg.BleedDecalDelay}
	end

	if ent:IsPlayer() then setStat(ent, CT + timeout(ent)) end
end

function MES.StopBleeding(ent)
	if not IsValid(ent) then return end

	bleeds[ent] = nil
	if ent:IsPlayer() and ent:getDarkRPVar("bleeding") then ent:RemoveTempStat("bleeding") end
end

-- ножи mlw_*, кейс и т.п. выдают статус сами (AddTempStat) - считаем это раной
hook.Add("DarkRP.TempStatAdded", "MES.Bleed", function(ply, stat)
	if stat ~= "bleeding" or ply.MES_BleedSet then return end
	MES.Bleed(ply)
end)

-- статус сняли (бинты, медик, админ, срок вышел). Смерть: hungermod снимает все статусы, а тело ещё кровит
hook.Add("DarkRP.TempStatRemoved", "MES.Bleed", function(ply, stat)
	if stat ~= "bleeding" then return end

	local b = bleeds[ply]
	if not b then return end

	if ply:Alive() then
		bleeds[ply] = nil
	else
		b.dead = true
	end
end)

hook.Add("PlayerDeath", "MES.Bleed", function(ply)
	local b = bleeds[ply]
	if b then b.dead = true end
end)

hook.Add("PlayerSpawn", "MES.Bleed", function(ply) bleeds[ply] = nil end)
hook.Add("MCR.CharacterUnloaded", "MES.Bleed", function(ply) bleeds[ply] = nil end)

-- NPC: от пуль и порезов
hook.Add("PostEntityTakeDamage", "MES.BleedNPC", function(ent, dmg, took)
	if not took or not IsValid(ent) or not ent:IsNPC() or not MES.DamageKind then return end

	local kind = MES.DamageKind(dmg)
	if kind == "bullet" or kind == "slash" then MES.Bleed(ent) end
end)

--[[---------------------------------------------------------------------------
Тик: урон, пятна крови, капли
---------------------------------------------------------------------------]]
local function bloodDecal(ent, target, pos)
	local tr = util.TraceLine({start = pos, endpos = pos - down, filter = {ent, target}})

	if tr.Hit then
		util.Decal("Blood", tr.HitPos + tr.HitNormal, tr.HitPos - tr.HitNormal, {ent, target})
	end
end

-- админ в невидимости / ноуклипе - не кровит
local function hidden(ply)
	return ply.DarkRPHidden or (ply:GetMoveType() == MOVETYPE_NOCLIP and not uncon(ply))
end

local function hurt(ply, n)
	if MES.Hurt then return MES.Hurt(ply, n, "bleeding") end

	local hp = ply:Health() - n
	if hp <= 0 then ply:Kill() else ply:SetHealth(hp) end
end

local function tickPlayer(ply, b, CT)
	if not ply:getDarkRPVar("bleeding") then
		bleeds[ply] = nil
		return
	end

	if ply:Health() >= ply:GetMaxHealth() or CT - b.last > timeout(ply) then
		MES.StopBleeding(ply)
		return
	end

	if hidden(ply) or not ply:getDarkRPVar("character") then return end

	local ko = uncon(ply)

	if not ko and CT >= b.nextDmg then
		b.nextDmg = CT + cfg.BleedDamageDelay
		hurt(ply, cfg.BleedDamage)
		if not ply:Alive() then return end
	end

	if CT < b.nextDecal then return end
	b.nextDecal = CT + cfg.BleedDecalDelay

	if ply:InVehicle() then return end

	local rag = ply.UnconRagdoll

	if ko and IsValid(rag) then
		bloodDecal(ply, rag, ragPos(rag))
		return
	end

	bloodDecal(ply, ply, ply:WorldSpaceCenter())

	if not ko then
		net.Start("MES.BleedDrops")
		net.WriteEntity(ply)
		net.SendPVS(ply:GetPos())
	end
end

timer.Create("MES.Bleeding", 0.25, 0, function()
	local CT = CurTime()
	local list = {}

	for ent in pairs(bleeds) do list[#list + 1] = ent end

	for _, ent in ipairs(list) do
		local b = bleeds[ent]
		if not b then continue end

		if not IsValid(ent) then
			bleeds[ent] = nil
			continue
		end

		if ent:IsPlayer() and not b.dead and ent:Alive() then
			tickPlayer(ent, b, CT)
			continue
		end

		if CT - b.last > timeout(ent) then
			bleeds[ent] = nil
			continue
		end

		-- умерший игрок: дальше кровит его тело (пятнами)
		if ent:IsPlayer() then
			local rag = ent.DeathRagdoll

			if IsValid(rag) then
				bleeds[ent] = nil
				bleeds[rag] = {corpse = true, last = b.last, nextDecal = b.nextDecal}
			end

			continue
		end

		if not b.corpse and CT >= b.nextDmg then
			b.nextDmg = CT + cfg.BleedDamageDelay
			if ent:Health() > 0 then ent:TakeDamage(cfg.BleedDamage, game.GetWorld(), game.GetWorld()) end
		end

		if CT >= b.nextDecal and IsValid(ent) then
			b.nextDecal = CT + cfg.BleedDecalDelay
			bloodDecal(ent, ent, b.corpse and ragPos(ent) or ent:WorldSpaceCenter())
		end
	end
end)
