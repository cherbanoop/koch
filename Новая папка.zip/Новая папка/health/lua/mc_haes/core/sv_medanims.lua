-- Шаг 21. Анимации медицины (по мотивам RP/lua/weapons/weapon_BetterMedkit.lua:
--   там во время перевязки/СЛР/физраствора игрок садится в "roofidle1" и не может крутить камерой).
--   У нас: помощь лежащему (без сознания / труп / СЛР) - на колено (первая найденная секвенция из Kneel),
--   помощь стоящему - жест "передать", на себе (бинт, препарат, таблетки) - жест к телу.
--   Анимация держится столько, сколько идёт действие (DarkRPVar rice_anim / rice_anim_n, noireanims/cl_anims.lua).
--   Шаг 24: везде (препараты, бинты, помощь медика, СЛР) - поза "roofidle1" (noireanims/sh_roofidle.lua,
--   DarkRP.RoofIdle). Старые варианты ниже - запасные, если у модели нет roofidle1.
MES = MES or {}

MES.AnimConfig = MES.AnimConfig or {
	Kneel = {"d1_town05_Daniels_Kneel_Idle", "roofidle1", "kneeldown2loop", "kneeldownloop", "d2_coast03_PreBattle_Kneel_Idle", "pose_ducking_02", "pose_ducking_01"},
	CPR = {"roofidle1", "d1_town05_Daniels_Kneel_Idle", "kneeldown2loop", "kneeldownloop", "pose_ducking_02"},
	HealStanding = ACT_GMOD_GESTURE_ITEM_GIVE,
	SelfUse = ACT_GMOD_GESTURE_ITEM_PLACE,
	Drug = ACT_GMOD_GESTURE_ITEM_GIVE,
	DrugTime = 2, -- шаг 24: сколько сек держать roofidle1 при вводе препарата
}
local acfg = MES.AnimConfig

function MES.Gesture(ply, act)
	if not IsValid(ply) or not act then return end
	DarkRP.UIEffect(nil, "_DarkRP_CustomAnim", {ply:UserID(), act})
end

local function findSeq(ply, list)
	for _, name in ipairs(list or {}) do
		local seq = ply:LookupSequence(name)
		if seq and seq > 0 then return name end
	end
end

-- держать секвенцию time секунд (стоять на месте)
function MES.HoldAnim(ply, list, time)
	if DarkRP.RoofIdle and DarkRP.RoofIdle(ply, time, true) then return DarkRP.RoofIdleSeq end
	local name = findSeq(ply, list)
	ply:SetDarkRPVar("rice_anim_n", name or "")
	ply:SetDarkRPVar("rice_anim", CurTime() + time)
	if name then DarkRP.UIEffect(nil, "plyAnimSetCycle", {ply:UserID()}) end
	return name
end

-- medic лечит ply (rag - его тело, если лежит) time секунд
function MES.PlayHealAnim(medic, ply, rag, time, cpr)
	if not IsValid(medic) then return end
	time = time or 2

	if DarkRP.RoofIdle and DarkRP.RoofIdle(medic, time, true) then return end

	if not IsValid(ply) or ply == medic then
		MES.Freeze(medic, time)
		MES.Gesture(medic, acfg.SelfUse)
		return
	end

	local lying = IsValid(rag) or not ply:Alive() or ply:getDarkRPVar("unconscious")
	if lying then
		MES.HoldAnim(medic, cpr and acfg.CPR or acfg.Kneel, time)
	else
		MES.Freeze(medic, time)
		MES.Gesture(medic, acfg.HealStanding)
	end
end

-- препарат / таблетки / шприц из инвентаря
function MES.DrugAnim(ply, d)
	if not IsValid(ply) or (d and d.smoke) then return end
	if DarkRP.RoofIdle and DarkRP.RoofIdle(ply, MES.AnimConfig.DrugTime or 2, true) then return end
	MES.Gesture(ply, acfg.Drug)
end
