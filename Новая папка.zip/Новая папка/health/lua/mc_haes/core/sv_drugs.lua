-- "addons\\health\\lua\\mc_haes\\core\\sv_drugs.lua"
-- Вещества: наркотики, таблетки, повязки, курение, передозировка, зависимость.
--   Предметы INV_JUNK (spawnlist/junk.lua) применяются из инвентаря: hook "McINV.UseItem" -> MES.Drugs[класс]
--     {kind = "opioid" | "stim", drug, stats = {статус = сек.}, addict, tox, od (% передоза), odMul, snd, me,
--      skin (рот не нужен: уколы, повязка), log (в логи), smoke (ключ MES.Smokes), check(ply, item) -> ok, why,
--      fn(ply, item) - после дозы, own(ply, item, type) - всё делает сам и сам тратит предмет}
--   Статусы (hungermod AddTempStat): relax - под воздействием, morph/heroin - опиоиды (обезболивают), coca/meth - стимуляторы,
--     stamina, focus (взлом), nark (LSD: чат вперемешку), nausea, cough, smoke, narcan (налоксон: опиоиды не действуют).
--   Зависимость: DarkRPVar "addict" (self, 0 - AddictMax), ply:AddAddiction(n, drug), ply:GetAddiction().
--     Не под воздействием падает на AddictDecay в минуту, с Withdrawal - ломка. Живёт с персонажем, после смерти - доля AddictDeath.
--   Передозировка - риск растёт от смеси веществ и алкоголя, зависимость даёт толерантность. DarkRPVar "overdose" (self):
--     через ODUnconDelay без сознания, через ODTime смерть (таймер ply:UserID() .. "overdose", его же снимает налоксон).
--     Налоксон (опиоиды) / адреналин (стимуляторы) из аптечки откачивают, морфин при передозе - смерть (sh_config.lua).
--   Курение: DarkRPVar "mouth" (публичная: cigar/sigar/joint/pipe - модель во рту) + статус "smoke", нужна зажигалка.
--     Затяжка раз в MES.Smokes[k].delay, дым видят игроки рядом (UIEffect "smoke"). Вода и маска тушат, /putout - потушить.
-- Хуки: MES.ItemUsed(ply, class, item) - предмет применён, MES.Addiction(ply, n, drug) - зависимость выросла.
local pmeta = FindMetaTable("Player")

MES.DrugConfig = MES.DrugConfig or {}

local cfg = MES.DrugConfig
cfg.AddictMax = cfg.AddictMax or 200
cfg.AddictDecay = cfg.AddictDecay or 1 -- в минуту
cfg.AddictDeath = cfg.AddictDeath or 0 -- шаг 38: после смерти / респавна зависимость снимается (было 0.5 - оставалась половина)
cfg.Withdrawal = cfg.Withdrawal or 30 -- с этого уровня - ломка
cfg.ODTime = cfg.ODTime or 90 -- сек. от передоза до смерти
cfg.ODUnconDelay = cfg.ODUnconDelay or {5, 10}
cfg.ODWake = cfg.ODWake or {10, 20} -- откачали - очнётся через
cfg.SmokeRange = cfg.SmokeRange or 1200 -- дым видно
cfg.SleepDelay = cfg.SleepDelay or 30 -- снотворное (pills3)
cfg.SleepTime = cfg.SleepTime or 45
cfg.BandageTime = cfg.BandageTime or 3
cfg.KarmaDelay = cfg.KarmaDelay or 300 -- карма за курение не чаще
cfg.PillKarmaDelay = cfg.PillKarmaDelay or 600 -- антидепрессант (pills2)

-- шаг 35: звуки из пака sound/player/ (addons/noire_sounds). Поменять - MES.Sounds в любом autorun.
MES.Sounds = MES.Sounds or {
	LighterOn = "player/lighter_on.wav", -- чирк + огонёк (сигарета, самокрутка), 1.8 с
	LighterOff = "player/lighter_off.wav", -- крышка зажигалки, 0.5 с
	LighterPipe = "player/lighter.wav", -- чирк, раскуривание и крышка (трубка), 4.3 с
	LighterLong = "player/lighter2.wav", -- долгое раскуривание (сигара), 5.9 с
	Bong = "player/bong.wav", -- бульканье бонга и выдох, 9 с
	Inhale = "player/breath_light.wav", -- затяжка
	Exhale = "player/exhale.wav", -- выдох дыма
	Snort = "player/use/snort.wav", -- вдохнуть порошок
	Syringe = "player/use/syringe.wav",
	Pills = "player/pills_here.mp3", -- баночка с таблетками
	Bandage = "player/heal.mp3",
	Drink = "eating_and_drinking/drinking.wav",
	StimBreath = {"player/breath_medium.wav", "player/breath_heavy.wav"}, -- тяжёлое дыхание под стимуляторами
}
local S = MES.Sounds

local sndSyringe = S.Syringe
local sndPills = S.Pills
local sndSnort = S.Snort
local sndBandage = S.Bandage
local sndDrink = S.Drink

local function roll(chance)
	return math.random(100) <= chance
end

local function tatoo(ply, id)
	return MCR and MCR.HasTatoo and MCR.HasTatoo(ply, id) or false
end

local function uncon(ply)
	return ply.IsUncon and ply:IsUncon() or false
end

local function unstat(ply, stat)
	if ply:getDarkRPVar(stat) then ply:RemoveTempStat(stat) end
end

--[[---------------------------------------------------------------------------
Инвентарь
---------------------------------------------------------------------------]]
local function findItem(ply, class)
	for _, v in ipairs(ply.inv and ply.inv[INV_JUNK] or {}) do
		if v.class == class then return v end
	end
end

-- потратить одну единицу (по ссылке: пока шло действие, номер в инвентаре мог смениться)
local function takeOne(ply, type, item)
	local list = ply.inv and ply.inv[type]
	if not list then return false end

	for i, v in ipairs(list) do
		if v ~= item then continue end

		if v.dt and v.dt.uses and v.dt.uses > 1 then
			local data = McINV.GetItem(type, v.class)

			v.dt.uses = v.dt.uses - 1
			v.weight = math.max((v.weight or 0) - (data and data.weight or 0), 0.01)
		else
			table.remove(list, i)
		end

		return true
	end

	return false
end

--[[---------------------------------------------------------------------------
Зависимость
---------------------------------------------------------------------------]]
function pmeta:GetAddiction()
	return tonumber(self:getDarkRPVar("addict")) or 0
end

local function setAddict(ply, n)
	n = math.Clamp(math.floor(tonumber(n) or 0), 0, cfg.AddictMax)

	if n <= 0 then
		ply:SetSelfDarkRPVar("addict", nil)
	elseif ply:getDarkRPVar("addict") ~= n then
		ply:SetSelfDarkRPVar("addict", n)
	end
end

-- drug - что принято (morph, heroin, coca...)
function pmeta:AddAddiction(n, drug)
	n = tonumber(n) or 0
	if n == 0 then return end

	setAddict(self, self:GetAddiction() + n)
	hook.Run("MES.Addiction", self, n, drug)
end

--[[---------------------------------------------------------------------------
Передозировка
---------------------------------------------------------------------------]]
local opioids = {"morph", "heroin"}
local stims = {"coca", "meth"}

local function any(ply, list)
	for _, stat in ipairs(list) do
		if ply:getDarkRPVar(stat) then return true end
	end

	return false
end

-- % передоза: сама доза + что уже в крови (считать до новых статусов)
local function odRisk(ply, d)
	if not d.kind or ply:getDarkRPVar("overdose") then return 0 end

	local risk = d.od or 0
	local op, st = any(ply, opioids), any(ply, stims)

	if d.kind == "opioid" then
		if ply:getDarkRPVar("narcan") then return 0 end
		if op then risk = risk + 45 end
		if st then risk = risk + 30 end -- спидбол
	elseif d.kind == "stim" then
		if st then risk = risk + 30 end
		if op then risk = risk + 30 end
	end

	if (tonumber(ply:getDarkRPVar("alcohol")) or 0) >= (tatoo(ply, "g4") and 90 or 60) then
		risk = risk + 25
	end

	risk = risk * (d.odMul or 1) - ply:GetAddiction() / 20

	return math.Clamp(risk, 0, 95)
end

local function odDeath(ply, time)
	timer.Create(ply:UserID() .. "overdose", math.max(time, 5), 1, function()
		if not IsValid(ply) or not ply:Alive() or not ply:getDarkRPVar("overdose") then return end

		if ply:HasGodMode() then
			MES.ClearOverdose(ply)
			return
		end

		ply.MES_Cause = "overdose"
		ply:Kill()
	end)
end

function MES.Overdose(ply, kind)
	if not IsValid(ply) or not ply:Alive() or ply:getDarkRPVar("overdose") then return end

	local CT = CurTime()
	local delay = math.random(cfg.ODUnconDelay[1], cfg.ODUnconDelay[2])

	ply.MES_ODKind = kind
	ply.MES_ODEnd = CT + cfg.ODTime
	ply:SetSelfDarkRPVar("overdose", true)

	DarkRP.UIEffect(ply, "overdose")
	MES.Shock(ply, 5)
	DarkRP.notify(ply, 1, 6, "Сердце бешено колотится, не хватает воздуха...")
	DarkRP.log("drugs", ply, nil, "передозировка", Color(255, 90, 160))

	timer.Create("MES.ODUncon" .. ply:UserID(), delay, 1, function()
		if not IsValid(ply) or not ply:Alive() or not ply:getDarkRPVar("overdose") then return end

		ply.MES_ODUncon = true
		ply:Ragdollize(cfg.ODTime - delay + 30, true)
	end)

	odDeath(ply, cfg.ODTime)
end

function MES.ClearOverdose(ply)
	timer.Remove(ply:UserID() .. "overdose")
	timer.Remove("MES.ODUncon" .. ply:UserID())

	if ply:getDarkRPVar("overdose") then ply:SetSelfDarkRPVar("overdose", nil) end
end

-- сняли (помощь медика, админ, смерть): таймеры прочь, откачанный приходит в себя
hook.Add("DarkRPVarChanged", "MES.Overdose", function(ply, var, old, new)
	if var ~= "overdose" or new ~= nil or not old then return end

	timer.Remove(ply:UserID() .. "overdose")
	timer.Remove("MES.ODUncon" .. ply:UserID())

	ply.MES_ODKind = nil
	ply.MES_ODEnd = nil

	if not ply.MES_ODUncon then return end
	ply.MES_ODUncon = nil

	if ply:Alive() and uncon(ply) then
		ply.UnconEnd = math.min(ply.UnconEnd or 0, CurTime() + math.random(cfg.ODWake[1], cfg.ODWake[2]))
	end
end)

-- налоксон - от опиоидов, адреналин - от стимуляторов (sh_config.lua снимает только при morph/heroin и coca)
hook.Add("MES.Healed", "MES.Drugs", function(medic, ply, k)
	local v = MES.ListHeal[k]
	if not v or not ply:Alive() or not ply:getDarkRPVar("overdose") then return end

	local stim = ply.MES_ODKind == "stim"

	if (v[1] == "Ввести налоксон" and not stim) or (v[1] == "Ввести адреналин" and stim) then
		MES.ClearOverdose(ply)
		return
	end

	-- налоксон при передозе стимулятором снял таймер (sh_config.lua) - смерть никуда не делась
	if not timer.Exists(ply:UserID() .. "overdose") then
		odDeath(ply, (ply.MES_ODEnd or CurTime()) - CurTime())
	end
end)

--[[---------------------------------------------------------------------------
Доза
---------------------------------------------------------------------------]]
local function dose(ply, d)
	if not d then return end

	local risk = odRisk(ply, d)

	if d.kind == "opioid" and ply:getDarkRPVar("narcan") then
		DarkRP.notify(ply, 1, 4, "Вы почти ничего не почувствовали")
		return
	end

	for stat, time in pairs(d.stats or {}) do
		ply:AddTempStat(stat, time)
	end

	if d.addict then ply:AddAddiction(d.addict, d.drug) end
	if d.tox then ply:AddToxity(d.tox) end

	if risk > 0 and roll(risk) then
		MES.Overdose(ply, d.kind)
	end
end

MES.Dose = dose

-- мет: после - отходняк
hook.Add("DarkRP.TempStatRemoved", "MES.Drugs", function(ply, stat)
	if stat == "smoke" then
		if ply.MES_Smoke then MES.StopSmoke(ply) end
		return
	end

	if stat ~= "meth" then return end

	-- следующим тиком: hungermod сейчас может обходить ply.TempStats
	timer.Simple(0, function()
		if not IsValid(ply) or not ply:Alive() or not ply:getDarkRPVar("character") then return end

		ply:AddTempStat("nausea", 60)
		ply:AddThirst(-50)
		DarkRP.notify(ply, 1, 4, "Действие проходит - накатывает слабость")
	end)
end)

-- шаг 35: под стимуляторами (мет, кокаин, крэк) иногда тяжело дышит - слышно рядом (MES.Sounds.StimBreath)
timer.Create("MES.StimBreath", 5, 0, function()
	local CT = CurTime()

	for _, ply in ipairs(player.GetAll()) do
		if not ply:Alive() or uncon(ply) or not (ply:getDarkRPVar("meth") or ply:getDarkRPVar("coca")) then
			ply.MES_StimBreath = nil
			continue
		end

		if not ply.MES_StimBreath then
			ply.MES_StimBreath = CT + math.Rand(8, 15)
			continue
		end

		if ply.MES_StimBreath > CT then continue end
		ply.MES_StimBreath = CT + math.Rand(20, 40)

		if not ply.MES_Smoke and MES.PlySound then MES.PlySound(ply, "StimBreath", 58) end
	end
end)

--[[---------------------------------------------------------------------------
Курение
---------------------------------------------------------------------------]]
-- {name - что тушат, me, mouth (MCR.Attachments.smoking), puffs - затяжек, delay - сек. между ними,
--  relax - сек. за затяжку, john - эффект "johnache" с первой, cough - % кашля за затяжку,
--  докурил: karma (не чаще KarmaDelay), tox, addict; dose - доза при закуривании (крэк)}
--  шаг 35: light - как прикуривать ("cig" - чирк + крышка, "pipe" - долго раскуривать трубку, "long" - сигара):
--  звук зажигалки + жест у лица с иммерсивной камерой на lightTime сек. (noireanims/sh_eatanim.lua)
MES.Smokes = {
	cigarette = {name = "сигарету", me = "закуривает сигарету", mouth = "cigar", puffs = 6, delay = 7, karma = 1, tox = 1, cough = 8, light = "cig"},
	sigar = {name = "сигару", me = "раскуривает сигару", mouth = "sigar", puffs = 10, delay = 7, karma = 2, tox = 2, cough = 5, light = "long"},
	joint = {name = "самокрутку", me = "закуривает самокрутку", mouth = "joint", puffs = 6, delay = 6, relax = 12, john = 20, cough = 20, addict = 2, drug = "weed", light = "cig"},
	pipe = {name = "трубку", me = "раскуривает трубку", mouth = "pipe", puffs = 8, delay = 7, karma = 1, tox = 1, cough = 6, light = "pipe"},
	weedpipe = {name = "трубку", me = "раскуривает трубку", mouth = "pipe", puffs = 5, delay = 6, relax = 15, john = 15, cough = 25, addict = 2, drug = "weed", light = "pipe"},
	crack = {name = "трубку", me = "раскуривает трубку", mouth = "pipe", puffs = 3, delay = 5, tox = 3, cough = 30, light = "pipe",
		dose = {kind = "stim", drug = "coca", stats = {coca = 45, relax = 45, stamina = 45}, addict = 20, od = 5}},
	-- шаг 35: метамфетамин через трубку (нужны трубка и зажигалка). Действует как пакетик, но сильнее бьёт по лёгким
	meth = {name = "трубку", me = "раскуривает трубку", mouth = "pipe", puffs = 4, delay = 5, tox = 3, cough = 25, light = "pipe",
		dose = {kind = "stim", drug = "meth", stats = {meth = 120, relax = 120, stamina = 120, focus = 120}, addict = 20, tox = 7}},
}

-- шаг 35: прикуривание {звук, сек. жеста (= примерно длина звука), звук крышки и через сколько сек}
MES.SmokeLight = MES.SmokeLight or {
	cig = {snd = "LighterOn", time = 2.2, close = "LighterOff", closeAt = 1.9},
	pipe = {snd = "LighterPipe", time = 4.3},
	long = {snd = "LighterLong", time = 5.5},
}

-- как в CanConsume: противогаз / сварочная маска / дыхательный аппарат
local function mouthBlocked(ply)
	local face = ply:getDarkRPVar("face")
	return (face and MCR and MCR.NoConsume and MCR.NoConsume[face]) or ply:getDarkRPVar("scba") == 1
end

local function smokeFX(ply)
	local pos = ply:GetPos()
	local recv = {}

	for _, v in ipairs(player.GetHumans()) do
		if v:GetPos():DistToSqr(pos) < cfg.SmokeRange ^ 2 then table.insert(recv, v) end
	end

	if #recv > 0 then DarkRP.UIEffect(recv, "smoke", {idx = ply:EntIndex()}) end
end

-- шаг 35: звук от игрока (S.* ключ или путь), через delay сек - если жив и всё ещё курит (check)
local function plySound(ply, snd, level, delay, check)
	snd = S[snd] or snd
	if istable(snd) then snd = snd[math.random(#snd)] end
	if not isstring(snd) or snd == "" then return end

	if not delay or delay <= 0 then
		ply:EmitSound(snd, level or 60)
		return
	end

	timer.Simple(delay, function()
		if not IsValid(ply) or not ply:Alive() then return end
		if check and not check(ply) then return end
		ply:EmitSound(snd, level or 60)
	end)
end
MES.PlySound = plySound

-- шаг 35: прикурить - звук зажигалки + жест у лица с иммерсивной камерой. -> сколько сек. длится
local function lightUp(ply, kind)
	local l = MES.SmokeLight[kind or "cig"] or MES.SmokeLight.cig

	plySound(ply, l.snd, 60)
	if l.close then plySound(ply, l.close, 55, l.closeAt) end
	if DarkRP.EatAnim then DarkRP.EatAnim(ply, l.time, true) end

	return l.time
end
MES.LightUp = lightUp

local function canSmoke(ply)
	if ply.MES_Smoke or ply:getDarkRPVar("mouth") then
		DarkRP.notify(ply, 1, 3, "Вы уже курите")
		return false
	end

	if ply:WaterLevel() >= 3 then
		DarkRP.notify(ply, 1, 3, "Под водой не закурить")
		return false
	end

	if not McINV.GetLighter(ply) then
		DarkRP.notify(ply, 1, 3, "Нужна зажигалка")
		return false
	end

	return true
end

function MES.StopSmoke(ply, msg)
	local was = ply.MES_Smoke or ply:getDarkRPVar("mouth")
	ply.MES_Smoke = nil

	if ply:getDarkRPVar("mouth") then ply:SetDarkRPVar("mouth", nil) end
	unstat(ply, "smoke")

	if was and msg then DarkRP.notify(ply, 1, 3, msg) end
end

function MES.StartSmoke(ply, k)
	local s = MES.Smokes[k]
	if not s or not IsValid(ply) or not ply:Alive() then return false end

	MES.StopSmoke(ply)

	-- шаг 35: прикуривание (звук + жест с камерой), первая затяжка - когда прикурил
	local light = lightUp(ply, s.light)

	ply.MES_Smoke = {k = k, s = s, left = s.puffs, n = 0, next = CurTime() + light + 0.5}
	ply:SetDarkRPVar("mouth", s.mouth)
	ply:AddTempStat("smoke", s.puffs * s.delay + light + 5)

	if s.me then MES.Me(ply, s.me) end
	if s.dose then dose(ply, s.dose) end

	return true
end

local function finish(ply, sm)
	local s = sm.s

	MES.StopSmoke(ply)

	if s.tox then ply:AddToxity(s.tox) end
	if s.addict then ply:AddAddiction(s.addict, s.drug) end

	if s.karma and ply.addKarma and (ply.MES_SmokeKarma or 0) <= CurTime() then
		ply.MES_SmokeKarma = CurTime() + cfg.KarmaDelay
		ply:addKarma(s.karma)
	end
end

local function puff(ply, sm, CT)
	local s = sm.s

	sm.n = sm.n + 1
	sm.left = sm.left - 1
	sm.next = CT + s.delay

	-- шаг 35: затяжка (жест без камеры), дым - через ~1.4 сек
	-- шаг 37: звуков вдоха/выдоха больше нет (вернуть: MES.PuffSounds = true)
	if MES.PuffSounds then plySound(ply, "Inhale", 55) end
	if DarkRP.EatAnim then DarkRP.EatAnim(ply, 1.5, false) end

	timer.Simple(1.4, function()
		if not IsValid(ply) or not ply:Alive() or uncon(ply) then return end
		smokeFX(ply)
		if MES.PuffSounds then plySound(ply, "Exhale", 60) end
	end)

	if s.relax then ply:AddTempStat("relax", s.relax) end
	if s.john and sm.n == 1 then DarkRP.UIEffect(ply, "johnache", {s.john}) end
	if s.cough and roll(s.cough) and MES.Cough then MES.Cough(ply) end

	if sm.left <= 0 then finish(ply, sm) end
end

timer.Create("MES.Smoke", 1, 0, function()
	local CT = CurTime()

	for _, ply in ipairs(player.GetAll()) do
		local sm = ply.MES_Smoke
		if not sm then continue end

		if not ply:Alive() or uncon(ply) or not ply:getDarkRPVar("mouth") then
			MES.StopSmoke(ply)
			continue
		end

		if ply:WaterLevel() >= 3 then
			MES.StopSmoke(ply, "Вода потушила " .. sm.s.name)
			continue
		end

		if mouthBlocked(ply) then
			MES.StopSmoke(ply, "Пришлось потушить " .. sm.s.name)
			continue
		end

		if sm.next <= CT then puff(ply, sm, CT) end
	end
end)

local function putOut(ply)
	local sm = ply.MES_Smoke

	if not sm and not ply:getDarkRPVar("mouth") then
		DarkRP.notify(ply, 1, 3, "Вы не курите")
		return ""
	end

	MES.StopSmoke(ply)
	if sm then MES.Me(ply, "тушит " .. sm.s.name) end

	return ""
end

local function registerCommands()
	if not DarkRP or not DarkRP.defineChatCommand then return end
	DarkRP.defineChatCommand("putout", putOut, 1)
end

registerCommands()
hook.Add("PostGamemodeLoaded", "MES.DrugCommands", registerCommands)

--[[---------------------------------------------------------------------------
Предметы
---------------------------------------------------------------------------]]
local function used(ply, item)
	local d = MES.Drugs[item.class]

	if d and d.log then
		local data = McINV.GetItem(INV_JUNK, item.class)
		DarkRP.log("drugs", ply, nil, "употребил " .. (data and data.name or item.class), Color(200, 140, 255))
	end

	hook.Run("MES.ItemUsed", ply, item.class, item)
end

local function smokeItem(ply, item, type, k)
	if not canSmoke(ply) or not takeOne(ply, type, item) then return false end

	ply.eatdelay = CurTime() + 2
	MES.StartSmoke(ply, k)
	used(ply, item)

	return true
end

local function needPipe(ply)
	if findItem(ply, "pipe") then return true end
	return false, "Нужна трубка"
end

local function rollJoint(ply, weed, paper)
	if not takeOne(ply, INV_JUNK, weed) then return false end
	takeOne(ply, INV_JUNK, paper)

	ply.eatdelay = CurTime() + 3
	MES.Me(ply, "скручивает самокрутку")
	ply:AddItemByClass(INV_JUNK, "joint", nil, true)

	return true
end

-- шаг 34: take() - потратить бинт (из инвентаря или сам бинт с пола), src - от чего не отходить
local function bandageStart(ply, item, src, take)
	if not ply:getDarkRPVar("bleeding") and ply:Health() >= ply:GetMaxHealth() then
		DarkRP.notify(ply, 1, 3, "Вам не нужна перевязка")
		return false
	end

	local started = DarkRP.ProgressAction(ply, src, cfg.BandageTime, 150, function()
		MES.Freeze(ply)

		if not ply:Alive() or not take() then return end
		McINV.QueueSend(ply)

		MES.StopBleeding(ply)
		ply:AddTempStat("meds3", 60)
		ply:SetHealth(math.min(ply:Health() + 5, ply:GetMaxHealth()))
		used(ply, item)
	end, function()
		MES.Freeze(ply)
		DarkRP.notify(ply, 1, 3, "Действие прервано")
	end)

	if not started then return false end

	-- шаг 24: поза roofidle1 на всё время перевязки (иначе как раньше - замереть + жест)
	if not (DarkRP.RoofIdle and DarkRP.RoofIdle(ply, cfg.BandageTime, true)) then
		MES.Freeze(ply, cfg.BandageTime)
		if MES.Gesture and MES.AnimConfig then MES.Gesture(ply, MES.AnimConfig.SelfUse) end
	end
	ply:EmitSound(sndBandage, 60)
	MES.Me(ply, "накладывает себе повязку")

	-- потратится по завершении
	return false
end

local function bandage(ply, item, type)
	return bandageStart(ply, item, ply, function() return takeOne(ply, type, item) end)
end

-- шаг 34: E по бинту на полу (inventory/sv_flooruse.lua) - та же перевязка, тратится бинт с пола.
-- Бинт подобрали / убрали, пока идёт перевязка - "Действие прервано".
local function bandageFloor(ply, ent, item)
	return bandageStart(ply, item, ent, function()
		if not IsValid(ent) or ent.McINV_Picked then return false end

		ent.McINV_Picked = true
		ent:Remove()
		DarkRP.log("items", ply, nil, "использовал с пола " .. McINV.prt(item, INV_JUNK))

		return true
	end)
end

local function sleep(ply)
	local name = "MES.Sleep" .. ply:UserID()
	if timer.Exists(name) then return end

	timer.Create(name, cfg.SleepDelay, 1, function()
		if not IsValid(ply) or not ply:Alive() or not ply:getDarkRPVar("character") then return end

		if ply:getDarkRPVar("coca") or ply:getDarkRPVar("meth") or ply:getDarkRPVar("adren") then
			DarkRP.notify(ply, 1, 3, "Веки тяжелеют, но сердце не даёт уснуть")
			return
		end

		DarkRP.notify(ply, 1, 4, "Глаза закрываются сами собой...")
		ply:Ragdollize(cfg.SleepTime, true)
	end)
end

local syringe = "делает себе укол"
local snort = "вдыхает порошок"
local pill = "принимает таблетку"

MES.Drugs = {
	-- опиоиды
	["dry_opium_small"] = {kind = "opioid", drug = "morph", stats = {morph = 60, relax = 60}, addict = 10, skin = true, snd = sndSyringe, me = syringe, log = true},
	["done_heroin_syr"] = {kind = "opioid", drug = "heroin", stats = {heroin = 120, relax = 120}, addict = 25, tox = 5, od = 5, skin = true, snd = sndSyringe, me = syringe, log = true},
	["done_heroin_small"] = {kind = "opioid", drug = "heroin", stats = {heroin = 90, relax = 90}, addict = 20, tox = 5, od = 5, snd = sndSnort, me = snort, log = true},
	["fentanyl"] = {kind = "opioid", drug = "fentanyl", stats = {morph = 90, relax = 90}, addict = 30, tox = 10, od = 25, skin = true, snd = sndSyringe, me = syringe, log = true},
	-- стимуляторы
	["done_coca_small"] = {kind = "stim", drug = "coca", stats = {coca = 90, relax = 90, stamina = 90}, addict = 15, snd = sndSnort, me = snort, log = true},
	-- шаг 35: есть трубка и зажигалка - мет курится через трубку (MES.Smokes.meth), нет - вдыхается, как раньше
	["done_meth_small"] = {kind = "stim", drug = "meth", stats = {meth = 120, relax = 120, stamina = 120, focus = 120}, addict = 20, tox = 10, snd = sndSnort, me = snort, log = true, pipe = "meth"},
	["craft_coca_small"] = {smoke = "crack", check = needPipe, log = true},
	-- курение
	["dry_tabacco_small"] = {smoke = "pipe", check = needPipe},
	["sigar"] = {smoke = "sigar"},
	["joint"] = {smoke = "joint", log = true},
	["dry_weed_small"] = {log = true, own = function(ply, item, type)
		local pipe = findItem(ply, "pipe")
		if pipe and McINV.GetLighter(ply) then return smokeItem(ply, item, type, "weedpipe") end

		local paper = findItem(ply, "paper")
		if paper then return rollJoint(ply, item, paper) end

		DarkRP.notify(ply, 1, 4, pipe and "Нужна зажигалка" or "Нужна трубка или бумага для самокрутки")
		return false
	end},
	-- трубка: забить что есть
	["pipe"] = {own = function(ply)
		for _, v in ipairs({{"dry_tabacco_small", "pipe"}, {"dry_weed_small", "weedpipe"}, {"craft_coca_small", "crack"}, {"done_meth_small", "meth"}}) do
			local stuff = findItem(ply, v[1])
			if stuff then return smokeItem(ply, stuff, INV_JUNK, v[2]) end
		end

		DarkRP.notify(ply, 1, 4, "Нечего забить в трубку")
		return false
	end},
	["paper"] = {skin = true, own = function(ply, item)
		local weed = findItem(ply, "dry_weed_small")
		if weed then return rollJoint(ply, weed, item) end

		DarkRP.notify(ply, 1, 4, "Нечего скрутить")
		return false
	end},
	["bong"] = {log = true, own = function(ply, item, type)
		if not McINV.GetLighter(ply) then
			DarkRP.notify(ply, 1, 3, "Нужна зажигалка")
			return false
		end

		if not takeOne(ply, type, item) then return false end

		-- шаг 35: зажигалка + бульканье (bong.wav ~9 с), жест с камерой, дым и кашель - на выдохе
		ply.eatdelay = CurTime() + 8
		plySound(ply, "LighterOn", 55)
		plySound(ply, "Bong", 65, 0.6)
		if DarkRP.EatAnim then DarkRP.EatAnim(ply, 7.5, true) end
		MES.Me(ply, "затягивается из бонга")

		ply:AddTempStat("relax", 40)
		ply:AddAddiction(3, "weed")

		local cough = roll(60)

		timer.Simple(7.8, function()
			if not IsValid(ply) or not ply:Alive() then return end

			smokeFX(ply)
			DarkRP.UIEffect(ply, "johnache", {12})

			if cough and MES.Cough then
				MES.Cough(ply)
				ply:AddTempStat("cough", 6)
			end
		end)

		used(ply, item)
		return true
	end},
	-- таблетки: этикетка ничего не говорит, действие узнаётся опытным путём
	["pills0"] = {snd = sndPills, me = pill, fn = function(ply)
		DarkRP.notify(ply, 0, 3, "Кажется, ничего не изменилось")
	end},
	["pills1"] = {snd = sndPills, me = pill, fn = function(ply)
		ply:AddAlcohol(-60)
		unstat(ply, "nausea")
	end},
	["pills2"] = {snd = sndPills, me = pill, fn = function(ply)
		if (ply.MES_PillKarma or 0) > CurTime() then
			ply:AddTempStat("nausea", 30)
			return
		end

		ply.MES_PillKarma = CurTime() + cfg.PillKarmaDelay
		if ply.addKarma then ply:addKarma(5) end
	end},
	["pills3"] = {snd = sndPills, me = pill, fn = sleep},
	["pills4"] = {kind = "opioid", drug = "morph", stats = {morph = 45}, addict = 2, odMul = 0.3, snd = sndPills, me = pill},
	["pills5"] = {snd = sndPills, me = pill, fn = function(ply)
		ply:AddToxity(-50)
		unstat(ply, "nausea")
	end},
	["pills6"] = {snd = sndPills, me = pill, fn = function(ply)
		if ply:getDarkRPVar("stamina") or ply:getDarkRPVar("coca") or ply:getDarkRPVar("meth") then
			ply:AddTempStat("nausea", 30)
			DarkRP.notify(ply, 1, 3, "Сердце колотится, подташнивает")
		end

		ply:AddTempStat("stamina", 60)
		ply:AddTempStat("focus", 90)
	end},
	["pills7"] = {snd = sndPills, me = pill, fn = function(ply)
		unstat(ply, "cough")
	end},
	["pills8"] = {snd = sndPills, me = pill, log = true, fn = function(ply)
		if not ply:getDarkRPVar("nark") then DarkRP.UIEffect(ply, "lsd") end

		ply:AddTempStat("nark", 180)
		ply:AddTempStat("relax", 180)
		ply:AddAddiction(5, "lsd")
	end},
	["headcure"] = {snd = sndDrink, me = "выпивает лекарство", fn = function(ply)
		unstat(ply, "nausea")
		unstat(ply, "shock")
		ply:AddAlcohol(-20)
	end},
	["bandage"] = {skin = true, own = bandage, floor = bandageFloor},
}

for _, class in ipairs({"pack_paddolo", "pack_jamal", "pack_whisher", "pack_bigc", "pack_noir"}) do
	MES.Drugs[class] = {smoke = "cigarette"}
end

-- true - применено (инвентарь уйдёт клиенту), false - отказ
local function useItem(ply, type, item)
	local d = MES.Drugs[item.class]

	if not MES.CanAct(ply) or uncon(ply) then return false end
	if DarkRP.NetDelay(ply, "MES.Drug", 1) then return false end

	if d.skin then
		if ply.eatdelay and ply.eatdelay > CurTime() then return false end
	elseif not ply:CanConsume() then
		return false
	end

	if d.check then
		local ok, why = d.check(ply, item)

		if not ok then
			if why then DarkRP.notify(ply, 1, 4, why) end
			return false
		end
	end

	if d.own then return d.own(ply, item, type) and true or false end
	if d.smoke then return smokeItem(ply, item, type, d.smoke) end
	-- шаг 35: можно и покурить (мет): трубка + зажигалка в инвентаре
	if d.pipe and findItem(ply, "pipe") and McINV.GetLighter(ply) then return smokeItem(ply, item, type, d.pipe) end

	if not takeOne(ply, type, item) then return false end

	ply.eatdelay = CurTime() + (d.delay or 2)

	if d.snd then ply:EmitSound(d.snd, 60) end
	if d.me then MES.Me(ply, d.me) end
	if MES.DrugAnim then MES.DrugAnim(ply, d) end

	dose(ply, d)
	if d.fn then d.fn(ply, item) end

	used(ply, item)

	return true
end

hook.Add("McINV.UseItem", "MES.Drugs", function(ply, type, item)
	if type ~= INV_JUNK or not istable(item) or not MES.Drugs[item.class] then return end
	return useItem(ply, type, item)
end)

--[[ шаг 35: с пола (E) можно применить только часть веществ. Значение:
	true - как из инвентаря; "lighter" - нужна зажигалка в инвентаре; "pipe" - нужны трубка и зажигалка.
	Мет с пола - только через трубку. Уколы и порошки (героин, кокаин, опиум, фентанил) с пола - нет, только подобрать ключами. ]]
MES.FloorDrugs = MES.FloorDrugs or {
	["done_meth_small"] = "pipe",
	["craft_coca_small"] = "pipe",
	["dry_tabacco_small"] = "pipe",
	["dry_weed_small"] = "pipe",
	["sigar"] = "lighter",
	["joint"] = "lighter",
	["bong"] = "lighter",
	["bandage"] = true,
	["headcure"] = true,
}

for i = 0, 8 do
	if MES.FloorDrugs["pills" .. i] == nil then MES.FloorDrugs["pills" .. i] = true end
end

for _, class in ipairs({"pack_paddolo", "pack_jamal", "pack_whisher", "pack_bigc", "pack_noir"}) do
	if MES.FloorDrugs[class] == nil then MES.FloorDrugs[class] = "lighter" end
end

-- можно ли вообще применить с пола (inventory/sv_flooruse.lua McINV.CanUseFromFloor)
function MES.CanFloorUse(class)
	return MES.Drugs[class] ~= nil and (MES.FloorDrugs[class] or false) ~= false
end

-- шаг 34: E по предмету на полу (modules/inventory/sv_flooruse.lua). Свой вариант есть только у бинта (floor),
-- остальное (таблетки, препараты, курево) идёт обычным путём: на миг в карман -> McINV.UseItem.
-- nil - не наш случай, true / false - обработано
function MES.FloorUse(ply, ent, item, type)
	local d = istable(item) and MES.Drugs[item.class]
	if not d then return nil end

	-- шаг 35: только разрешённое и с нужными вещами в инвентаре
	local need = MES.FloorDrugs[item.class]
	if not need then return false end

	if need == "pipe" and not findItem(ply, "pipe") then
		DarkRP.notify(ply, 1, 3, "Нужна трубка")
		return false
	end

	if (need == "pipe" or need == "lighter") and not McINV.GetLighter(ply) then
		DarkRP.notify(ply, 1, 3, "Нужна зажигалка")
		return false
	end

	if not d.floor then return nil end

	if not MES.CanAct(ply) or uncon(ply) then return false end
	if DarkRP.NetDelay(ply, "MES.Drug", 1) then return false end
	if d.skin and ply.eatdelay and ply.eatdelay > CurTime() then return false end

	return d.floor(ply, ent, item, type) and true or false
end

--[[---------------------------------------------------------------------------
Ломка
---------------------------------------------------------------------------]]
timer.Create("MES.Addiction", 60, 0, function()
	local CT = CurTime()

	for _, ply in ipairs(player.GetAll()) do
		local a = ply:GetAddiction()
		if a <= 0 or not ply:Alive() or not ply:getDarkRPVar("character") then continue end

		-- под воздействием зависимость не уходит
		if ply:getDarkRPVar("relax") then continue end

		setAddict(ply, a - cfg.AddictDecay)

		if a < cfg.Withdrawal or uncon(ply) then continue end

		ply:AddTempStat("nausea", 30)
		MES.Shock(ply, 3)

		if (ply.MES_WithdrawMsg or 0) <= CT then
			ply.MES_WithdrawMsg = CT + 300
			DarkRP.notify(ply, 1, 6, a >= 100 and "Ломает всё тело. Нужна доза..." or "Знобит и подташнивает. Хочется чего-нибудь принять")
		end

		if a >= 100 and ply.addKarma and roll(30) then ply:addKarma(-1) end
	end
end)

--[[---------------------------------------------------------------------------
Смерть / персонаж
---------------------------------------------------------------------------]]
local function clearDrugs(ply)
	timer.Remove("MES.Sleep" .. ply:UserID())

	MES.ClearOverdose(ply)
	MES.StopSmoke(ply)

	ply.MES_ODKind = nil
	ply.MES_ODUncon = nil
end

hook.Add("PlayerDeath", "MES.Drugs", function(ply)
	clearDrugs(ply)
	ply.MES_DrugDied = true

	-- шаг 38: зависимость и ломка уходят сразу после смерти
	if (cfg.AddictDeath or 0) <= 0 then
		setAddict(ply, 0)
		ply.MES_WithdrawMsg = nil
	end
end)

hook.Add("PlayerSpawn", "MES.Drugs", function(ply)
	local died = ply.MES_DrugDied
	ply.MES_DrugDied = nil

	-- реанимация (sv_init.lua MES.Revive): всё как было
	if ply.MES_Revive then return end

	clearDrugs(ply)

	if died and ply:GetAddiction() > 0 then
		setAddict(ply, ply:GetAddiction() * cfg.AddictDeath)
	end

	-- шаг 38: респавн тоже снимает зависимость (вход за персонажа не трогает: DarkRP.CharacterSelected ставит её после Spawn)
	if (cfg.AddictDeath or 0) <= 0 and ply:GetAddiction() > 0 then
		setAddict(ply, 0)
		ply.MES_WithdrawMsg = nil
	end
end)

hook.Add("DarkRP.CharacterSelected", "MES.Drugs", function(ply, slot, ch)
	local vars = ch and ch.vars or {}

	ply.MES_WithdrawMsg = nil
	setAddict(ply, tonumber(vars.addict) or 0)
end)

hook.Add("DarkRP.DB.SaveCharVars", "MES.Drugs", function(ply, vars)
	local a = ply:GetAddiction()
	vars.addict = a > 0 and a or nil
end)

hook.Add("MCR.CharacterUnloaded", "MES.Drugs", function(ply)
	clearDrugs(ply)
	setAddict(ply, 0)

	ply.MES_DrugDied = nil
	ply.MES_WithdrawMsg = nil
end)

hook.Add("PlayerDisconnected", "MES.Drugs", function(ply)
	timer.Remove("MES.Sleep" .. ply:UserID())
	timer.Remove("MES.ODUncon" .. ply:UserID())
	timer.Remove(ply:UserID() .. "overdose")
end)
