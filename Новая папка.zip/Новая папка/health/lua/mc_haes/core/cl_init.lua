-- "addons\\health\\lua\\mc_haes\\core\\cl_init.lua"
-- Retrieved by Urbanichka
function MES.OpenMenuCheck()
	if IsValid(MMD.RadialMenu) then return end
	MMD.RadialMenu = vgui.Create("MMD.RadialMenu")

	local panel = MMD.RadialMenu
	panel:SetSize(700, 700)
	panel:MakePopup()
	panel:Center()

	panel.KeyThink = function()
		if input.IsMouseDown(MOUSE_RIGHT) then
			panel.Close()
		end
	end

	panel.Close = function()
		MMD.RadialMenu:Remove()
		MMD.RadialMenu = nil
		MSD.PlaySnd("msd/ui/click.wav")
	end

	panel.Page = {}

	panel.OpenPage = function(id)
		page = panel.Page[id]
		if not page then return end
		MSD.PlaySnd("msd/ui/toggle.wav")
		panel.actions = page
		panel:Build()
	end

	panel.Page["main"] = {}

	for k, v in pairs(MES.List) do
		table.insert(panel.Page["main"], {
			v[2], function()
				RunConsoleCommand("mes.check", k)
				panel.Close()
			end
		})
	end

	panel.OpenPage("main")
end

function MES.OpenMenuApply()
	if IsValid(MMD.RadialMenu) then return end
	MMD.RadialMenu = vgui.Create("MMD.RadialMenu")

	local panel = MMD.RadialMenu
	panel:SetSize(700, 700)
	panel:MakePopup()
	panel:Center()
	panel.inittime = CurTime() + 1

	panel.KeyThink = function()
		if panel.inittime < CurTime() and input.IsMouseDown(MOUSE_RIGHT) then
			panel.Close()
		end
	end

	panel.Close = function()
		MMD.RadialMenu:Remove()
		MMD.RadialMenu = nil
		surface.PlaySound("piemenu_select.wav")
	end

	panel.Page = {}

	panel.OpenPage = function(id)
		page = panel.Page[id]
		if not page then return end
		surface.PlaySound("piemenu_open.wav")
		panel.actions = page
		panel:Build()
	end

	panel.Page["main"] = {}

	for k, v in pairs(MES.ListHeal) do
		-- шаг 39: MRS.GetPlyRank без ранга возвращает false -> ошибка сравнения
		if MES.ListHealRest[k] and (LocalPlayer():Team() ~= 13 or (tonumber((MRS.GetPlyRank(LocalPlayer(), "FDNY"))) or 0) < 3) then continue end
		table.insert(panel.Page["main"], {
			v[1], function()
				RunConsoleCommand("mes.apply", k)
				panel.Close()
			end
		})
	end

	panel.OpenPage("main")
end
