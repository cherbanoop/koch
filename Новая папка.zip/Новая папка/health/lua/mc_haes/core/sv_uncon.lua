-- "addons\\health\\lua\\mc_haes\\core\\sv_uncon.lua"
-- Шаг 25. Порт присланного uncon.lua (+ pain.lua) в систему здоровья.
--   Сам рэгдолл, без сознания в машине (клаксон), урон по телу, камера, блок управления/чата/голоса -
--   уже в гейммоде (modules/base/sv_ragdoll.lua, ply:Ragdollize) и в sv_damage.lua (пули по машине,
--   авария, взрыв головы - sv_headexplode.lua). Здесь - правила из uncon.lua, которых не было:
--     * вырубает от урона: после удара HP <= HPLimit или за 10 сек набрано >= RecentLimit урона
--       (если нет брони; падение - всегда). Водитель: удар >= 20 (пули/дробь >= 40) или HP <= 30.
--       Время: урон * 0.8 + 10, от 20 до 80 сек.
--     * болевой шок (pain.lua, NW "Shock") > ShockKO - отключается на 15-25 сек, шок сбрасывается.
--     * при потере сознания выпадает оружие из рук (кроме полиции/детектива и командного оружия).
--     * встаёт анимацией "zombie_slump_rise_01" (noireanims/sv_anims.lua DarkRP.PlayGetUp),
--       пока встаёт - без оружия/атаки.
--     * тело стало тяжелее и не улетает (server/sv_gamemode.lua DarkRP.RagdollPhys).
--   Отключено из uncon.lua: свой отдельный рэгдолл/спектатор, PlayerDeathThink 120 сек (у нас своя смерть/СЛР),
--   testuncon -> noire_testuncon (только суперадмин).
-- Настройки: MES.UnconConfig.
MES.UnconConfig = MES.UnconConfig or {}

local cfg = MES.UnconConfig
if cfg.Enabled == nil then cfg.Enabled = true end
cfg.HPLimit = cfg.HPLimit or 30
cfg.RecentWindow = cfg.RecentWindow or 10
cfg.RecentLimit = cfg.RecentLimit or 40
cfg.DriverHit = cfg.DriverHit or 20
cfg.DriverBulletHit = cfg.DriverBulletHit or 40
cfg.PassengerHit = cfg.PassengerHit or cfg.DriverHit
cfg.PassengerBulletHit = cfg.PassengerBulletHit or cfg.DriverBulletHit
cfg.TimeMul = cfg.TimeMul or 0.8
cfg.TimeAdd = cfg.TimeAdd or 10
cfg.TimeMin = cfg.TimeMin or 20
cfg.TimeMax = cfg.TimeMax or 80
cfg.WakeProtect = cfg.WakeProtect or 4 -- сек после подъёма, когда урон снова не вырубает
cfg.ShockKO = cfg.ShockKO or 150
cfg.ShockKOTime = cfg.ShockKOTime or {15, 25}
cfg.ShockKOCooldown = cfg.ShockKOCooldown or 5
if cfg.DropWeapon == nil then cfg.DropWeapon = true end

local policeModels = {}
for i = 1, 9 do policeModels["models/cityrp/pm/nypd/male_0" .. i .. ".mdl"] = true end

local function isPolice(ply)
	if ply:GetNWBool("detective", false) then return true end
	if ply.isCP and ply:isCP() then return true end
	return policeModels[string.lower(ply:GetModel() or "")] == true
end

local function uncon(ply)
	return ply.IsUncon and ply:IsUncon() or false
end

local function tatoo(ply, id)
	return MCR and MCR.HasTatoo and MCR.HasTatoo(ply, id) or false
end

-- урон, который "вырубает" (не голод, не яд, не кровотечение)
local koTypes = bit.bor(DMG_BULLET, DMG_BUCKSHOT, DMG_CLUB, DMG_SLASH, DMG_BLAST, DMG_FALL, DMG_CRUSH, DMG_VEHICLE, DMG_SONIC, DMG_SHOCK)

local function carOfEnt(ent)
	if not IsValid(ent) then return end
	if ent.PressedKeys or ent.GetSeats then return ent end
	local p = ent.base or ent:GetParent()
	if IsValid(p) and (p.PressedKeys or p.GetSeats) then return p end
end

local function countsForKO(ply, dmg)
	if bit.band(dmg:GetDamageType(), koTypes) ~= 0 then return true end
	local atk = dmg:GetAttacker()
	if IsValid(atk) and (atk:IsPlayer() or atk:IsNPC()) then return true end

	-- шаг 29: в машине урон приходит от самой машины с типом DMG_DIRECT (авария, взрыв, пули по кузову) -
	-- раньше такой урон не считался "вырубающим", и в салоне никто не терял сознание
	if ply:InVehicle() then
		if dmg:IsDamageType(DMG_DIRECT) then return true end
		if carOfEnt(dmg:GetInflictor()) or carOfEnt(atk) then return true end
	end

	return false
end

local function isDriver(ply)
	if not ply:InVehicle() then return false end
	local seat = ply:GetVehicle()
	if not IsValid(seat) then return false end
	local car = seat.base or seat:GetParent()
	if IsValid(car) and car.GetDriver then return car:GetDriver() == ply end
	return seat.GetDriver and seat:GetDriver() == ply or false
end

local function koTime(a)
	return math.Clamp(a * cfg.TimeMul + cfg.TimeAdd, cfg.TimeMin, cfg.TimeMax)
end

hook.Add("PostEntityTakeDamage", "MES.Uncon", function(ply, dmg, took)
	if not cfg.Enabled or not took or not IsValid(ply) or not ply:IsPlayer() then return end
	if not ply:Alive() or uncon(ply) or ply.MES_Skip then return end
	if (ply.MES_WokeUp or 0) > CurTime() then return end
	if not countsForKO(ply, dmg) then return end

	local a = dmg:GetDamage()
	if a <= 0 then return end

	local CT = CurTime()
	local hits = ply.MES_UnconHits or {}
	ply.MES_UnconHits = hits
	table.insert(hits, {CT, a})

	local tot = 0
	for i = #hits, 1, -1 do
		if hits[i][1] < CT - cfg.RecentWindow then table.remove(hits, i) else tot = tot + hits[i][2] end
	end

	local bullet = dmg:IsBulletDamage() or dmg:IsDamageType(DMG_BUCKSHOT)

	-- "Непреодолимая сила": пули не вырубают
	if bullet and tatoo(ply, "g6") then return end

	local hp = ply:Health()
	local ko = false

	if ply:InVehicle() then
		-- шаг 29: и водитель, и пассажиры (раньше пассажиров не вырубало вообще)
		local thr
		if isDriver(ply) then
			thr = bullet and cfg.DriverBulletHit or cfg.DriverHit
		else
			thr = bullet and cfg.PassengerBulletHit or cfg.PassengerHit
		end
		ko = a >= thr or tot >= thr or hp <= cfg.HPLimit
	else
		local fall = dmg:IsDamageType(DMG_FALL)
		ko = (fall or ply:Armor() <= 0) and (hp <= cfg.HPLimit or tot >= cfg.RecentLimit)
	end

	if not ko then return end

	ply.MES_UnconHits = nil
	MES.Knockout(ply, koTime(a), true)
end)

-- болевой шок (pain.lua): слишком больно - отключается
local lastSKO = {}
util.AddNetworkString("SKO")

timer.Create("MES.UnconShock", 0.5, 0, function()
	if not cfg.Enabled or not MES.GetPainShock then return end

	local CT = CurTime()

	for _, ply in ipairs(player.GetAll()) do
		if not ply:Alive() or uncon(ply) or ply:getDarkRPVar("unconscious") then continue end
		if MES.GetPainShock(ply) <= cfg.ShockKO then continue end
		if (lastSKO[ply] or 0) > CT then continue end

		lastSKO[ply] = CT + cfg.ShockKOCooldown
		ply:SetNWFloat("Shock", 0)
		MES.Knockout(ply, math.random(cfg.ShockKOTime[1], cfg.ShockKOTime[2]), true)

		net.Start("SKO")
		net.Send(ply)
	end
end)

-- потерял сознание - оружие из рук падает рядом с телом (uncon.lua: не у полиции)
hook.Add("DarkRP.Ragdollized", "MES.UnconDrop", function(ply, rag, time, heavy)
	if not cfg.DropWeapon or not heavy or not IsValid(rag) then return end
	if isPolice(ply) then return end

	local class = ply.UnconWeapon
	if not class or class == "keys" then return end

	local wep = ply:GetWeapon(class)
	if not IsValid(wep) or wep:GetModel() == "" or not DarkRP.CanDropWeapon(ply, wep) then return end

	local phys = rag:GetPhysicsObjectNum(0)
	local pos = (IsValid(phys) and phys:GetPos() or rag:GetPos()) + Vector(math.random(-12, 12), math.random(-12, 12), 14)

	ply.UnconWeapon = nil
	ply:DropDRPWeapon(wep, pos, Angle(0, math.random(0, 359), 0))
end)

-- пришёл в себя - пара секунд без повторного нокаута (пока встаёт)
hook.Add("DarkRP.UnRagdollized", "MES.Uncon", function(ply)
	if not IsValid(ply) then return end
	ply.MES_WokeUp = CurTime() + cfg.WakeProtect
	ply.MES_UnconHits = nil
end)

hook.Add("PlayerSpawn", "MES.Uncon", function(ply)
	ply.MES_UnconHits = nil
	ply.MES_WokeUp = nil
end)

hook.Add("PlayerDisconnected", "MES.Uncon", function(ply)
	lastSKO[ply] = nil
end)

concommand.Add("noire_testuncon", function(ply, cmd, args)
	if not IsValid(ply) or not ply:IsSuperAdmin() or not ply:Alive() then return end
	ply:Ragdollize(tonumber(args[1]) or 10, true)
end)
