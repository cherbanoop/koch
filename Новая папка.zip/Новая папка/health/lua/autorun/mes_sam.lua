-- "addons\\health\\lua\\autorun\\mes_sam.lua"
-- Команды SAM, категория "Health" (общий файл - чтобы команды были видны в меню SAM и TAB):
--   revive <игроки> - мёртвого поднять у тела, живого привести в сознание и вылечить (MES.AdminRevive)
--   ragdoll <игроки> [сек.] - сбить с ног (ply:Ragdollize, 2-180, по умолчанию 30)
--   unragdoll <игроки> - поднять на ноги (ply:UnRagdollize)
local function addCommands()
	if not sam or not sam.command or not sam.command.new then return end
	if sam.command.get_command and sam.command.get_command("revive") then return end

	sam.command.new("revive")
		:SetCategory("Health")
		:SetPermission("revive", "admin")
		:AddArg("player", {allow_higher_target = true})
		:Help("Реанимировать / привести в сознание и вылечить")
		:OnExecute(function(ply, targets)
			for i = 1, #targets do
				MES.AdminRevive(targets[i])
			end

			sam.player.send_message(nil, "{A} реанимировал {T}", {A = ply, T = targets})
		end)
	:End()

	sam.command.new("ragdoll")
		:SetCategory("Health")
		:SetPermission("ragdoll", "admin")
		:AddArg("player")
		:AddArg("number", {hint = "секунды", optional = true, default = 30, min = 2, max = 180, round = true})
		:Help("Сбить с ног")
		:OnExecute(function(ply, targets, time)
			for i = 1, #targets do
				local v = targets[i]
				if not v:Alive() then continue end

				if v:InVehicle() then v:ExitVehicle() end
				v:Ragdollize(time)
			end

			sam.player.send_message(nil, "{A} сбил с ног {T} на {V} сек.", {A = ply, T = targets, V = time})
		end)
	:End()

	sam.command.new("unragdoll")
		:SetCategory("Health")
		:SetPermission("unragdoll", "admin")
		:AddArg("player")
		:Help("Поднять на ноги")
		:OnExecute(function(ply, targets)
			for i = 1, #targets do
				local v = targets[i]
				if v.IsUncon and v:IsUncon() then v:UnRagdollize() end
			end

			sam.player.send_message(nil, "{A} поднял на ноги {T}", {A = ply, T = targets})
		end)
	:End()
end

hook.Add("PostGamemodeLoaded", "MES.SAM", addCommands)
