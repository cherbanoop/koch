-- "addons\\carradio\\lua\\wcarradio\\sv_carstereo.lua"
--[[---------------------------------------------------------------------------
Wyozi Car Radio - сервер под протокол HUD машины (simfphys/client/hud.lua) и cl_carstereo.lua
  net "wyozicr_cradio" (клиент -> сервер): [Entity - переносное радио] Int8 Bool
    Bool = false: Int8 1 / -1 - следующая / предыдущая станция, 0 - вкл/выкл
    Bool = true:  Int8 громкость 0..100
  Состояние на сущности: NW2Int "wcr_chan" (0 - выкл, индекс wyozicr.AllStations), NW2Float "radio_vol",
  NWBool "MccD.Radio" - есть магнитола (машины - автосалон McCD, переносное радио - при использовании).
  Переносное радио: предмет DarkRP.Junk "radio" (spawned_junk), E - панель управления (UIEffect radio_open).
---------------------------------------------------------------------------]]
-- шаг 26: переносная магнитола - "radio" и "boombox" (бумбокс работает так же: E - панель радио)
local PORTABLE_RADIO = {["radio"] = true, ["boombox"] = true}
if wyozicr then wyozicr.PortableRadio = PORTABLE_RADIO end

util.AddNetworkString("wyozicr_cradio")

wyozicr.UseDist = wyozicr.UseDist or 200

local function isRadioItem(ent)
	return IsValid(ent) and ent:GetClass() == "spawned_junk" and ent.Geteclass and PORTABLE_RADIO[ent:Geteclass()]
end

function wyozicr.ChangeStation(ent, dir)
	local count = #(wyozicr.AllStations or {})
	if count < 1 then return end

	local cur = ent:WCR_GetChannel()

	if dir == 0 then
		if cur > 0 then
			ent.WCR_LastChannel = cur
			ent:WCR_SetChannel(0)
		else
			ent:WCR_SetChannel(math.Clamp(ent.WCR_LastChannel or 1, 1, count))
		end

		return
	end

	local new = cur + dir
	if new < 1 then new = count elseif new > count then new = 1 end

	ent:WCR_SetChannel(new)
end

-- без сущности в сообщении 9 бит (Int8 + Bool), с сущностью - больше
net.Receive("wyozicr_cradio", function(len, ply)
	local ent

	if len > 20 then
		ent = net.ReadEntity()
		if not isRadioItem(ent) or ent:GetPos():DistToSqr(ply:GetPos()) > wyozicr.UseDist ^ 2 then return end
	else
		ent = ply.GetSimfphys and ply:GetSimfphys()

		if not IsValid(ent) then
			local veh = ply:GetVehicle()
			ent = IsValid(veh) and veh:WCR_GetCarEntity()
		end
	end

	if not IsValid(ent) or not ent:WCR_HasRadioCapability() then return end

	local val = net.ReadInt(8)

	if net.ReadBool() then
		ent:SetNW2Float("radio_vol", math.Clamp(val / 100, 0, 1))
		return
	end

	if DarkRP and DarkRP.NetDelay and DarkRP.NetDelay(ply, "wyozicr_cradio", 0.3) then return end

	wyozicr.ChangeStation(ent, math.Clamp(val, -1, 1))
end)

hook.Add("PlayerUse", "WCR.RadioItem", function(ply, ent)
	if not isRadioItem(ent) then return end
	if DarkRP.NetDelay(ply, "WCR.RadioItem", 1) then return end

	ent:SetNWBool("MccD.Radio", true)
	DarkRP.UIEffect(ply, "radio_open", {idx = ent:EntIndex()})
end)
