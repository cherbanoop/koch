-- "addons\\carradio\\lua\\wcarradio\\sh_wcr_util.lua"
-- Retrieved by Urbanichka
-- шаг 26: переносная магнитола - "radio" и "boombox" (бумбокс работает так же: E - панель радио)
local PORTABLE_RADIO = {["radio"] = true, ["boombox"] = true}
if wyozicr then wyozicr.PortableRadio = PORTABLE_RADIO end

local function isTracked(cls, ent)
	return cls == "prop_vehicle_jeep" or cls == "prop_vehicle_jeep_old" or (cls == "spawned_junk" and ent.Geteclass and PORTABLE_RADIO[ent:Geteclass()])
end

local carents = setmetatable({}, {
	__mode = "v"
})

for _, e in pairs(ents.GetAll()) do
	if isTracked(e:GetClass(), e) then
		table.insert(carents, e)
	end
end

hook.Add(SERVER and "OnEntityCreated" or "NetworkEntityCreated", "CarRadio_CarTracker", function(e)
	if isTracked(e:GetClass(), e) then
		table.insert(carents, e)
	end
end)

hook.Add("EntityRemoved", "CarRadio_CarTracker", function(e)
	if isTracked(e:GetClass(), e) then
		table.RemoveByValue(carents, e)
	end
end)

function wyozicr.GetCarEnts()
	return carents
end