-- "addons\\simp_phys_lmao\\lua\\entities\\fire_ladder.lua"
-- Retrieved by Urbanichka
--[[---------------------------------------------------------------------------
Пожарная лестница (autorun/spawnlist_fire_truck.lua - "Пожарная машина (Ladder)")
  Шаг 53 - доделано:
    * водитель на стоянке [T] - опоры (машина встаёт, лестница отцепляется, сзади лесенка на платформу);
      подсказки водителю, нельзя убрать опоры с разложенной лестницей / на ходу
    * управлять лестницей - [E] по лестнице (только пожарные, двигатель заведён), подсказка управления на экране:
      ЛКМ / ПКМ - выдвинуть / сложить, W / S - поднять / опустить, A / D - поворот, R - повернуть прямо
    * встал с пульта - по лестнице можно лезть (func_useableladder), вверху и внизу точки схода
      (info_ladder_dismount), если там есть куда встать
    * упёрлась в стену - движение просто стоит (раньше Think возвращал nil)
  NoireLadder.Teams - кто может управлять (nil - все)
---------------------------------------------------------------------------]]
AddCSLuaFile()
ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = "Engine Ladder"
ENT.Spawnable = false
ENT.AutomaticFrameAdvance = true
ENT.AdminSpawnable = false
ENT.DoNotDuplicate = true

function ENT:SetupDataTables()
	self:NetworkVar("Float", 0, "Open")
	self:NetworkVar("Float", 1, "Climb")
	self:NetworkVar("Float", 2, "Rotate")
end

NoireLadder = NoireLadder or {}

if SERVER then
	-- кто может управлять лестницей: команды (TEAM_*). Таблица заполняется после загрузки работ
	hook.Add("InitPostEntity", "NoireLadder.Teams", function()
		if NoireLadder.Teams == nil and TEAM_FIREFIGHTER then
			NoireLadder.Teams = {[TEAM_FIREFIGHTER] = true}
		end
	end)

	function NoireLadder.CanOperate(ply)
		if not IsValid(ply) then return false end
		if ply:IsAdmin() then return true end

		local teams = NoireLadder.Teams
		return not teams or teams[ply:Team()] == true
	end

	local hullMins, hullMaxs = Vector(-16, -16, 0), Vector(16, 16, 72)

	-- точка, где игрок может стоять: пол под ногами и место под рост
	local function standSpot(pos, filter, depth)
		local tr = util.TraceLine({start = pos, endpos = pos - Vector(0, 0, depth or 64), filter = filter})
		if not tr.Hit or tr.HitNormal.z < 0.7 then return end

		local ground = tr.HitPos + Vector(0, 0, 2)
		local hull = util.TraceHull({start = ground, endpos = ground, mins = hullMins, maxs = hullMaxs, filter = filter})
		if hull.StartSolid or hull.Hit then return end

		return ground
	end

	-- точки схода с лестницы (info_ladder_dismount) - создаются ДО Spawn/Activate func_useableladder,
	-- лестница ищет их в радиусе ~100 от концов. outDir - куда сходить (горизонтально)
	function NoireLadder.Dismounts(list, pos, outDir, filter, max)
		if not outDir or outDir:IsZero() then return list end

		outDir = Vector(outDir.x, outDir.y, 0)
		outDir:Normalize()
		local right = outDir:Angle():Right()
		local made = 0

		for _, d in ipairs({20, 36, 52}) do
			for _, side in ipairs({0, 22, -22}) do
				local spot = standSpot(pos + outDir * d + right * side + Vector(0, 0, 24), filter, 72)

				if spot then
					local dm = ents.Create("info_ladder_dismount")
					if not IsValid(dm) then return list end

					dm:SetPos(spot)
					dm:Spawn()
					list[#list + 1] = dm
					made = made + 1

					if made >= (max or 2) then return list end
					break
				end
			end
		end

		return list
	end

	function NoireLadder.RemoveDismounts(list)
		if not list then return end

		for _, dm in ipairs(list) do
			if IsValid(dm) then dm:Remove() end
		end
	end

	-- func_useableladder между двумя точками + точки схода
	function NoireLadder.Create(bottom, top, ang, topOut, bottomOut, filter)
		local dismounts = {}
		NoireLadder.Dismounts(dismounts, top, topOut, filter)
		NoireLadder.Dismounts(dismounts, bottom, bottomOut, filter)

		local lad = ents.Create("func_useableladder")
		if not IsValid(lad) then
			NoireLadder.RemoveDismounts(dismounts)
			return
		end

		lad:SetPos(bottom)
		lad:SetAngles(ang or Angle(0, 0, 0))
		lad:SetKeyValue("point0", tostring(bottom))
		lad:SetKeyValue("point1", tostring(top))
		lad:Spawn()
		lad:Activate()

		lad.NoireDismounts = dismounts
		lad:CallOnRemove("NoireLadder.Dismounts", function(ent)
			NoireLadder.RemoveDismounts(ent.NoireDismounts)
		end)

		return lad
	end

	-- typ: 0 - подсказка, 1 - ошибка (DarkRP.notify)
	local function hint(ply, key, time, msg, typ)
		if not IsValid(ply) or not (DarkRP and DarkRP.notify) then return end
		ply.NoireLadderHints = ply.NoireLadderHints or {}
		if (ply.NoireLadderHints[key] or 0) > CurTime() then return end
		ply.NoireLadderHints[key] = CurTime() + time

		DarkRP.notify(ply, typ or 0, 5, msg)
	end
	NoireLadder.Hint = hint

	function ENT:Initialize()
		self:SetModel("models/left4dead/vehicles/ladder01a.mdl")
		self:PhysicsInit(SOLID_VPHYSICS)
		self:SetMoveType(MOVETYPE_NONE)
		self:SetSolid(SOLID_VPHYSICS)
		self:SetUseType(SIMPLE_USE)
		self:DrawShadow(false)
		self:SetOpen(0)
		self:SetClimb(0)
		self:SetRotate(0)

		self.DriverSeat = ents.Create("prop_vehicle_prisoner_pod")
		self.DriverSeat:SetMoveType(MOVETYPE_NONE)
		self.DriverSeat:SetModel("models/nova/airboat_seat.mdl")
		self.DriverSeat:SetKeyValue("vehiclescript", "scripts/vehicles/prisoner_pod.txt")
		self.DriverSeat:SetKeyValue("limitview", 0)
		self.DriverSeat:SetPos(self:LocalToWorld(Vector(-59.04,-18.85,-33.5)))
		self.DriverSeat:SetAngles(self:GetAngles() + Angle(0,-90,0))
		self.DriverSeat:SetOwner(self)
		self.DriverSeat:Spawn()
		self.DriverSeat:Activate()
		self.DriverSeat:SetParent(self, 0)

		self.DriverSeat:GetPhysicsObject():EnableDrag(false)
		self.DriverSeat:GetPhysicsObject():EnableMotion(false)
		self.DriverSeat:GetPhysicsObject():SetMass(1)
		self.DriverSeat:SetNW2String("sit_anim", "d3_c17_03_tower_idle")
		self.DriverSeat:SetNW2Entity("NoireLadder", self) -- шаг 53: клиент рисует подсказку управления
		self.DriverSeat.base = self
		self.DriverSeat.DoNotDuplicate = true

		self:DeleteOnRemove(self.DriverSeat)
		self.DriverSeat:SetNotSolid(true)
		self.DriverSeat:SetColor(Color(255, 255, 255, 0))
		self.DriverSeat:SetRenderMode(RENDERMODE_TRANSALPHA)
		self.DriverSeat:DrawShadow(false)
	end

	function ENT:Use(ply)
		if not IsValid(ply) or not ply:IsPlayer() then return end
		if not IsValid(self.engine) then return true end

		-- шаг 53: подсказки вместо молчания
		if not self.engine.fixed_pos then
			hint(ply, "fix", 3, "Сначала выставите опоры: водитель на стоянке нажимает [T]")
			return true
		end

		if not NoireLadder.CanOperate(ply) then
			hint(ply, "team", 3, "Лестницей управляют только пожарные", 1)
			return true
		end

		if not IsValid(self.DriverSeat) or IsValid(self.DriverSeat:GetDriver()) then
			hint(ply, "busy", 3, "Пульт лестницы занят", 1)
			return true
		end

		if self.lastDT and self.lastDT > CurTime() then return end
		ply:EnterVehicle(self.DriverSeat)

		if (self.engine.EngineRPM or 0) <= 0 then
			hint(ply, "engine", 5, "Заведите двигатель пожарной машины - без него лестница не двигается")
		end
	end

	function ENT:OnRemove()
		if IsValid(self.ladderEnt) then
			self.ladderEnt:Remove()
		end
	end

	function ENT:UpdateSit()
		local att = self:GetBoneMatrix(0)
		local pos = self:WorldToLocal(att:GetTranslation())
		local ang = self:WorldToLocalAngles(att:GetAngles())

		self.DriverSeat:SetPos(pos + ang:Up() * 40 + ang:Forward() * 20 )
		self.DriverSeat:SetAngles(ang + self:LocalToWorldAngles(Angle(0,0,-90)))
		self.engine.usedladder = CurTime() + 1
	end

	function ENT:CollisionForward()
		local ladsp = self:GetAttachment(self:LookupAttachment("start"))
		local ladep = self:GetAttachment(self:LookupAttachment("end"))
		local dir = ladep.Pos - ladsp.Pos
		local cor = dir:Angle():Up() * -20 + dir:Angle():Right() * -2
		local tr = util.TraceLine( {
			start = ladsp.Pos + cor,
			endpos = ladep.Pos + dir:Angle():Forward() * 15 + cor,
			filter = {self, self.engine}
		})
		--DarkRP.UIEffect(nil, "debug", {tr.StartPos, tr.HitPos})
		return tr.Hit
	end

	function ENT:CollisionUp()
		local ladsp = self:GetAttachment(self:LookupAttachment("start"))
		local ladep = self:GetAttachment(self:LookupAttachment("end"))
		local dir = ladep.Pos - ladsp.Pos
		local cor = dir:Angle():Up() * 25
		local tr = util.TraceLine( {
			start = ladsp.Pos + cor,
			endpos = ladep.Pos + dir:Angle():Forward() * 30 + cor,
			filter = {self, self.engine}
		})
		return tr.Hit
	end

	function ENT:CollisionDown()
		local ladsp = self:GetAttachment(self:LookupAttachment("start"))
		local ladep = self:GetAttachment(self:LookupAttachment("end"))
		local dir = ladep.Pos - ladsp.Pos
		local cor = dir:Angle():Up() * -25
		local tr = util.TraceLine( {
			start = ladsp.Pos + cor,
			endpos = ladep.Pos + dir:Angle():Forward() * 30 + cor,
			filter = {self, self.engine}
		})
		return tr.Hit
	end

	function ENT:CollisionRight()
		local ladsp = self:GetAttachment(self:LookupAttachment("start"))
		local ladep = self:GetAttachment(self:LookupAttachment("end"))
		local dir = ladep.Pos - ladsp.Pos
		local cor = dir:Angle():Up() * 15 +  dir:Angle():Right() * 25
		local tr = util.TraceLine( {
			start = ladsp.Pos + cor,
			endpos = ladep.Pos + dir:Angle():Forward() * 15 + cor,
			filter = {self, self.engine}
		})
		return tr.Hit
	end

	function ENT:CollisionLeft()
		local ladsp = self:GetAttachment(self:LookupAttachment("start"))
		local ladep = self:GetAttachment(self:LookupAttachment("end"))
		local dir = ladep.Pos - ladsp.Pos
		local cor = dir:Angle():Up() * 15 +  dir:Angle():Right() * -25
		local tr = util.TraceLine( {
			start = ladsp.Pos + cor,
			endpos = ladep.Pos + dir:Angle():Forward() * 15 + cor,
			filter = {self, self.engine}
		})
		return tr.Hit
	end

	function ENT:Think()
		self:SetPoseParameter("open", self:GetOpen())
		self:SetPoseParameter("climb", self:GetClimb())
		self:SetPoseParameter("rotate", self:GetRotate())
		self:NextThink(CurTime())

		if not IsValid(self.engine) then return true end

		if (not self.lastDT or self.lastDT < CurTime()) and IsValid(self.DriverSeat) and IsValid(self.DriverSeat:GetDriver()) then

			local ply = self.DriverSeat:GetDriver()
			self.od = ply
			if self.engine.EngineRPM <= 0 then
				if ply:KeyDown(IN_ATTACK) or ply:KeyDown(IN_ATTACK2) or ply:KeyDown(IN_FORWARD) or ply:KeyDown(IN_BACK) or ply:KeyDown(IN_MOVELEFT) or ply:KeyDown(IN_MOVERIGHT) then
					hint(ply, "engine", 5, "Двигатель пожарной машины заглушен - лестница не двигается", 1)
				end

				return true
			end

			if IsValid(self.ladderEnt) then
				self.ladderEnt:Remove()
			end

			self.lastDT = CurTime() + 0.1

			if ply:KeyDown(IN_ATTACK) then
				if self:CollisionForward() then return true end
				self:SetOpen(math.Clamp(self:GetOpen() + 0.01, 0, 1))
				self.engine.usedladder = CurTime() + 1
			elseif ply:KeyDown(IN_ATTACK2) then
				self:SetOpen(math.Clamp(self:GetOpen() - 0.01, 0, 1))
				self.engine.usedladder = CurTime() + 1
			end

			if ply:KeyDown(IN_FORWARD) then
				if self:CollisionUp() then return true end
				self:SetClimb(math.Clamp(self:GetClimb() + 0.01, 0, 1))
				self.engine.usedladder = CurTime() + 1
			elseif ply:KeyDown(IN_BACK) then
				if self:CollisionDown() then return true end
				self:SetClimb(math.Clamp(self:GetClimb() - 0.01, 0, 1))
				self.engine.usedladder = CurTime() + 1
			end

			if ply:KeyDown(IN_MOVERIGHT) then
				if self:CollisionRight() then return true end
				self:SetRotate(math.Clamp(self:GetRotate() + 0.003, -1, 1))
				self:UpdateSit()
			elseif ply:KeyDown(IN_MOVELEFT) then
				if self:CollisionLeft() then return true end
				self:SetRotate(math.Clamp(self:GetRotate() - 0.003, -1, 1))
				self:UpdateSit()
			end

			if ply:KeyDown(IN_RELOAD) then
				if self:GetRotate() > 0 then
					if self:CollisionRight() then return true end
					self:SetRotate(math.max(self:GetRotate() - 0.003, 0))
					self:UpdateSit()
				else
					if self:CollisionLeft() then return true end
					self:SetRotate(math.min(self:GetRotate() + 0.003, 0))
					self:UpdateSit()
				end
			end
		end

		if not IsValid(self.DriverSeat:GetDriver()) and self.od then
			self.od = nil
			if IsValid(self.ladderEnt) then
				self.ladderEnt:Remove()
			end

			if self:GetOpen() == 0 and self:GetRotate() == 0 and self:GetClimb() == 0 then return true end
			self:EmitSound("vehicles/crane/crane_magnet_release.wav")
			local ladsp = self:GetAttachment(self:LookupAttachment("start"))
			local ladep = self:GetAttachment(self:LookupAttachment("end"))
			if not ladsp or not ladep then return true end

			local ladderStartPos = ladsp.Pos
			local ladderEndPos = ladep.Pos

			-- шаг 53: + точки схода: вверху - дальше по направлению лестницы, внизу - обратно на платформу
			local dir = ladderEndPos - ladderStartPos
			self.ladderEnt = NoireLadder.Create(ladderStartPos, ladderEndPos, self:GetAngles(), dir, -dir, {self})
		end

		return true
	end
end



if CLIENT then
	-- шаг 53: подсказка управления на пульте лестницы
	local bg = Color(0, 0, 0, 170)
	local hl = Color(255, 200, 90)
	local lines = {
		{"ЛКМ / ПКМ", "выдвинуть / сложить"},
		{"W / S", "поднять / опустить"},
		{"A / D", "повернуть"},
		{"R", "повернуть прямо"},
		{"E", "встать с пульта (по лестнице можно лезть)"},
	}

	hook.Add("HUDPaint", "NoireLadder.Controls", function()
		local ply = LocalPlayer()
		local veh = IsValid(ply) and ply:GetVehicle()
		if not IsValid(veh) then return end

		local lad = veh:GetNW2Entity("NoireLadder")
		if not IsValid(lad) then return end

		local w, h = 330, 30 + #lines * 20 + 22
		local x, y = ScrW() - w - 30, ScrH() * 0.5 - h * 0.5

		draw.RoundedBox(6, x, y, w, h, bg)
		draw.SimpleText("Пожарная лестница", "DermaDefaultBold", x + 12, y + 8, hl)

		for i, l in ipairs(lines) do
			local ly = y + 10 + i * 20
			draw.SimpleText(l[1], "DermaDefaultBold", x + 12, ly, color_white)
			draw.SimpleText(l[2], "DermaDefault", x + 100, ly, color_white)
		end

		local info = string.format("Выдвинута %d%%   Подъём %d%%   Поворот %+d%%", math.Round(lad:GetOpen() * 100), math.Round(lad:GetClimb() * 100), math.Round(lad:GetRotate() * 100))
		draw.SimpleText(info, "DermaDefault", x + 12, y + h - 20, hl)
	end)

	function ENT:OnActiveMove(play)
		if self.lastsound and self.lastsound > CurTime() then return end

		if not play then
			if self.sound then
				self.sound:ChangeVolume(0, 0.1)
			end
			return
		end

		if play then self.lastsound = CurTime() + 0.1 end

		if not self.sound then
			self.sound = CreateSound(self, "vehicles/crane/crane_magnet_grab.wav")
			self.sound:PlayEx(0, 100)
			self.sound:ChangeVolume(0.3, 0.1)
		else
			self.sound:ChangeVolume(0.3, 0.1)
		end
	end

	function ENT:Think()
		if not self.open then self.open = self:GetOpen() end
		if not self.climb then self.climb = self:GetClimb() end
		if not self.rotate then self.rotate = self:GetRotate() end

		if self.open ~= self:GetOpen() then
			self.open = math.Approach(self.open, self:GetOpen(), FrameTime() * 0.1)
			self:OnActiveMove(true)
		end
		if self.climb ~= self:GetClimb() then
			self.climb = math.Approach(self.climb, self:GetClimb(), FrameTime() * 0.1)
			self:OnActiveMove(true)
		end
		if self.rotate ~= self:GetRotate() then
			self.rotate = math.Approach(self.rotate, self:GetRotate(), FrameTime() * 0.03)
			self:OnActiveMove(true)
		end

		self:OnActiveMove(false)

		self:SetPoseParameter("open", self.open)
		self:SetPoseParameter("climb", self.climb)
		self:SetPoseParameter("rotate", self.rotate)
	end

	function ENT:OnRemove()
		if self.sound then
			self.sound:Stop()
		end
	end
end