-- "addons\\simp_phys_lmao\\lua\\autorun\\simfphys_init.lua"
-- Retrieved by Urbanichka
hook.Add("PostGamemodeLoaded", "SimfPhys.Loading", function()
	AddCSLuaFile("simfphys/init.lua")
	include("simfphys/init.lua")
end)