-- "addons\\cardealer\\lua\\entities\\mccd_terminal_garage\\shared.lua"
AddCSLuaFile()

ENT.Base = "mccd_terminal"
ENT.Type = "anim"
ENT.PrintName = "Гараж (шкаф)"
ENT.Category = "N.Y. Noire"
ENT.Spawnable = true
ENT.AdminOnly = true
ENT.TerminalType = "garage"
