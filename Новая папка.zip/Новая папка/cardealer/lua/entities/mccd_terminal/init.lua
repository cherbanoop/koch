-- "addons\\cardealer\\lua\\entities\\mccd_terminal\\init.lua"
-- Шкаф-терминал автосалона (вместо MCS NPC). Точки - McCD.Config.EntSpawns (sh_config) + data/mccd_terminals_<карта>.json
-- net "McCD.Terminal": сервер -> клиент (Entity, String заголовок, UInt4 n, n x {String ключ, String текст});
--                      клиент -> сервер (Entity, String ключ) - разборка / автомастерская
AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

util.AddNetworkString("McCD.Terminal")

local DEF_MODEL = "models/props_wasteland/controlroom_storagecloset001a.mdl"
local USE_DIST = 200 ^ 2

local function conf()
	return McCD.Config or {}
end

function ENT:Initialize()
	local tp = self:GetTermType()
	local c = conf()

	-- шаг 54: шкафы выключены (McCD.Config.Terminals = false) - любой шкаф (конфиг, PermaProps, Q-меню) убирается
	if c.Terminals == false then
		self:SetModel("models/props_junk/PopCan01a.mdl")
		SafeRemoveEntityDelayed(self, 0)
		return
	end

	self:SetModel(self.TermModel or (c.TerminalModels and c.TerminalModels[tp]) or c.TerminalModel or DEF_MODEL)
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_NONE)
	self:SetSolid(SOLID_VPHYSICS)
	self:SetUseType(SIMPLE_USE)

	local phys = self:GetPhysicsObject()
	if IsValid(phys) then phys:EnableMotion(false) end

	self.NonPickeble = true

	if self:GetType() == "" then self:SetType(tp) end

	if self:GetNameType() == "" then
		local t = McCD.Terminals[tp]
		self:SetNameType(t and t.name or "Автосалон")
	end
end

function ENT:Use(ply)
	if not IsValid(ply) or not ply:IsPlayer() then return end
	if DarkRP.UseDelay(ply, 1) then return end
	if not ply:Alive() or not ply:IsUnrestrained() or ply:InVehicle() then return end

	McCD.TerminalUse(ply, self)
end

--[[---------------------------------------------------------------------------
Действия
---------------------------------------------------------------------------]]
local up_order = {"radio", "bpw", "turbo", "super"}

local function sendOptions(ply, ent, title, opts)
	net.Start("McCD.Terminal")
		net.WriteEntity(ent)
		net.WriteString(title)
		net.WriteUInt(#opts, 4)

		for _, v in ipairs(opts) do
			net.WriteString(v[1])
			net.WriteString(v[2])
		end
	net.Send(ply)
end

local types = {
	["dealer"] = function(ply, ent)
		McCD.OpenDealer(ply, ent)
	end,

	["garage"] = function(ply, ent)
		McCD.OpenGarageMenu(ply, ent)
	end,

	["chopshop"] = function(ply, ent)
		sendOptions(ply, ent, ent.GetNameType and ent:GetNameType() or "Разборка", {
			{"check", "Оценить машину"},
			{"sell", "Сдать машину на разборку"},
		})
	end,

	["workshop"] = function(ply, ent)
		local opts = {}

		for _, key in ipairs(up_order) do
			local up = McCD.Upgrades and McCD.Upgrades[key]
			if not up then continue end

			local price = math.max(math.floor(tonumber(up.price()) or 0), 0)
			table.insert(opts, {key, up.name .. " - $" .. string.Comma(price)})
		end

		sendOptions(ply, ent, ent.GetNameType and ent:GetNameType() or "Автомастерская", opts)
	end,
}

-- шаг 54: те же меню у обычного NPC (MCS действие "DarkRP Автомастерская: меню", modules/base/sh_compat.lua;
-- разборка - McCD.NPCTerminalMenu(ply, npc, "chopshop")) - шкафы выключены (McCD.Config.Terminals = false)
function McCD.NPCTerminalMenu(ply, npc, tp)
	if not IsValid(npc) or not types[tp] then return end

	local ok, msg = McCD.CanOpen(ply)
	if not ok then
		if msg then DarkRP.notify(ply, 1, 4, msg) end
		return
	end

	ply.McCD_TermNPC = {ent = npc, type = tp, time = CurTime()}
	types[tp](ply, npc)
end

function McCD.WorkshopMenu(ply, npc)
	McCD.NPCTerminalMenu(ply, npc, "workshop")
end

function McCD.TerminalUse(ply, ent)
	local fn = types[ent:GetTermType()]
	if not fn then return end

	local ok, msg = McCD.CanOpen(ply)
	if not ok then
		if msg then DarkRP.notify(ply, 1, 4, msg) end
		return
	end

	fn(ply, ent)
end

net.Receive("McCD.Terminal", function(len, ply)
	if DarkRP.NetDelay(ply, "McCD.Terminal", 1) then return end

	local ent = net.ReadEntity()
	local key = net.ReadString()

	if not IsValid(ent) then return end
	if not ply:Alive() or not ply:IsUnrestrained() or ply:InVehicle() then return end
	if ent:GetPos():DistToSqr(ply:GetPos()) > USE_DIST then return end

	local tp
	if ent.IsMcCDTerminal then
		tp = ent:GetTermType()
	else
		-- шаг 54: меню открыл NPC (McCD.NPCTerminalMenu)
		local s = ply.McCD_TermNPC
		if not s or s.ent ~= ent or s.time + 600 < CurTime() then return end
		tp = s.type
	end

	if tp == "chopshop" then
		if key == "check" then
			McCD.ChopShopCheck(ply, ent)
		elseif key == "sell" then
			McCD.ChopShopSell(ply, ent)
		end
	elseif tp == "workshop" then
		if not McCD.Upgrades or not McCD.Upgrades[key] then return end

		McCD.Workshop(ply, ent, {upgrade = key})
	end
end)

--[[---------------------------------------------------------------------------
Расстановка: конфиг (McCD.Config.EntSpawns) + сохранённые админом (data/mccd_terminals_<карта>.json)
---------------------------------------------------------------------------]]
local function saveFile()
	return "mccd_terminals_" .. string.lower(game.GetMap()) .. ".json"
end

function McCD.LoadSavedTerminals()
	local data = file.Read(saveFile(), "DATA")
	local tbl = data and util.JSONToTable(data)

	return istable(tbl) and tbl or {}
end

function McCD.SaveTerminals(tbl)
	file.Write(saveFile(), util.TableToJSON(tbl, true))
end

local function floorPos(pos)
	local tr = util.TraceLine({
		start = pos + Vector(0, 0, 40),
		endpos = pos - Vector(0, 0, 300),
		mask = MASK_SOLID_BRUSHONLY
	})

	return (tr.Hit and not tr.StartSolid) and tr.HitPos or pos
end

function McCD.SpawnTerminal(v, saved_id)
	local tp = McCD.Terminals[v.type] and v.type or "dealer"
	local ent = ents.Create(McCD.Terminals[tp].class)
	if not IsValid(ent) then return end

	local pos = floorPos(v.pos)

	ent.TermModel = v.model
	ent:SetType(tp)
	ent:SetNameType(v.name or McCD.Terminals[tp].name)
	ent:SetPos(pos)
	ent:SetAngles(v.ang or Angle(0, 0, 0))
	ent:Spawn()
	ent:Activate()

	-- модель стоит на полу, а не утоплена наполовину
	ent:SetPos(pos + Vector(0, 0, -ent:OBBMins().z))

	ent.McCD_Auto = true
	ent.McCD_SavedID = saved_id

	return ent
end

function McCD.SpawnTerminals()
	local c = conf()

	for _, v in ipairs(ents.GetAll()) do
		if v.IsMcCDTerminal and (v.McCD_Auto or c.Terminals == false) then v:Remove() end
	end

	if c.Terminals == false then return end -- шаг 54
	local map = c.TerminalMap or ""

	if map == "" or string.find(string.lower(game.GetMap()), map, 1, true) then
		for _, v in ipairs(c.EntSpawns or {}) do
			McCD.SpawnTerminal(v)
		end
	end

	for id, v in ipairs(McCD.LoadSavedTerminals()) do
		if not v.pos then continue end

		McCD.SpawnTerminal({
			type = v.type,
			name = v.name,
			model = v.model,
			pos = Vector(v.pos[1], v.pos[2], v.pos[3]),
			ang = Angle(0, v.yaw or 0, 0),
		}, id)
	end
end

hook.Add("InitPostEntity", "McCD.SpawnTerminals", function()
	timer.Simple(3, McCD.SpawnTerminals)
end)

hook.Add("PostCleanupMap", "McCD.SpawnTerminals", McCD.SpawnTerminals)

--[[---------------------------------------------------------------------------
Команды (суперадмин, консоль):
  mccd_terminal_add <dealer|garage|chopshop|workshop> [название] - шкаф в точку прицела, лицом к вам (сохраняется)
  mccd_terminal_remove - убрать сохранённый шкаф под прицелом
  mccd_terminal_pos [тип] - строка для McCD.Config.EntSpawns по точке прицела
  mccd_terminal_reload - пересоздать все шкафы
---------------------------------------------------------------------------]]
local function isAdm(ply)
	return not IsValid(ply) or ply:IsSuperAdmin()
end

local function aim(ply)
	local tr = ply:GetEyeTrace()

	return tr.HitPos, math.Round(ply:EyeAngles().y + 180)
end

concommand.Add("mccd_terminal_add", function(ply, cmd, args)
	if not IsValid(ply) or not isAdm(ply) then return end

	if conf().Terminals == false then
		DarkRP.notify(ply, 1, 6, "Шкафы выключены: McCD.Config.Terminals = false (mc_cardealer/sh_config.lua)")
		return
	end

	local tp = args[1]
	if not McCD.Terminals[tp] then
		ply:PrintMessage(HUD_PRINTCONSOLE, "Тип: dealer, garage, chopshop, workshop")
		return
	end

	local name = #args > 1 and table.concat(args, " ", 2) or nil
	local pos, yaw = aim(ply)

	local tbl = McCD.LoadSavedTerminals()
	table.insert(tbl, {type = tp, name = name, pos = {math.Round(pos.x, 2), math.Round(pos.y, 2), math.Round(pos.z, 2)}, yaw = yaw})
	McCD.SaveTerminals(tbl)

	McCD.SpawnTerminal({type = tp, name = name, pos = pos, ang = Angle(0, yaw, 0)}, #tbl)
	DarkRP.notify(ply, 0, 4, "Шкаф \"" .. (name or McCD.Terminals[tp].name) .. "\" поставлен и сохранён")
end)

concommand.Add("mccd_terminal_remove", function(ply)
	if not IsValid(ply) or not isAdm(ply) then return end

	local ent = ply:GetEyeTrace().Entity
	if not IsValid(ent) or not ent.IsMcCDTerminal then
		DarkRP.notify(ply, 1, 4, "Смотрите на шкаф автосалона")
		return
	end

	if not ent.McCD_SavedID then
		DarkRP.notify(ply, 1, 4, "Этот шкаф из конфига (McCD.Config.EntSpawns) или PermaProps - уберите его там")
		return
	end

	local tbl = McCD.LoadSavedTerminals()
	table.remove(tbl, ent.McCD_SavedID)
	McCD.SaveTerminals(tbl)

	McCD.SpawnTerminals()
	DarkRP.notify(ply, 0, 4, "Шкаф убран")
end)

concommand.Add("mccd_terminal_pos", function(ply, cmd, args)
	if not IsValid(ply) or not isAdm(ply) then return end

	local pos, yaw = aim(ply)
	local line = string.format("{type = %q, pos = Vector(%.2f, %.2f, %.2f), ang = Angle(0, %d, 0)},", args[1] or "dealer", pos.x, pos.y, pos.z, yaw)

	ply:PrintMessage(HUD_PRINTCONSOLE, line)
	ply:ChatPrint(line)
end)

concommand.Add("mccd_terminal_reload", function(ply)
	if not isAdm(ply) then return end

	McCD.SpawnTerminals()
end)
