-- "addons\\cardealer\\lua\\entities\\mccd_terminal\\cl_init.lua"
include("shared.lua")

local cl_bl_150 = Color(0, 0, 0, 150)
local color_hint = Color(200, 200, 200)
local DRAW_DIST = 300 ^ 2

function ENT:Draw()
	self:DrawModel()

	if self:GetPos():DistToSqr(LocalPlayer():GetPos()) > DRAW_DIST then return end

	local yaw = LocalPlayer():EyeAngles().y - 90
	local pos = self:GetPos() + Vector(0, 0, self:OBBMaxs().z + 12)
	local t = McCD.Terminals and McCD.Terminals[self:GetTermType()]

	cam.Start3D2D(pos, Angle(0, yaw, 90), 0.08)
		local text = self:GetNameType()
		surface.SetFont("MSDFontB.32")
		local tw = surface.GetTextSize(text)

		draw.RoundedBox(0, -tw / 2 - 20, -10, tw + 40, 80, cl_bl_150)
		draw.SimpleText(text, "MSDFontB.32", 0, 0, color_white, TEXT_ALIGN_CENTER)
		draw.SimpleText("[E] " .. (t and t.hint or ""), "MSDFont.22", 0, 38, color_hint, TEXT_ALIGN_CENTER)
	cam.End3D2D()
end

net.Receive("McCD.Terminal", function()
	local ent = net.ReadEntity()
	local title = net.ReadString()
	local n = net.ReadUInt(4)
	local opts = {}

	for i = 1, n do
		opts[i] = {net.ReadString(), net.ReadString()}
	end

	if not IsValid(ent) or n == 0 then return end

	local menu = DermaMenu()
	menu:AddOption(title):SetEnabled(false)
	menu:AddSpacer()

	for _, v in ipairs(opts) do
		menu:AddOption(v[2], function()
			net.Start("McCD.Terminal")
				net.WriteEntity(ent)
				net.WriteString(v[1])
			net.SendToServer()
		end)
	end

	menu:AddOption("Закрыть")
	menu:Open(ScrW() / 2, ScrH() / 2)
end)
