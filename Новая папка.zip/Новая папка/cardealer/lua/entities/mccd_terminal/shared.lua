-- "addons\\cardealer\\lua\\entities\\mccd_terminal\\shared.lua"
-- Шкаф-терминал автосалона вместо NPC: E - меню (тип в NWString "Type").
-- Классы: mccd_terminal (автосалон), mccd_terminal_garage, mccd_terminal_chop, mccd_terminal_workshop
ENT.Base = "base_gmodentity"
ENT.Type = "anim"
ENT.PrintName = "Автосалон (шкаф)"
ENT.Category = "N.Y. Noire"
ENT.Spawnable = true
ENT.AdminOnly = true
ENT.IsMcCDTerminal = true
ENT.TerminalType = "dealer"

function ENT:SetupDataTables()
	self:NetworkVar("String", 0, "NameType")
	self:NetworkVar("String", 1, "Type")
end

function ENT:GetTermType()
	local tp = self:GetType()

	return (tp and tp ~= "") and tp or self.TerminalType
end

McCD = McCD or {}

McCD.Terminals = {
	["dealer"] = {name = "Автосалон", hint = "Покупка машин и гараж", class = "mccd_terminal"},
	["garage"] = {name = "Гараж", hint = "Ваши машины", class = "mccd_terminal_garage"},
	["chopshop"] = {name = "Разборка", hint = "Сдать машину на запчасти", class = "mccd_terminal_chop"},
	["workshop"] = {name = "Автомастерская", hint = "Улучшения для вашей машины", class = "mccd_terminal_workshop"},
}
