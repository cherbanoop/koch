-- "addons\\cardealer\\lua\\entities\\mccd_terminal_chop\\shared.lua"
AddCSLuaFile()

ENT.Base = "mccd_terminal"
ENT.Type = "anim"
ENT.PrintName = "Разборка (шкаф)"
ENT.Category = "N.Y. Noire"
ENT.Spawnable = true
ENT.AdminOnly = true
ENT.TerminalType = "chopshop"
