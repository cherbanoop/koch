-- "addons\\cardealer\\lua\\autorun\\mc_cd_ext.lua"
--[[---------------------------------------------------------------------------
McCD - общая часть сервера автосалона (грузится до mc_cd_load.lua - McCD трогаем только в хуках)
  Ключи: владелец машины из гаража (NW2String "McCD.Owner" = SteamID64) открывает/закрывает её
         ключами, подсказка "ПКМ" видна и на клиенте. keysOwn не используется (не занимает лимит дверей).
  SAM (категория "Cars"):
    givecar <игрок> <класс>  - выдать машину в гараж (superadmin)
    takecar <игрок> <класс>  - изъять последнюю машину класса (superadmin)
    returncar <игрок>        - вернуть все машины игрока с улицы в гараж (admin)
  Оффлайн-выдача: консоль сервера mccd_givecar / mccd_takecar (mc_cardealer/sv_init.lua)
---------------------------------------------------------------------------]]
local function isCarOwner(ply, ent)
	if not IsValid(ply) or not IsValid(ent) or not ent.IsSimfphyscar then return false end

	local sid = ent:GetNW2String("McCD.Owner", "")

	return sid ~= "" and sid == ply:SteamID64()
end

hook.Add("canKeysLock", "McCD.OwnerKeys", function(ply, ent)
	if isCarOwner(ply, ent) then return true end
end)

hook.Add("canKeysUnlock", "McCD.OwnerKeys", function(ply, ent)
	if isCarOwner(ply, ent) then return true end
end)

local function addCommands()
	if not sam or not sam.command or not sam.command.new then return end
	if sam.command.get_command and sam.command.get_command("givecar") then return end

	sam.command.new("givecar")
		:SetCategory("Cars")
		:SetPermission("givecar", "superadmin")
		:AddArg("player", {single_target = true})
		:AddArg("text", {hint = "класс машины"})
		:Help("Выдать машину в гараж игрока")
		:OnExecute(function(ply, targets, class)
			McCD.AdminCommand(ply, "give", targets[1], string.Trim(class or ""))
		end)
	:End()

	sam.command.new("takecar")
		:SetCategory("Cars")
		:SetPermission("takecar", "superadmin")
		:AddArg("player", {single_target = true})
		:AddArg("text", {hint = "класс машины"})
		:Help("Изъять машину из гаража игрока")
		:OnExecute(function(ply, targets, class)
			McCD.AdminCommand(ply, "take", targets[1], string.Trim(class or ""))
		end)
	:End()

	sam.command.new("returncar")
		:SetCategory("Cars")
		:SetPermission("returncar", "admin")
		:AddArg("player", {single_target = true})
		:Help("Вернуть машины игрока с улицы в гараж")
		:OnExecute(function(ply, targets)
			McCD.AdminCommand(ply, "return", targets[1])
		end)
	:End()
end

hook.Add("PostGamemodeLoaded", "McCD.SAM", addCommands)

if GAMEMODE then addCommands() end
