-- "addons\\cardealer\\lua\\mc_cardealer\\sv_db.lua"
--[[---------------------------------------------------------------------------
McCD - база машин игроков (SQLite, sv.db)
  mccd_cars: id, steamid (SteamID64 - машины общие для всех персонажей аккаунта),
             class (класс simfphys), plate (номер), data (JSON: цвет, тюнинг, флаги), created
  В data пишутся только поля из McCD.DB.Fields, остальное (name, refundprice...) считается из каталога.
---------------------------------------------------------------------------]]
McCD.DB = McCD.DB or {}

local function q(str)
	local res = sql.Query(str)

	if res == false then
		ErrorNoHalt("[McCD] SQL ошибка: " .. tostring(sql.LastError()) .. "\n" .. str .. "\n")
	end

	return res
end

McCD.DB.Query = q

q([[CREATE TABLE IF NOT EXISTS mccd_cars (
	id INTEGER PRIMARY KEY AUTOINCREMENT,
	steamid TEXT NOT NULL,
	class TEXT NOT NULL,
	plate TEXT,
	data TEXT,
	created INTEGER NOT NULL DEFAULT 0
)]])

q("CREATE INDEX IF NOT EXISTS mccd_cars_steamid ON mccd_cars (steamid)")
q("CREATE INDEX IF NOT EXISTS mccd_cars_plate ON mccd_cars (plate)")

McCD.DB.Fields = {
	"color", "skin", "skin_pack", "bodygroups", "suspension", "nitro", "breaks", "horn", "smoke", "neon",
	"plates", "lpcd", "unlockedbg", "wci", "wcitimer", "radio", "bpw", "turbo", "super", "blown",
	"originalprice", "donate", "bought",
}

local function isNull(v)
	return v == nil or v == "NULL" or v == ""
end

function McCD.DB.Encode(car)
	local data = {}

	for _, k in ipairs(McCD.DB.Fields) do
		local v = car[k]
		if v == nil then continue end

		if k == "color" and istable(v) then
			v = {r = v.r or 255, g = v.g or 255, b = v.b or 255, a = v.a or 255}
		elseif k == "bodygroups" and istable(v) then
			local bg = {}

			for id, val in pairs(v) do
				bg[tostring(id)] = tonumber(val)
			end

			v = bg
		end

		data[k] = v
	end

	return util.TableToJSON(data) or "{}"
end

function McCD.DB.Decode(row)
	local data = util.JSONToTable(row.data or "") or {}
	local car = {}

	for _, k in ipairs(McCD.DB.Fields) do
		car[k] = data[k]
	end

	if istable(car.color) then
		local c = car.color
		car.color = Color(tonumber(c.r) or 255, tonumber(c.g) or 255, tonumber(c.b) or 255, tonumber(c.a) or 255)
	else
		car.color = nil
	end

	if istable(car.bodygroups) then
		local bg = {}

		for id, val in pairs(car.bodygroups) do
			id, val = tonumber(id), tonumber(val)
			if id and val then bg[id] = val end
		end

		car.bodygroups = bg
	else
		car.bodygroups = nil
	end

	car.id = tonumber(row.id)
	car.entity = row.class
	car.steamid = row.steamid
	car.uniqueid = not isNull(row.plate) and row.plate or nil
	car.created = tonumber(row.created) or 0

	return car
end

-- все машины аккаунта (по порядку покупки)
function McCD.DB.Load(sid64)
	local res = q("SELECT * FROM mccd_cars WHERE steamid = " .. sql.SQLStr(sid64) .. " ORDER BY id ASC")
	local cars = {}

	if not istable(res) then return cars end

	for _, row in ipairs(res) do
		table.insert(cars, McCD.DB.Decode(row))
	end

	return cars
end

function McCD.DB.Get(id)
	id = math.floor(tonumber(id) or 0)
	if id < 1 then return end

	local res = q("SELECT * FROM mccd_cars WHERE id = " .. id)
	if not istable(res) or not res[1] then return end

	return McCD.DB.Decode(res[1])
end

-- последняя машина класса у аккаунта (для админ-команд)
function McCD.DB.FindClass(sid64, class)
	local res = q("SELECT * FROM mccd_cars WHERE steamid = " .. sql.SQLStr(sid64) .. " AND class = " .. sql.SQLStr(class) .. " ORDER BY id DESC LIMIT 1")
	if not istable(res) or not res[1] then return end

	return McCD.DB.Decode(res[1])
end

function McCD.DB.Insert(sid64, car)
	local ok = q(string.format("INSERT INTO mccd_cars (steamid, class, plate, data, created) VALUES (%s, %s, %s, %s, %d)",
		sql.SQLStr(sid64), sql.SQLStr(car.entity), car.uniqueid and sql.SQLStr(car.uniqueid) or "NULL", sql.SQLStr(McCD.DB.Encode(car)), os.time()))

	if ok == false then return end

	local id = tonumber(sql.QueryValue("SELECT last_insert_rowid()"))
	if not id or id < 1 then return end

	car.id = id
	car.steamid = sid64
	car.created = os.time()

	return id
end

function McCD.DB.Save(car)
	if not car or not car.id then return end

	q(string.format("UPDATE mccd_cars SET class = %s, plate = %s, data = %s WHERE id = %d",
		sql.SQLStr(car.entity), car.uniqueid and sql.SQLStr(car.uniqueid) or "NULL", sql.SQLStr(McCD.DB.Encode(car)), car.id))
end

function McCD.DB.Delete(id)
	id = math.floor(tonumber(id) or 0)
	if id < 1 then return end

	q("DELETE FROM mccd_cars WHERE id = " .. id)
end

function McCD.DB.PlateExists(plate)
	local res = sql.QueryValue("SELECT 1 FROM mccd_cars WHERE plate = " .. sql.SQLStr(plate) .. " LIMIT 1")

	return res ~= nil and res ~= false
end
