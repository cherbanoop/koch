-- "addons\\cardealer\\lua\\mc_cardealer\\sv_init.lua"
--[[---------------------------------------------------------------------------
McCD - серверная часть автосалона (клиент: cl_init.lua, net "McCD.Msg")
  Клиент -> сервер, UInt(3) операция:
    0 Bool           - список машин (true - "Купленные авто" / продажа, false - "Гараж")
    1 String Float   - купить машину (класс, индекс цвета палитры)
    2 UInt32 [Bool]  - продать машину (индекс; донат-машина: true - обмен на ¤, false - продажа за $)
    3 Float String   - тюнинг (индекс машины, тип + данные типа - см. Tune ниже)
    4 UInt16         - вывезти машину из гаража
  Сервер -> клиент: String "Garage" Table Bool / String "GarageUpdate" Table Float
  Машины хранятся на аккаунт (SteamID64, sv_db.lua) и доступны всем персонажам игрока.
  Открытие - действия MCS NPC "DarkRP Автосалон" / "DarkRP Гараж" (gamemode: modules/base/sh_compat.lua).
---------------------------------------------------------------------------]]
util.AddNetworkString("McCD.Msg")

local cfg = McCD.Config

cfg.BaseSlots = cfg.BaseSlots or 5 -- места в гараже без MQS "car_slots" (клиент показывает 5 + car_slots)
cfg.UnlockBodyGroups = cfg.UnlockBodyGroups or 750 -- ¤, разблокировка кастомизации кузова (как в меню)
cfg.CreditRate = cfg.CreditRate or 150 -- $ за 1¤ при продаже донат-машины за деньги
cfg.MenuDist = cfg.MenuDist or 400 -- меню работает рядом с NPC
cfg.ReturnDist = cfg.ReturnDist or 2000 -- машина "у гаража": её можно тюнинговать/продать/забрать
cfg.MaxSpawned = cfg.MaxSpawned or 1 -- машин на улице одновременно
cfg.NitroTorque = cfg.NitroTorque or 0.02 -- +2% тяги за уровень двигателя (как в меню)
cfg.NitroGrip = cfg.NitroGrip or 0.03 -- -3% сцепления за уровень, начиная со 2-го
cfg.BrakesMul = cfg.BrakesMul or 0.1 -- +10% тормозного усилия за уровень
cfg.WorkshopDist = cfg.WorkshopDist or 700 -- автомастерская: машина должна стоять рядом с NPC

local PLAYER = FindMetaTable("Player")
local CAR_CLASS = "gmod_sent_vehicle_fphysics_base"

local function vehList()
	return list.GetForEdit and list.GetForEdit("simfphys_vehicles") or list.Get("simfphys_vehicles")
end

-- Float/UInt с клиента -> целый индекс (NaN/inf отбрасываем)
local function readIndex(v)
	v = tonumber(v)
	if not v or v ~= v or v == math.huge or v == -math.huge then return end

	return math.floor(v)
end

local function niceTime(sec)
	sec = math.max(math.floor(sec or 0), 0)

	local h, m = math.floor(sec / 3600), math.floor(sec % 3600 / 60)
	if h > 0 then return h .. " ч " .. m .. " мин" end
	if m > 0 then return m .. " мин" end

	return sec .. " сек"
end

local function say(ply, typ, text)
	if IsValid(ply) then
		DarkRP.notify(ply, typ, 5, text)
	else
		print("[McCD] " .. text)
	end
end

local function hasGroup(ply, groups)
	local group = ply:GetUserGroup()

	for _, v in pairs(groups) do
		if group == v then return true end
		if v == "admin" and ply:IsAdmin() then return true end
		if v == "superadmin" and ply:IsSuperAdmin() then return true end
	end

	return false
end

local function occupied(ent)
	if ent.GetDriver and IsValid(ent:GetDriver()) then return true end
	if IsValid(ent.DriverSeat) and IsValid(ent.DriverSeat:GetDriver()) then return true end

	if istable(ent.pSeat) then
		for _, seat in pairs(ent.pSeat) do
			if IsValid(seat) and IsValid(seat:GetDriver()) then return true end
		end
	end

	return false
end

McCD.IsOccupied = occupied

local function plateMat(car)
	local p = car.plates and cfg.Plates[car.plates]
	if p and p[2] and p[2] ~= "" then return p[2] end
end

local function gps(ply, name, pos)
	if McPhone and McPhone.ToggleGPS then
		McPhone.ToggleGPS(ply, name, pos)
	end
end

--[[---------------------------------------------------------------------------
Машины игрока (кеш ply.McCD_Cars, порядок = индексы меню клиента)
---------------------------------------------------------------------------]]
function McCD.PrepareCar(car)
	local shop = McCD.Cars[car.entity]
	if not shop then return car end

	car.name = shop.name or car.entity
	if car.donate == nil then car.donate = shop.donate and true or false end
	car.originalprice = car.originalprice or shop.price or 0

	return car
end

-- в меню попадают только машины, которые есть в каталоге и в simfphys (иначе клиент сломается)
function PLAYER:LoadCars(force)
	if self.McCD_Cars and not force then return self.McCD_Cars end

	local vlist, cars = vehList(), {}

	for _, car in ipairs(McCD.DB.Load(self:SteamID64())) do
		if not McCD.Cars[car.entity] or not vlist[car.entity] then continue end

		table.insert(cars, McCD.PrepareCar(car))
	end

	self.McCD_Cars = cars

	for _, ent in ipairs(McCD.GetSpawnedList(self)) do
		local car = McCD.FindCar(self, ent.McCD_CarDataId)
		if car then ent.McCD_CarData = car end
	end

	return cars
end

function McCD.GetCars(ply)
	return ply:LoadCars()
end

function McCD.GetCar(ply, idx)
	idx = readIndex(idx)
	if not idx then return end

	return ply:LoadCars()[idx]
end

function McCD.FindCar(ply, id)
	id = tonumber(id)
	if not id then return end

	for i, car in ipairs(ply:LoadCars()) do
		if car.id == id then return car, i end
	end
end

function McCD.MaxCars(ply)
	local extra = MQS and MQS.GetDataStored and tonumber(MQS.GetDataStored(ply, "car_slots")) or 0

	return cfg.BaseSlots + math.max(extra, 0)
end

function McCD.RefundPrice(car)
	local shop = McCD.Cars[car.entity]
	local price = car.originalprice or (shop and shop.price) or 0

	return math.Round(price * (cfg.RefundPercentage or 70) / 100)
end

-- кузов: фиксы каталога (shop.bodygroups) + выбор игрока
function McCD.GetBodygroups(car)
	local shop = McCD.Cars[car.entity] or {}
	local bg = {}

	for id, v in pairs(shop.bodygroups or {}) do bg[id] = v end
	for id, v in pairs(car.bodygroups or {}) do bg[id] = v end

	return bg
end

-- машина "потеряна" (разборка ChopShop) - true, пока не истёк wcitimer
function McCD.CheckLost(car)
	if not car or not car.wcitimer then return false end
	if car.wcitimer > os.time() then return true end

	car.wci, car.wcitimer = nil, nil
	if car.id then McCD.DB.Save(car) end

	return false
end

local clientFields = {"name", "donate", "color", "skin", "skin_pack", "suspension", "nitro", "breaks", "horn",
	"smoke", "neon", "plates", "lpcd", "wci", "wcitimer", "radio", "bpw", "turbo", "super"}

local shopFields = {"nocase", "noskin", "tuneblock", "allowed_skins", "baned_bg", "baned_bgs", "fweels", "wheel_ang",
	"garage_vect", "garage_angle"}

function McCD.ClientCar(car)
	local shop = McCD.Cars[car.entity] or {}
	local t = {
		entity = car.entity,
		uniqueid = car.uniqueid,
		refundprice = McCD.RefundPrice(car),
		unlockedbg = (car.unlockedbg or shop.unlockedbg) and true or nil,
	}

	for _, k in ipairs(clientFields) do t[k] = car[k] end
	for _, k in ipairs(shopFields) do t[k] = shop[k] end

	if not t.donate then t.donate = nil end

	local bg = McCD.GetBodygroups(car)
	if next(bg) then t.bodygroups = bg end

	return t
end

local function clientList(ply)
	local list = {}

	for i, car in ipairs(ply:LoadCars()) do
		McCD.CheckLost(car)
		list[i] = McCD.ClientCar(car)
	end

	return list
end

function McCD.SendGarage(ply, sell)
	local list = clientList(ply)

	net.Start("McCD.Msg")
		net.WriteString("Garage")
		net.WriteTable(list)
		net.WriteBool(sell and true or false)
	net.Send(ply)

	return #list
end

-- клиент берёт CarInventory[idx].uniqueid - индекс обязан существовать
function McCD.SendUpdate(ply, idx)
	idx = readIndex(idx)
	if not idx or not ply:LoadCars()[idx] then return end

	net.Start("McCD.Msg")
		net.WriteString("GarageUpdate")
		net.WriteTable(clientList(ply))
		net.WriteFloat(idx)
	net.Send(ply)
end

--[[---------------------------------------------------------------------------
Выдача / изменение / удаление
---------------------------------------------------------------------------]]
-- DarkRP.GenLPlate режет строку до 24 символов вместе с os.time() - сид должен быть коротким
function McCD.GenPlate()
	for i = 1, 25 do
		local plate = DarkRP.GenLPlate(math.random(10000, 99999) .. i)
		if not McCD.DB.PlateExists(plate) then return plate end
	end

	return DarkRP.GenLPlate(math.random(100000, 999999))
end

function McCD.NewCar(class, data)
	local shop = McCD.Cars[class]
	local palette = shop.palette or cfg.CarColors
	local pc = #palette > 0 and palette[math.random(#palette)]
	local c = pc and pc[1] or color_white

	local car = {
		entity = class,
		color = Color(c.r, c.g, c.b),
		donate = shop.donate and true or false,
		originalprice = shop.price or 0,
		radio = true,
		bought = os.time(),
	}

	if istable(data) then
		for k, v in pairs(data) do car[k] = v end
	end

	car.uniqueid = car.uniqueid or McCD.GenPlate()

	return McCD.PrepareCar(car)
end

-- glac (донат-магазин, кейсы) вызывает через pcall: ошибка = возврат кредитов
function McCD.AddCar(ply, class, data, silent)
	if not IsValid(ply) or not ply:IsPlayer() then error("McCD.AddCar: игрок не найден", 2) end
	if not McCD.Cars[class] or not vehList()[class] then error("McCD.AddCar: неизвестная машина " .. tostring(class), 2) end

	local cars = ply:LoadCars()
	local car = McCD.NewCar(class, data)

	if not McCD.DB.Insert(ply:SteamID64(), car) then error("McCD.AddCar: ошибка базы данных", 2) end

	table.insert(cars, car)

	if not silent then
		DarkRP.notify(ply, 0, 6, "Машина " .. car.name .. " добавлена в ваш гараж (номер " .. car.uniqueid .. ")")
	end

	DarkRP.log("property", ply, nil, "получил машину " .. class .. " (" .. car.uniqueid .. ")")
	hook.Run("McCD.CarAdded", ply, car)

	return car, #cars
end

function McCD.AddCarOffline(sid64, class, data)
	if not McCD.Cars[class] or not vehList()[class] then return end

	local car = McCD.NewCar(class, data)
	if not McCD.DB.Insert(sid64, car) then return end

	return car
end

local function locateCar(id, ply, ent)
	if IsValid(ent) and ent.McCD_CarData and ent.McCD_CarData.id == id then return ent.McCD_CarData end

	if IsValid(ply) and ply:IsPlayer() then
		local car = McCD.FindCar(ply, id)
		if car then return car end
	end

	for _, v in ipairs(player.GetAll()) do
		if not v.McCD_Cars then continue end

		local car = McCD.FindCar(v, id)
		if car then return car end
	end

	return McCD.DB.Get(id)
end

-- изменить поля машины (ChopShop: wci/radio/wcitimer); владелец может быть оффлайн
function McCD.AddCarParameter(ply, id, params, ent)
	id = tonumber(id)
	if not id or not istable(params) then return end

	local car = locateCar(id, ply, ent)
	if not car then return end

	for k, v in pairs(params) do
		car[k] = v
	end

	McCD.DB.Save(car)

	local spawned = (IsValid(ent) and ent.McCD_CarDataId == id) and ent or McCD.GetSpawned(car)
	if IsValid(spawned) then
		McCD.ApplyLive(spawned, car)
	end

	return car
end

function McCD.RemoveCar(ply, idx)
	local cars = ply:LoadCars()
	local car = cars[idx]
	if not car then return end

	McCD.DB.Delete(car.id)
	table.remove(cars, idx)

	return car
end

--[[---------------------------------------------------------------------------
Машины на улице
---------------------------------------------------------------------------]]
function McCD.GetSpawned(car)
	if not car or not car.id then return end

	for _, ent in ipairs(ents.FindByClass(CAR_CLASS)) do
		if ent.McCD_CarDataId == car.id and not ent.McCD_Returned then return ent end
	end
end

function McCD.GetSpawnedList(ply)
	local res = {}
	if not IsValid(ply) then return res end

	local sid = ply:SteamID64()

	for _, ent in ipairs(ents.FindByClass(CAR_CLASS)) do
		if ent.McCD_CarDataId and ent.McCD_OwnerSID == sid and not ent.McCD_Returned then
			table.insert(res, ent)
		end
	end

	return res
end

-- убрать машину в гараж (silent - без уведомления владельцу)
function McCD.ReturnCar(ent, silent)
	if not IsValid(ent) or ent.McCD_Returned then return end

	ent.McCD_Returned = true
	ent.McCD_Silent = silent
	ent:Remove()
end

-- свободная машина у гаража (рядом с NPC текущей сессии)
local function nearGarage(ply, ent)
	if occupied(ent) then return false end

	local s = ply.McCD_Session
	local pos = s and s.pos or ply:GetPos()

	return ent:GetPos():DistToSqr(pos) <= cfg.ReturnDist ^ 2
end

--[[---------------------------------------------------------------------------
Сессия меню (NPC)
---------------------------------------------------------------------------]]
function McCD.SetSession(ply, npc, mode)
	ply.McCD_Session = {
		npc = npc,
		pos = IsValid(npc) and npc:GetPos() or ply:GetPos(),
		mode = mode,
		time = CurTime(),
	}
end

function McCD.InSession(ply)
	local s = ply.McCD_Session
	if not s then return false end

	if s.time + 3600 < CurTime() then
		ply.McCD_Session = nil
		return false
	end

	return ply:GetPos():DistToSqr(s.pos) <= cfg.MenuDist ^ 2
end

function McCD.CanOpen(ply)
	if not IsValid(ply) or not ply:IsPlayer() then return false end
	if ply.DarkRPUnInitialized or not ply:getDarkRPVar("character") then return false, "Сначала выберите персонажа" end
	if not ply:IsFreeman() then return false end
	if ply:InVehicle() then return false, "Сначала выйдите из машины" end

	local team, bl = ply:Team(), cfg.BlackListJobs or {}
	if bl[team] == true or table.HasValue(bl, team) then return false, "С этой профессией автосалон недоступен" end

	local ok, msg = hook.Run("McCD.CanOpen", ply)
	if ok == false then return false, msg end

	return true
end

function McCD.CanUse(ply)
	return McCD.InSession(ply) and ply:IsFreeman() and not ply:InVehicle()
end

function McCD.OpenList(ply, sell)
	if McCD.SendGarage(ply, sell) > 0 then return true end

	DarkRP.notify(ply, 1, 4, "У вас пока нет машин - их можно купить в автосалоне")

	return false
end

-- автосалон: покупка + гараж (меню клиента McCD.OpenGarage(true))
function McCD.OpenDealer(ply, npc)
	local ok, msg = McCD.CanOpen(ply)
	if not ok then
		if msg then DarkRP.notify(ply, 1, 4, msg) end
		return
	end

	ply:LoadCars()
	McCD.SetSession(ply, npc, "dealer")
	ply:SendLua("if McCD and McCD.OpenGarage then McCD.OpenGarage(true) end")
end

-- только гараж (меню открывается ответом "Garage")
function McCD.OpenGarageMenu(ply, npc)
	local ok, msg = McCD.CanOpen(ply)
	if not ok then
		if msg then DarkRP.notify(ply, 1, 4, msg) end
		return
	end

	McCD.SetSession(ply, npc, "garage")
	McCD.OpenList(ply, false)
end

-- шаг 54: NPC "Продавец" - "Я хочу убрать свой автомобиль в гараж": свободные машины игрока
-- в ReturnDist от NPC уезжают в гараж (раньше этот ответ слал несуществующую операцию и ничего не делал)
function McCD.ReturnNear(ply, npc)
	local ok, msg = McCD.CanOpen(ply)
	if not ok then
		if msg then DarkRP.notify(ply, 1, 4, msg) end
		return
	end

	local pos = IsValid(npc) and npc:GetPos() or ply:GetPos()
	local n = 0

	for _, ent in ipairs(McCD.GetSpawnedList(ply)) do
		if IsValid(ent) and not ent.McCD_Returned and not occupied(ent) and ent:GetPos():DistToSqr(pos) <= cfg.ReturnDist ^ 2 then
			McCD.ReturnCar(ent)
			n = n + 1
		end
	end

	if n == 0 then
		DarkRP.notify(ply, 1, 4, "Рядом нет вашей свободной машины - подгоните её к автосалону и выйдите из неё")
	end
end

--[[---------------------------------------------------------------------------
Парковка: зоны McCD.Config.SpawnZone {угол, угол, Angle} и платформы mcarspawn
---------------------------------------------------------------------------]]
local function blocking(v, ignore)
	if not IsValid(v) or v:IsWorld() then return false end
	if ignore and (ignore[v] or ignore[v:GetParent()] or (v.GetBaseEnt and ignore[v:GetBaseEnt()])) then return false end
	if v:IsPlayer() then return v:Alive() end
	if v:IsNPC() then return true end
	if v:CreatedByMap() or v:IsWeapon() or v:GetClass() == "mcarspawn" then return false end
	if v:GetSolid() == SOLID_NONE then return false end

	return v:IsVehicle() or IsValid(v:GetPhysicsObject())
end

local function spotBusy(mins, maxs, ignore)
	for _, v in ipairs(ents.FindInBox(mins, maxs)) do
		if blocking(v, ignore) then return true end
	end

	return false
end

-- ближайшее к origin свободное место: pos, ang
function McCD.FindSpot(origin, ignore)
	local spots = {}

	for _, zone in ipairs(cfg.SpawnZone or {}) do
		local mins, maxs = Vector(zone[1]), Vector(zone[2])
		OrderVectors(mins, maxs)

		table.insert(spots, {mins = mins, maxs = maxs, center = (mins + maxs) / 2, ang = zone[3] or Angle(0, 0, 0)})
	end

	for _, pad in ipairs(ents.FindByClass("mcarspawn")) do
		local _min, _max = pad:GetModelBounds()
		local mins, maxs = pad:LocalToWorld(_min), pad:LocalToWorld(_max) + Vector(0, -200, 50)
		OrderVectors(mins, maxs)

		local pos = pad:GetPos() + Vector(0, -200, 50)
		table.insert(spots, {mins = mins, maxs = maxs, center = pos, pos = pos, ang = pad:GetAngles() + Angle(0, 90, 0)})
	end

	table.sort(spots, function(a, b) return a.center:DistToSqr(origin) < b.center:DistToSqr(origin) end)

	for _, s in ipairs(spots) do
		if spotBusy(s.mins, s.maxs, ignore) then continue end

		local pos = s.pos

		if not pos then
			local tr = util.TraceLine({
				start = Vector(s.center.x, s.center.y, s.maxs.z),
				endpos = Vector(s.center.x, s.center.y, s.mins.z - 64),
				mask = MASK_SOLID_BRUSHONLY
			})

			pos = (tr.Hit and not tr.StartSolid) and tr.HitPos or Vector(s.center.x, s.center.y, s.mins.z)
			pos = pos + Vector(0, 0, 30)
		end

		return pos, Angle(s.ang.p, s.ang.y, s.ang.r)
	end
end

--[[---------------------------------------------------------------------------
Машина на улице: владелец, внешний вид, опции, характеристики
---------------------------------------------------------------------------]]
function McCD.LinkOwner(ent, ply)
	ent.Owner = ply
	ent.McCDOwner = ply
	ent.EntityOwner = ply

	if ent.CPPISetOwner then ent:CPPISetOwner(ply) end
end

function McCD.SetupCar(ent, ply, car)
	ent.McCD_CarData = car
	ent.McCD_CarDataId = car.id
	ent.McCD_UniqueId = car.uniqueid
	ent.McCD_Plate = car.uniqueid
	ent.McCD_OwnerSID = ply:SteamID64()
	ent.McCD_SpawnTime = CurTime()
	ent.OwnerCharID = DarkRP.CharacterID(ply)
	ent.customplates = plateMat(car)

	McCD.LinkOwner(ent, ply)

	ent:SetNWString("McCD.UniqueId", car.uniqueid or "")
	ent:SetNW2String("McCD.Owner", ply:SteamID64())

	McCD.ApplyLook(ent, car)
	McCD.ApplyLive(ent, car)
end

function McCD.ApplyLook(ent, car)
	local shop = McCD.Cars[car.entity] or {}
	local c = car.color

	if istable(c) then
		ent:SetColor(Color(c.r or 255, c.g or 255, c.b or 255, c.a or 255))
	end

	ent:SetSkin(car.skin or 0)

	for id in pairs(ent.McCD_SubMats or {}) do
		ent:SetSubMaterial(id, "")
	end

	ent.McCD_SubMats = {}

	local pack = car.skin_pack and shop.skins_pack and shop.skins_pack[car.skin_pack]

	if pack then
		for id, mat in pairs(pack) do
			ent:SetSubMaterial(id, mat)
			ent.McCD_SubMats[id] = true
		end
	end

	for id, val in pairs(McCD.GetBodygroups(car)) do
		ent:SetBodygroup(id, val)
	end
end

-- опции, которые можно менять на ходу (радио, неон, дым, гудок, шины, наддув)
function McCD.ApplyLive(ent, car)
	ent:SetNWBool("MccD.Radio", car.radio ~= false)

	local neon = car.neon and cfg.Neon[car.neon] and car.neon or 0
	ent:SetNW2Int("MccD.Neon", neon)

	if neon <= 0 and ent.GetFogLightsEnabled and ent:GetFogLightsEnabled() then
		ent:SetFogLightsEnabled(false)
	end

	if ent.SetTireSmokeColor then
		local smoke = car.smoke and cfg.Smoke[car.smoke] and cfg.Smoke[car.smoke][2]
		ent:SetTireSmokeColor(smoke and Vector(smoke.r, smoke.g, smoke.b) / 255 or Vector(180, 180, 180) / 255)
	end

	local horn = car.horn and cfg.Horns[car.horn]
	local members = ent.VehicleTable and ent.VehicleTable.Members or {}
	local snd = horn and horn[2] or members.snd_horn

	if ent.snd_horn ~= snd then
		ent.snd_horn = snd

		if ent.horn then
			ent.horn:Stop()
			ent.horn = nil
		end
	end

	if ent.SetBulletProofTires then ent:SetBulletProofTires(car.bpw and true or (members.BulletProofTires or false)) end
	if ent.SetTurboCharged then ent:SetTurboCharged(car.turbo and true or (members.Turbocharged or false)) end
	if ent.SetSuperCharged then ent:SetSuperCharged(car.super and true or (members.Supercharged or false)) end
end

-- двигатель / тормоза / подвеска (после инициализации simfphys - нужны колёса)
-- подвеска: в McCD минус = ниже, в simfphys плюс = ниже
function McCD.ApplyPerformance(ent, car)
	local nitro = tonumber(car.nitro) or 0
	local brakes = tonumber(car.breaks) or 0
	local susp = tonumber(car.suspension) or 0

	if ent.PeakTorque and ent.SetMaxTorque then
		ent:SetMaxTorque(ent.PeakTorque * (1 + nitro * cfg.NitroTorque))
	end

	if ent.MaxGrip and ent.SetMaxTraction then
		ent:SetMaxTraction(ent.MaxGrip * (1 - (nitro >= 2 and nitro * cfg.NitroGrip or 0)))
	end

	if ent.BrakePower and ent.SetBrakePower then
		ent:SetBrakePower((ent.BrakePower + 30) * (1 + brakes * cfg.BrakesMul))
	end

	if ent.SetFrontSuspensionHeight then
		ent:SetFrontSuspensionHeight(-susp)
		ent:SetRearSuspensionHeight(-susp)
	end
end

function McCD.UpdatePlates(ent, car)
	ent.McCD_UniqueId = car.uniqueid
	ent.McCD_Plate = car.uniqueid
	ent.customplates = plateMat(car)
	ent:SetNWString("McCD.UniqueId", car.uniqueid or "")

	for _, plt in ipairs({ent.frontplt, ent.rearplt}) do
		if not IsValid(plt) then continue end

		if car.uniqueid and REN and REN.SetLicensePlateNumber then
			REN.SetLicensePlateNumber(plt, car.uniqueid)
		end

		plt:SetSubMaterial(0, ent.customplates or "")
	end
end

function McCD.ApplyAll(ent, car)
	McCD.ApplyLook(ent, car)
	McCD.ApplyLive(ent, car)
	McCD.UpdatePlates(ent, car)

	if ent.IsInitialized and ent:IsInitialized() then
		McCD.ApplyPerformance(ent, car)
	end
end

function McCD.SpawnCar(ply, car, pos, ang)
	if not simfphys or not simfphys.SpawnVehicleSimple then return nil, "Транспорт сейчас недоступен" end

	local ent = simfphys.SpawnVehicleSimple(car.entity, pos, ang)
	if not IsValid(ent) then return nil, "Не удалось подать машину" end

	McCD.SetupCar(ent, ply, car)

	return ent
end

--[[---------------------------------------------------------------------------
Покупка / продажа / подача из гаража
---------------------------------------------------------------------------]]
function McCD.Buy(ply, class, colorid)
	local shop = McCD.Cars[class]
	if not shop or shop.nobuy or not vehList()[class] then return end

	if istable(shop.grouprequirements) and not hasGroup(ply, shop.grouprequirements) then
		DarkRP.notify(ply, 1, 4, "Эта машина доступна только для групп: " .. table.concat(shop.grouprequirements, ", "))
		return
	end

	local cars, max = ply:LoadCars(), McCD.MaxCars(ply)

	if #cars >= max then
		DarkRP.notify(ply, 1, 5, "В гараже нет свободного места (" .. #cars .. " из " .. max .. ")")
		return
	end

	local palette = shop.palette or cfg.CarColors
	local pc = palette[colorid or 1] or palette[1]
	local c = pc and pc[1]
	local price = shop.donate and math.Round(shop.price * (cfg.Discount or 1)) or shop.price

	if shop.donate then
		if not ply.TakeCredits or not ply:TakeCredits(price, "mccd_buy_" .. class) then
			DarkRP.notify(ply, 1, 4, "Недостаточно кредитов: нужно " .. string.Comma(price) .. "¤")
			return
		end
	else
		if not ply:canAfford(price) then
			DarkRP.notify(ply, 1, 4, "Недостаточно денег: нужно $" .. string.Comma(price))
			return
		end

		ply:addMoney(-price)
	end

	local ok, car = pcall(McCD.AddCar, ply, class, {
		color = c and Color(c.r, c.g, c.b) or nil,
		originalprice = price,
	}, true)

	if not ok or not car then
		if shop.donate then ply:AddCredits(price, "mccd_refund_" .. class) else ply:addMoney(price) end

		DarkRP.notify(ply, 1, 5, "Не удалось оформить покупку, средства возвращены")
		ErrorNoHalt("[McCD] " .. tostring(car) .. "\n")
		return
	end

	DarkRP.notify(ply, 0, 6, "Поздравляем с покупкой! " .. car.name .. " (" .. car.uniqueid .. ") ждёт вас в гараже")
	DarkRP.log("money", ply, nil, "купил машину " .. class .. " (" .. car.uniqueid .. ")", nil, shop.donate and price .. "¤" or price)
	hook.Run("McCD.CarBought", ply, car, price, shop.donate)
end

function McCD.Sell(ply, idx, credits)
	local car = McCD.GetCar(ply, idx)
	if not car then return end

	local shop = McCD.Cars[car.entity] or {}

	if shop.nocase then
		DarkRP.notify(ply, 1, 4, "Эту машину нельзя продать")
		return
	end

	if McCD.CheckLost(car) then
		DarkRP.notify(ply, 1, 5, "Автомобиль потерян. Пожалуйста подождите, пока его вернут в гараж")
		return
	end

	local ent = McCD.GetSpawned(car)

	if IsValid(ent) then
		if not nearGarage(ply, ent) then
			DarkRP.notify(ply, 1, 5, "Машина на улице - пригоните её к гаражу, чтобы продать")
			return
		end

		McCD.ReturnCar(ent, true)
	end

	local refund = McCD.RefundPrice(car)
	local money, cred = 0, 0

	if car.donate then
		if credits then
			cred = math.Round(refund / 2)
		else
			money = math.Round(refund * cfg.CreditRate / 2)
		end
	else
		money = refund
	end

	McCD.RemoveCar(ply, readIndex(idx))

	if cred > 0 then ply:AddCredits(cred, "mccd_sell_" .. car.entity) end
	if money > 0 then ply:addMoney(money) end

	DarkRP.notify(ply, 0, 6, "Машина " .. car.name .. " продана за " .. (cred > 0 and string.Comma(cred) .. "¤" or "$" .. string.Comma(money)))
	DarkRP.log("money", ply, nil, "продал машину " .. car.entity .. " (" .. tostring(car.uniqueid) .. ")", nil, cred > 0 and cred .. "¤" or money)
	hook.Run("McCD.CarSold", ply, car, money, cred)

	McCD.SendGarage(ply, true)
end

-- лимит MaxSpawned: свободные машины игрока на улице уезжают в гараж сами (старые первыми)
function McCD.Unpark(ply, idx)
	local car = McCD.GetCar(ply, idx)
	if not car then return end

	if not McCD.Cars[car.entity] or not vehList()[car.entity] then
		DarkRP.notify(ply, 1, 4, "Эта машина сейчас недоступна")
		return
	end

	if McCD.CheckLost(car) then
		DarkRP.notify(ply, 1, 5, "Автомобиль потерян. Он вернётся в гараж через " .. niceTime(car.wcitimer - os.time()))
		return
	end

	local s = ply.McCD_Session
	local origin = s and s.pos or ply:GetPos()
	local recall = {}
	local cur = McCD.GetSpawned(car)

	if IsValid(cur) then
		if occupied(cur) then
			DarkRP.notify(ply, 1, 5, "Вашей машиной сейчас кто-то пользуется")
			return
		end

		if cur:GetPos():DistToSqr(origin) <= cfg.ReturnDist ^ 2 then
			DarkRP.notify(ply, 0, 4, "Машина уже стоит у гаража")
			gps(ply, car.name, cur:GetPos())
			return
		end

		recall[cur] = true
	end

	local out = {}

	for _, ent in ipairs(McCD.GetSpawnedList(ply)) do
		if ent ~= cur then table.insert(out, ent) end
	end

	table.sort(out, function(a, b) return (a.McCD_SpawnTime or 0) < (b.McCD_SpawnTime or 0) end)

	local need = #out + 1 - cfg.MaxSpawned

	for _, ent in ipairs(out) do
		if need <= 0 then break end
		if occupied(ent) then continue end

		recall[ent] = true
		need = need - 1
	end

	if need > 0 then
		DarkRP.notify(ply, 1, 5, "Одновременно можно вывезти машин: " .. cfg.MaxSpawned .. ". Ваши машины на улице сейчас заняты")
		return
	end

	local fee = McCD.GetSpawnFee(car, car.blown)

	if not ply:canAfford(fee) then
		DarkRP.notify(ply, 1, 4, "Подача машины стоит $" .. string.Comma(fee))
		return
	end

	local pos, ang = McCD.FindSpot(origin, recall)

	if not pos then
		DarkRP.notify(ply, 1, 4, "Все парковочные места заняты, попробуйте чуть позже")
		return
	end

	for ent in pairs(recall) do
		McCD.ReturnCar(ent, ent == cur)
	end

	local ent, err = McCD.SpawnCar(ply, car, pos, ang)

	if not IsValid(ent) then
		DarkRP.notify(ply, 1, 4, err or "Не удалось подать машину")
		return
	end

	ply:addMoney(-fee)

	if car.blown then
		car.blown = nil
		McCD.DB.Save(car)
	end

	DarkRP.notify(ply, 0, 6, "Машина " .. car.name .. " подана на парковку ($" .. string.Comma(fee) .. ")")
	gps(ply, car.name, pos)
	DarkRP.log("money", ply, nil, "вывез из гаража " .. car.entity .. " (" .. tostring(car.uniqueid) .. ")", nil, fee, ent)
	hook.Run("McCD.CarSpawned", ply, car, ent)
end

--[[---------------------------------------------------------------------------
Тюнинг (операция 3). Обработчик читает данные типа и возвращает:
  цена $, цена ¤, функция применения | nil, текст ошибки
Машина должна быть в гараже или стоять свободной у гаража (тогда изменения видны сразу).
---------------------------------------------------------------------------]]
local modelCache = {}

-- скины и бодигруппы модели без спавна (кеш по классу)
function McCD.ModelInfo(class)
	if modelCache[class] then return modelCache[class] end

	local veh = vehList()[class]
	if not veh or not veh.Model then return end

	local ent = ents.Create("prop_dynamic")
	if not IsValid(ent) then return end

	ent:SetModel(veh.Model)

	local info = {skins = ent:SkinCount(), bodygroups = {}}

	for _, bg in ipairs(ent:GetBodyGroups() or {}) do
		info.bodygroups[bg.id] = {name = bg.name, num = bg.num}
	end

	ent:Remove()
	modelCache[class] = info

	return info
end

local Tune = {}

Tune["color"] = function(ply, car, shop)
	local c = cfg.TuneColors[net.ReadUInt(16)]
	if not c then return end

	return c[2], 0, function() car.color = Color(c[1].r, c[1].g, c[1].b) end
end

Tune["skin"] = function(ply, car, shop)
	local skin = readIndex(net.ReadFloat())
	if not skin or skin < 0 or skin == (car.skin or 0) then return end
	if shop.noskin then return nil, nil, nil, "Для этой машины смена покрытия недоступна" end
	if shop.allowed_skins and not shop.allowed_skins[skin] then return end

	local info = McCD.ModelInfo(car.entity)
	if not info or skin >= info.skins then return end

	return cfg.CarSkinPrice or 0, 0, function() car.skin = skin > 0 and skin or nil end
end

Tune["skin_pack"] = function(ply, car, shop)
	local pack = net.ReadString()

	if pack == "" then
		if not car.skin_pack then return end
		return 0, 0, function() car.skin_pack = nil end
	end

	if not shop.skins_pack or not shop.skins_pack[pack] or car.skin_pack == pack then return end

	if not (MQS and MQS.GetSData and MQS.GetSData(ply, pack)) then
		return nil, nil, nil, "Это покрытие у вас не разблокировано"
	end

	return 0, 0, function() car.skin_pack = pack end
end

Tune["unlockgbs"] = function(ply, car, shop)
	if not shop.cantune then return end
	if car.unlockedbg or shop.unlockedbg then return nil, nil, nil, "Кастомизация кузова уже разблокирована" end

	return 0, cfg.UnlockBodyGroups, function() car.unlockedbg = true end
end

-- клиент присылает все бодигруппы модели (num >= 2), платятся только изменённые
Tune["bodygroups"] = function(ply, car, shop)
	local tbl = net.ReadTable()
	net.ReadFloat() -- количество изменений сервер считает сам

	if not shop.cantune or not istable(tbl) then return end
	if not car.unlockedbg and not shop.unlockedbg then return nil, nil, nil, "Сначала разблокируйте кастомизацию кузова" end

	local info = McCD.ModelInfo(car.entity)
	if not info then return end

	local cur = McCD.GetBodygroups(car)
	local new, changes, count = table.Copy(car.bodygroups or {}), 0, 0

	for id, val in pairs(tbl) do
		count = count + 1
		if count > 64 then return end

		id, val = readIndex(id), readIndex(val)
		if not id or not val then return end

		local bg = info.bodygroups[id]
		if not bg or val < 0 or val >= bg.num then return end
		if (cur[id] or 0) == val then continue end

		if cfg.BannedBodyGroup[bg.name] or (shop.baned_bg and shop.baned_bg[id]) or (shop.baned_bgs and shop.baned_bgs[id] and shop.baned_bgs[id][val]) then
			return nil, nil, nil, "Эту деталь кузова менять нельзя"
		end

		new[id] = val
		changes = changes + 1
	end

	if changes < 1 then return end

	return changes * cfg.BodyGroupPrice, 0, function() car.bodygroups = new end
end

Tune["nitro"] = function(ply, car, shop)
	local k = readIndex(net.ReadFloat())
	if not k or not cfg.Nitro[k] or (car.nitro or 0) == k then return end
	if shop.tuneblock then return nil, nil, nil, "Эту машину нельзя тюнинговать" end

	return cfg.Nitro[k], 0, function() car.nitro = k > 0 and k or nil end
end

Tune["breaks"] = function(ply, car, shop)
	local k = readIndex(net.ReadFloat())
	if not k or not cfg.Breaks[k] or (car.breaks or 0) == k then return end
	if shop.tuneblock then return nil, nil, nil, "Эту машину нельзя тюнинговать" end

	return cfg.Breaks[k], 0, function() car.breaks = k > 0 and k or nil end
end

-- клиент шлёт индекс McCD.Config.Suspension, хранится значение высоты
Tune["suspension"] = function(ply, car, shop)
	local k = readIndex(net.ReadFloat())
	local s = k and cfg.Suspension[k]
	if not s or (car.suspension or 0) == s[1] then return end

	return s[3], 0, function() car.suspension = s[1] ~= 0 and s[1] or nil end
end

Tune["horn"] = function(ply, car, shop)
	local k = readIndex(net.ReadFloat())
	local h = k and cfg.Horns[k]
	if not h or car.horn == k then return end

	return h[3], 0, function() car.horn = k end
end

Tune["smoke"] = function(ply, car, shop)
	local k = readIndex(net.ReadFloat())
	if not k or not cfg.Smoke[k] or (car.smoke or 0) == k then return end

	return cfg.TireSmokePrice, 0, function() car.smoke = k > 0 and k or nil end
end

Tune["neon"] = function(ply, car, shop)
	local k = readIndex(net.ReadFloat())
	if not k or not cfg.Neon[k] or (car.neon or 0) == k then return end
	if shop.tuneblock then return nil, nil, nil, "Для этой машины подсветка недоступна" end

	return 0, cfg.NeonPrice, function() car.neon = k > 0 and k or nil end
end

Tune["plate_gen"] = function(ply, car, shop)
	if car.lpcd and car.lpcd > os.time() then
		return nil, nil, nil, "Сменить номер можно будет через " .. niceTime(car.lpcd - os.time())
	end

	return cfg.RandomPlate, 0, function()
		car.uniqueid = McCD.GenPlate()
		car.lpcd = os.time() + cfg.CoolDown
	end
end

Tune["plates"] = function(ply, car, shop)
	local k = readIndex(net.ReadFloat())
	local p = k and cfg.Plates[k]
	if not p or (car.plates or 0) == k then return end

	return 0, k > 0 and p[3] or 0, function() car.plates = k > 0 and k or nil end
end

McCD.TuneHandlers = Tune

local function tunable(ply, car)
	if McCD.CheckLost(car) then return false, "Автомобиль потерян. Пожалуйста подождите, пока его вернут в гараж" end

	local ent = McCD.GetSpawned(car)

	if IsValid(ent) and not nearGarage(ply, ent) then
		return false, "Машина на улице - пригоните её к гаражу, чтобы что-то изменить"
	end

	return true, ent
end

function McCD.Tune(ply, idx, kind)
	local car = McCD.GetCar(ply, idx)
	local handler = Tune[kind]
	if not car or not handler then return end

	local shop = McCD.Cars[car.entity]
	if not shop then return end

	local function fail(msg)
		if msg then DarkRP.notify(ply, 1, 4, msg) end
		McCD.SendUpdate(ply, idx)
	end

	local price, credits, apply, err = handler(ply, car, shop)
	if not apply then return fail(err) end

	local ok, ent = tunable(ply, car)
	if not ok then return fail(ent) end

	price = math.max(math.floor(tonumber(price) or 0), 0)
	credits = math.max(math.floor(tonumber(credits) or 0), 0)

	if price > 0 and not ply:canAfford(price) then return fail("Недостаточно денег: нужно $" .. string.Comma(price)) end
	if credits > 0 and not (ply.CanAffordCredits and ply:CanAffordCredits(credits)) then return fail("Недостаточно кредитов: нужно " .. string.Comma(credits) .. "¤") end
	if credits > 0 and not ply:TakeCredits(credits, "mccd_" .. kind) then return fail("Не удалось списать кредиты") end
	if price > 0 then ply:addMoney(-price) end

	apply()
	McCD.DB.Save(car)

	if IsValid(ent) then McCD.ApplyAll(ent, car) end

	McCD.SendUpdate(ply, idx)

	DarkRP.log("money", ply, nil, "тюнинг " .. kind .. ": " .. car.entity .. " (" .. tostring(car.uniqueid) .. ")", nil, credits > 0 and credits .. "¤" or price)
	hook.Run("McCD.CarTuned", ply, car, kind, price, credits)
end

--[[---------------------------------------------------------------------------
Сеть
---------------------------------------------------------------------------]]
local Ops = {}

Ops[0] = function(ply)
	McCD.OpenList(ply, net.ReadBool())
end

Ops[1] = function(ply)
	local class = net.ReadString()
	McCD.Buy(ply, class, readIndex(net.ReadFloat()))
end

-- Bool приходит только для донат-машин (3 + 32 бита без него)
Ops[2] = function(ply, len)
	local idx = net.ReadUInt(32)
	McCD.Sell(ply, idx, len > 35 and net.ReadBool())
end

Ops[3] = function(ply)
	local idx = readIndex(net.ReadFloat())
	McCD.Tune(ply, idx, net.ReadString())
end

Ops[4] = function(ply)
	McCD.Unpark(ply, net.ReadUInt(16))
end

net.Receive("McCD.Msg", function(len, ply)
	if DarkRP.NetDelay(ply, "McCD.Msg", 0.2) then return end

	local op = net.ReadUInt(3)
	if not Ops[op] or not McCD.CanUse(ply) then return end

	Ops[op](ply, len)
end)

--[[---------------------------------------------------------------------------
Хуки машин
---------------------------------------------------------------------------]]
-- после инициализации simfphys (колёса созданы, OnSpawn модели отработал)
hook.Add("simfphysOnSpawn", "McCD.Setup", function(ent)
	local car = ent.McCD_CarData
	if not car then return end

	McCD.ApplyLook(ent, car)
	McCD.ApplyLive(ent, car)
	McCD.ApplyPerformance(ent, car)

	if ent.keysLock then ent:keysLock() end
end)

hook.Add("simfphysOnDestroyed", "McCD.Destroyed", function(ent)
	local car = ent.McCD_CarData
	if not car then return end

	ent.McCD_Destroyed = true
	car.blown = true
	McCD.DB.Save(car)

	local ply = ent.McCDOwner

	if IsValid(ply) then
		DarkRP.notify(ply, 1, 7, "Ваша машина " .. (car.name or car.entity) .. " уничтожена. Подача из гаража обойдётся в $" .. string.Comma(McCD.GetSpawnFee(car, true)))
	end

	DarkRP.log("property", ply, nil, "машина уничтожена: " .. car.entity .. " (" .. tostring(car.uniqueid) .. ")", nil, nil, ent)
end)

hook.Add("EntityRemoved", "McCD.CarRemoved", function(ent)
	if not ent.McCD_CarDataId or ent.McCD_Destroyed or ent.McCD_Silent then return end

	local ply, car = ent.McCDOwner, ent.McCD_CarData
	if not IsValid(ply) or not car then return end

	if McCD.CheckLost(car) then
		DarkRP.notify(ply, 1, 7, "Ваша машина " .. car.name .. " пропала. Она вернётся в гараж через " .. niceTime(car.wcitimer - os.time()))
		return
	end

	DarkRP.notify(ply, 0, 4, "Машина " .. car.name .. " возвращена в гараж")
end)

-- ключи: владелец (NW2 "McCD.Owner") открывает машину - mc_cd_ext.lua (shared)
-- реконнект / повторный вход тем же персонажем: машина ещё на улице (entremovedelay) - снова ваша
hook.Add("DarkRP.CharacterSelected", "McCD.Relink", function(ply)
	local sid, charid = ply:SteamID64(), DarkRP.CharacterID(ply)

	for _, ent in ipairs(ents.FindByClass(CAR_CLASS)) do
		if not ent.McCD_CarDataId or ent.McCD_OwnerSID ~= sid or ent.OwnerCharID ~= charid then continue end

		McCD.LinkOwner(ent, ply)
		ent.McCD_CarData = McCD.FindCar(ply, ent.McCD_CarDataId) or ent.McCD_CarData
	end
end)

-- комната гаража (McCD.Config.TunePos) рендерится клиентом, пока открыто меню
hook.Add("SetupPlayerVisibility", "McCD.GaragePVS", function(ply)
	if ply.McCD_Session and cfg.TunePos and McCD.InSession(ply) then
		AddOriginToPVS(cfg.TunePos)
	end
end)

--[[---------------------------------------------------------------------------
Разборка (McCD.ChopShop в sh_config): MCS NPC "DarkRP Разборка: оценка" / "DarkRP Разборка машин"
---------------------------------------------------------------------------]]
local function npcSay(ply, text, snd, typ)
	if not isstring(text) then return end

	DarkRP.notify(ply, typ or 0, 8, text)

	if isstring(snd) and string.StartWith(snd, "http") then
		ply:SendLua(string.format("sound.PlayURL(%q,\"\",function(s) if IsValid(s) then s:Play() end end)", snd))
	end
end

local function chopOffer(ans)
	return istable(ans) and istable(ans[1]) and ans[1][2] == "ChopShop"
end

function McCD.ChopShopCheck(ply, npc)
	local text, snd, ans = McCD.ChopShop(ply, true)
	npcSay(ply, text, snd, chopOffer(ans) and 0 or 1)
end

function McCD.ChopShopSell(ply, npc)
	if DarkRP.NetDelay(ply, "McCD.ChopShop", 2) then return end

	local text, snd, ans = McCD.ChopShop(ply, true)

	if not chopOffer(ans) then
		npcSay(ply, text, snd, 1)
		return
	end

	local before = ply:getDarkRPVar("money") or 0
	local ok, err = pcall(McCD.ChopShop, ply)

	if not ok then ErrorNoHalt("[McCD] ChopShop: " .. tostring(err) .. "\n") end

	local gain = (ply:getDarkRPVar("money") or 0) - before

	if gain > 0 then
		DarkRP.notify(ply, 0, 6, "По рукам! Машина ушла на разборку: +$" .. string.Comma(gain))
	end
end

-- без этого GetGlobalInt = 0 и разборка закрыта первые 40 минут после рестарта
local function initChopShop()
	if GetGlobalInt("LslChopShop", 0) == 0 then
		SetGlobalInt("LslChopShop", -2400)
	end
end

initChopShop()
hook.Add("InitPostEntity", "McCD.ChopShop", initChopShop)

--[[---------------------------------------------------------------------------
Автомастерская (MCS NPC "DarkRP Автомастерская", data.upgrade): машина игрока у NPC
---------------------------------------------------------------------------]]
McCD.Upgrades = {
	radio = {name = "Автомагнитола", price = function() return cfg.RadioPrice end},
	bpw = {name = "Пуленепробиваемые шины", price = function() return cfg.BpwPrice end, tune = true},
	turbo = {name = "Турбонаддув", price = function() return cfg.TurboCharger end, tune = true},
	super = {name = "Нагнетатель", price = function() return cfg.SuperCharger end, tune = true},
}

local function hasUpgrade(car, key)
	if key == "radio" then return car.radio ~= false end

	return car[key] and true or false
end

local function ownCarNear(ply, pos, dist)
	local best, bd

	for _, ent in ipairs(McCD.GetSpawnedList(ply)) do
		local d = ent:GetPos():DistToSqr(pos)

		if d <= dist ^ 2 and (not bd or d < bd) then
			best, bd = ent, d
		end
	end

	return best
end

function McCD.Workshop(ply, npc, data)
	local key = istable(data) and data.upgrade or "radio"
	local up = McCD.Upgrades[key]
	if not up or not IsValid(npc) then return end

	local ok, msg = McCD.CanOpen(ply)
	if not ok then
		if msg then DarkRP.notify(ply, 1, 4, msg) end
		return
	end

	local ent = ownCarNear(ply, npc:GetPos(), cfg.WorkshopDist)
	local car = IsValid(ent) and ent.McCD_CarData

	if not car then
		DarkRP.notify(ply, 1, 4, "Подгоните свою машину к мастерской")
		return
	end

	local shop = McCD.Cars[car.entity] or {}

	if up.tune and shop.tuneblock then
		DarkRP.notify(ply, 1, 4, "Эту машину нельзя улучшать")
		return
	end

	if hasUpgrade(car, key) then
		DarkRP.notify(ply, 1, 4, up.name .. " уже установлен(а)")
		return
	end

	local price = math.max(math.floor(tonumber(up.price()) or 0), 0)

	if not ply:canAfford(price) then
		DarkRP.notify(ply, 1, 4, up.name .. ": нужно $" .. string.Comma(price))
		return
	end

	ply:addMoney(-price)
	McCD.AddCarParameter(ply, car.id, {[key] = true}, ent)

	DarkRP.notify(ply, 0, 5, up.name .. " установлен(а) на " .. car.name .. " (-$" .. string.Comma(price) .. ")")
	DarkRP.log("money", ply, nil, "мастерская " .. key .. ": " .. car.entity .. " (" .. tostring(car.uniqueid) .. ")", nil, price, ent)
	hook.Run("McCD.CarTuned", ply, car, key, price, 0)
end

-- предмет "Радио (от машины)" (DarkRP.Junk car_radio): E рядом с машиной без радио
function McCD.InstallRadio(ply, item)
	local best, bd

	for _, ent in ipairs(ents.FindInSphere(item:GetPos(), 150)) do
		if ent:GetClass() ~= CAR_CLASS or not ent.McCD_CarData or ent.McCD_Returned then continue end

		local d = ent:GetPos():DistToSqr(item:GetPos())
		if not bd or d < bd then best, bd = ent, d end
	end

	if not IsValid(best) then
		DarkRP.notify(ply, 1, 4, "Поднесите радио к машине")
		return
	end

	local car = best.McCD_CarData
	local access = (best.HasKeysAccess and best:HasKeysAccess(ply)) or ply:Team() == TEAM_CAR

	if not access then
		DarkRP.notify(ply, 1, 4, "Нужны ключи от этой машины (или помощь автомеханика)")
		return
	end

	if car.radio ~= false then
		DarkRP.notify(ply, 1, 4, "В этой машине уже есть радио")
		return
	end

	item:Remove()
	McCD.AddCarParameter(best.McCDOwner, car.id, {radio = true}, best)

	DarkRP.notify(ply, 0, 4, "Радио установлено")
	DarkRP.log("property", ply, best.McCDOwner, "установил радио в " .. car.entity .. " (" .. tostring(car.uniqueid) .. ")", nil, nil, best)
end

hook.Add("PlayerUse", "McCD.CarRadioItem", function(ply, ent)
	if ent:GetClass() ~= "spawned_junk" or not ent.Geteclass or ent:Geteclass() ~= "car_radio" then return end
	if DarkRP.NetDelay(ply, "McCD.CarRadioItem", 1) then return end

	McCD.InstallRadio(ply, ent)
end)

--[[---------------------------------------------------------------------------
Админ-команды: SAM (mc_cd_ext.lua) и консоль сервера
  mccd_givecar <SteamID | SteamID64 | ник> <класс>  - выдать машину (в т.ч. оффлайн)
  mccd_takecar <SteamID | SteamID64 | ник> <класс>  - забрать последнюю машину класса
---------------------------------------------------------------------------]]
local function findTarget(str)
	str = string.Trim(tostring(str or ""))
	if str == "" then return end

	local sid64

	if string.StartWith(string.upper(str), "STEAM_") then
		sid64 = util.SteamIDTo64(string.upper(str))
	elseif string.match(str, "^7656%d+$") then
		sid64 = str
	end

	if sid64 and sid64 ~= "0" then
		return player.GetBySteamID64(sid64) or nil, sid64
	end

	local found
	str = string.lower(str)

	for _, v in ipairs(player.GetHumans()) do
		if string.find(string.lower(v:Nick()), str, 1, true) then
			if found then return end
			found = v
		end
	end

	if found then return found, found:SteamID64() end
end

function McCD.AdminCommand(admin, mode, target, class)
	local ply, sid64

	if isentity(target) then
		if not IsValid(target) then return end
		ply, sid64 = target, target:SteamID64()
	else
		ply, sid64 = findTarget(target)
	end

	if not sid64 then return say(admin, 1, "Игрок не найден") end

	local who = IsValid(ply) and ply:Nick() or sid64

	if mode == "give" then
		if not McCD.Cars[class] or not vehList()[class] then return say(admin, 1, "Неизвестная машина: " .. tostring(class)) end

		local ok, car = true

		if IsValid(ply) then
			ok, car = pcall(McCD.AddCar, ply, class)
		else
			car = McCD.AddCarOffline(sid64, class)
		end

		if not ok or not car then return say(admin, 1, "Не удалось выдать машину" .. (ok and "" or ": " .. tostring(car))) end

		say(admin, 0, "Машина " .. class .. " (" .. car.uniqueid .. ") выдана: " .. who)
		DarkRP.log("admin", admin, ply, "выдал машину " .. class .. " (" .. sid64 .. ")")
	elseif mode == "take" then
		local car, idx

		if IsValid(ply) then
			local cars = ply:LoadCars()

			for i = #cars, 1, -1 do
				if cars[i].entity == class then
					car, idx = cars[i], i
					break
				end
			end
		else
			car = McCD.DB.FindClass(sid64, class)
		end

		if not car then return say(admin, 1, "У игрока нет машины " .. tostring(class)) end

		McCD.ReturnCar(McCD.GetSpawned(car), true)

		if idx then
			McCD.RemoveCar(ply, idx)
		else
			McCD.DB.Delete(car.id)
		end

		if IsValid(ply) then DarkRP.notify(ply, 1, 6, "Администратор изъял вашу машину " .. (car.name or class)) end

		say(admin, 0, "Машина " .. class .. " изъята у " .. who)
		DarkRP.log("admin", admin, ply, "изъял машину " .. class .. " (" .. sid64 .. ")")
	elseif mode == "return" then
		if not IsValid(ply) then return say(admin, 1, "Игрок не на сервере") end

		local list = McCD.GetSpawnedList(ply)

		for _, ent in ipairs(list) do
			McCD.ReturnCar(ent)
		end

		say(admin, 0, "Возвращено машин " .. who .. ": " .. #list)
		DarkRP.log("admin", admin, ply, "вернул машины игрока в гараж (" .. #list .. ")")
	end
end

-- ник может быть с пробелами, SteamID с двоеточиями - разбираем argStr (последнее слово - класс)
local function parseArgs(argStr)
	local parts = string.Explode("%s+", string.Trim(argStr or ""), true)
	local class = #parts > 1 and table.remove(parts) or nil

	return string.Trim(table.concat(parts, " "), "\""), class
end

for cmd, mode in pairs({mccd_givecar = "give", mccd_takecar = "take"}) do
	concommand.Add(cmd, function(ply, _, _, argStr)
		if IsValid(ply) and not ply:IsSuperAdmin() then return end

		local target, class = parseArgs(argStr)
		if not class then return say(ply, 1, cmd .. " <SteamID | SteamID64 | ник> <класс>") end

		McCD.AdminCommand(ply, mode, target, class)
	end)
end
